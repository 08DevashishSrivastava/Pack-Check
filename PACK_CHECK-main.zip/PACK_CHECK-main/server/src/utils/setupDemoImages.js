import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import https from 'https';
import http from 'http';
import { query, execute } from '../config/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const UPLOADS_DIR = path.resolve(__dirname, '../../uploads/inspections');

// Ensure base uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Helper to download an image from a URL to a local destination
const downloadFile = (url, destPath) => {
  return new Promise((resolve, reject) => {
    if (fs.existsSync(destPath) && fs.statSync(destPath).size > 1000) {
      return resolve(destPath);
    }

    const dir = path.dirname(destPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const file = fs.createWriteStream(destPath);
    const client = url.startsWith('https') ? https : http;

    const request = client.get(url, (response) => {
      // Handle redirects (e.g. Unsplash 302/301)
      if (response.statusCode === 301 || response.statusCode === 302 || response.statusCode === 307) {
        file.close();
        if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
        return downloadFile(response.headers.location, destPath).then(resolve).catch(reject);
      }

      if (response.statusCode !== 200) {
        file.close();
        if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
        return reject(new Error(`Failed to download image: status code ${response.statusCode}`));
      }

      response.pipe(file);

      file.on('finish', () => {
        file.close(() => resolve(destPath));
      });
    });

    request.on('error', (err) => {
      file.close();
      if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
      reject(err);
    });

    request.setTimeout(15000, () => {
      request.destroy();
      file.close();
      if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
      reject(new Error('Download timeout'));
    });
  });
};

// Fallback generator for generating clean SVG placeholder if remote network is offline
const createSvgFallback = (destPath, title, subtitle, face) => {
  const dir = path.dirname(destPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">
  <rect width="800" height="800" fill="#0f172a"/>
  <rect x="20" y="20" width="760" height="760" rx="16" fill="#1e293b" stroke="#334155" stroke-width="2"/>
  <circle cx="400" cy="300" r="80" fill="#2563eb" opacity="0.2"/>
  <path d="M370 270 L430 330 M430 270 L370 330" stroke="#60a5fa" stroke-width="6" stroke-linecap="round"/>
  <rect x="150" y="240" width="500" height="120" rx="12" fill="#1d4ed8" opacity="0.1" stroke="#3b82f6" stroke-width="2" stroke-dasharray="6 4"/>
  <text x="400" y="440" fill="#f8fafc" font-size="26" font-weight="bold" font-family="sans-serif" text-anchor="middle">${title}</text>
  <text x="400" y="480" fill="#94a3b8" font-size="18" font-family="sans-serif" text-anchor="middle">${subtitle}</text>
  <rect x="300" y="520" width="200" height="36" rx="18" fill="#3b82f6"/>
  <text x="400" y="544" fill="#ffffff" font-size="14" font-weight="bold" font-family="sans-serif" text-anchor="middle">SURFACE: ${face}</text>
  <text x="400" y="740" fill="#64748b" font-size="13" font-family="monospace" text-anchor="middle">LEGAL METROLOGY (PACKAGED COMMODITIES) RULES, 2011</text>
</svg>`;

  fs.writeFileSync(destPath, svgContent, 'utf-8');
  return destPath;
};

// Seed map for all demo images
const demoImageMap = [
  {
    inspectionId: 'INSP-2026-0841',
    imgId: 'INSP-2026-0841_img-1',
    face: 'FRONT',
    fileName: 'front-nutricrunch-digestive.jpg',
    url: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800&auto=format&fit=crop&q=80',
    title: 'NutriCrunch Digestive Biscuits 200g',
    subtitle: 'Principal Display Panel (Front)'
  },
  {
    inspectionId: 'INSP-2026-0841',
    imgId: 'INSP-2026-0841_img-2',
    face: 'BACK',
    fileName: 'back-nutricrunch-ingredients.jpg',
    url: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800&auto=format&fit=crop&q=80',
    title: 'NutriCrunch Digestive Biscuits 200g',
    subtitle: 'Back Packaging Panel (Declarations)'
  },
  {
    inspectionId: 'INSP-2026-0840',
    imgId: 'INSP-2026-0840_img-1',
    face: 'FRONT',
    fileName: 'front-pureglo-facewash.jpg',
    url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800&auto=format&fit=crop&q=80',
    title: 'PureGlo Aloe Vera Face Wash 150ml',
    subtitle: 'Front Display Panel'
  },
  {
    inspectionId: 'INSP-2026-0839',
    imgId: 'INSP-2026-0839_img-1',
    face: 'FRONT',
    fileName: 'front-sunspice-turmeric.jpg',
    url: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=800&auto=format&fit=crop&q=80',
    title: 'SunSpice Organic Turmeric Powder 500g',
    subtitle: 'Front Packaging Surface'
  },
  {
    inspectionId: 'INSP-2026-0838',
    imgId: 'INSP-2026-0838_img-1',
    face: 'FRONT',
    fileName: 'front-sparkletech-spray.jpg',
    url: 'https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=800&auto=format&fit=crop&q=80',
    title: 'SparkleTech Disinfectant Spray 500ml',
    subtitle: 'Front Label Surface'
  },
  {
    inspectionId: 'INSP-2026-0846',
    imgId: 'INSP-2026-0846_img-test-1',
    face: 'FRONT',
    fileName: 'front-organic-flour.jpg',
    url: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800&auto=format&fit=crop&q=80',
    title: 'Organic Wheat Flour 5kg',
    subtitle: 'Front Display Panel'
  },
  {
    inspectionId: 'INSP-2026-0847',
    imgId: 'INSP-2026-0847_img-face-1',
    face: 'FRONT',
    fileName: 'front-principal-display.jpg',
    url: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800&auto=format&fit=crop&q=80',
    title: 'Parle-G Glucose Biscuits',
    subtitle: 'Front Principal Display Panel'
  },
  {
    inspectionId: 'INSP-2026-0847',
    imgId: 'INSP-2026-0847_img-face-1787472534953-0',
    face: 'BACK',
    fileName: 'back-parle-g-biscuit.jpg',
    url: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800&auto=format&fit=crop&q=80',
    title: 'Parle-G Glucose Biscuits',
    subtitle: 'Back Packaging Surface (MRP & USP)'
  }
];

export async function setupDemoImages() {
  console.log('--- Setting up Physical Demo Image Assets in server/uploads ---');
  let successCount = 0;

  for (const item of demoImageMap) {
    const inspDir = path.join(UPLOADS_DIR, item.inspectionId);
    if (!fs.existsSync(inspDir)) {
      fs.mkdirSync(inspDir, { recursive: true });
    }

    const filePath = path.join(inspDir, item.fileName);
    const relativeUrl = `/uploads/inspections/${item.inspectionId}/${item.fileName}`;

    try {
      // Attempt download from CDN
      console.log(`Provisioning image for ${item.inspectionId} (${item.face})...`);
      await downloadFile(item.url, filePath);
      console.log(`  ✓ Saved file: ${filePath} (${fs.statSync(filePath).size} bytes)`);
    } catch (err) {
      console.warn(`  ! CDN download failed (${err.message}). Generating high-quality SVG fallback...`);
      createSvgFallback(filePath, item.title, item.subtitle, item.face);
      console.log(`  ✓ Generated asset at: ${filePath}`);
    }

    // Update MySQL product_images record with relative served URL
    await execute(
      `UPDATE product_images 
       SET url = ?, file_name = ?
       WHERE id = ? OR (inspection_id = ? AND type = ?)`,
      [relativeUrl, item.fileName, item.imgId, item.inspectionId, item.face]
    );

    successCount++;
  }

  console.log(`--- Demo images setup complete. ${successCount} image files verified on disk & updated in MySQL ---\n`);
}

// Allow standalone execution
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  setupDemoImages()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(err);
      process.exit(1);
    });
}
