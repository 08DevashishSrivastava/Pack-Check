import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import sharp from 'sharp';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SERVER_SAMPLES_DIR = path.resolve(__dirname, '../../uploads/samples');
const CLIENT_SAMPLES_DIR = path.resolve(__dirname, '../../../client/public/samples');

[SERVER_SAMPLES_DIR, CLIENT_SAMPLES_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

const samples = [
  {
    id: 'sample-parle-g',
    fileName: 'parle_g_biscuit_pack.png',
    title: 'Parle-G Original Gluco Biscuits 250g',
    category: 'Food & Beverages / Biscuits',
    description: 'Parle-G Glucose Biscuits packaging label with complete mandatory declarations.',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="900" viewBox="0 0 900 900">
      <defs>
        <linearGradient id="bgParle" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#fffbeb"/>
          <stop offset="100%" stop-color="#fef3c7"/>
        </linearGradient>
        <linearGradient id="banner" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#dc2626"/>
          <stop offset="100%" stop-color="#b91c1c"/>
        </linearGradient>
      </defs>
      <rect width="900" height="900" rx="24" fill="url(#bgParle)" stroke="#d97706" stroke-width="4"/>
      
      <!-- Brand & Product Header -->
      <rect x="50" y="50" width="800" height="120" rx="16" fill="url(#banner)"/>
      <text x="450" y="110" fill="#ffffff" font-size="44" font-weight="900" font-family="Arial, Helvetica, sans-serif" text-anchor="middle" letter-spacing="2">PARLE-G</text>
      <text x="450" y="150" fill="#fef08a" font-size="22" font-weight="bold" font-family="Arial, Helvetica, sans-serif" text-anchor="middle">ORIGINAL GLUCO BISCUITS</text>

      <!-- Principal Display Declarations Panel -->
      <rect x="50" y="190" width="800" height="660" rx="16" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
      
      <rect x="80" y="220" width="740" height="50" rx="8" fill="#eff6ff"/>
      <text x="100" y="254" fill="#1e3a8a" font-size="24" font-weight="bold" font-family="Arial, sans-serif">Commodity: Glucose Biscuits</text>

      <rect x="80" y="290" width="740" height="60" rx="8" fill="#f0fdf4" stroke="#86efac" stroke-width="1.5"/>
      <text x="100" y="330" fill="#166534" font-size="26" font-weight="bold" font-family="Arial, sans-serif">Net Quantity: 250 g</text>

      <rect x="80" y="370" width="740" height="70" rx="8" fill="#fef2f2" stroke="#fca5a5" stroke-width="1.5"/>
      <text x="100" y="408" fill="#991b1b" font-size="25" font-weight="bold" font-family="Arial, sans-serif">MRP ₹ 30.00 (Incl. of all taxes)</text>
      <text x="100" y="432" fill="#7f1d1d" font-size="16" font-family="Arial, sans-serif">Unit Sale Price: ₹ 0.12 / g</text>

      <!-- Manufacturer & Address -->
      <text x="80" y="480" fill="#0f172a" font-size="18" font-weight="bold" font-family="Arial, sans-serif">Manufactured &amp; Packed by:</text>
      <text x="80" y="510" fill="#334155" font-size="16" font-family="Arial, sans-serif">Parle Products Pvt. Ltd., V.S. Khandekar Marg, Vile Parle East, Mumbai - 400057, Maharashtra</text>

      <!-- Dates & Batch -->
      <rect x="80" y="540" width="740" height="90" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1"/>
      <text x="100" y="575" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Date of Mfd / Pkd: 08/2026</text>
      <text x="500" y="575" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Batch No: BATCH-PG-2026-88</text>
      <text x="100" y="610" fill="#475569" font-size="16" font-family="Arial, sans-serif">Best Before: 9 Months from packaging</text>

      <!-- Consumer Care & Origin -->
      <rect x="80" y="650" width="740" height="110" rx="8" fill="#f1f5f9"/>
      <text x="100" y="682" fill="#0f172a" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Consumer Care Cell:</text>
      <text x="100" y="710" fill="#334155" font-size="15" font-family="Arial, sans-serif">Toll Free: 1800-22-7799 | Email: customercare@parle.biz</text>
      <text x="100" y="740" fill="#0369a1" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Country of Origin: India</text>

      <text x="450" y="810" fill="#94a3b8" font-size="12" font-family="monospace" text-anchor="middle">LEGAL METROLOGY (PACKAGED COMMODITIES) RULES, 2011 COMPLIANT LABEL</text>
    </svg>`
  },
  {
    id: 'sample-cadbury',
    fileName: 'cadbury_dairy_milk_silk.png',
    title: 'Cadbury Dairy Milk Silk 150g',
    category: 'Confectionery / Chocolate',
    description: 'Cadbury Dairy Milk Silk chocolate wrapper packaging with nutritional and statutory declarations.',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="900" viewBox="0 0 900 900">
      <defs>
        <linearGradient id="bgCadbury" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#3b0764"/>
          <stop offset="100%" stop-color="#1e1b4b"/>
        </linearGradient>
        <linearGradient id="gold" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#fbbf24"/>
          <stop offset="100%" stop-color="#f59e0b"/>
        </linearGradient>
      </defs>
      <rect width="900" height="900" rx="24" fill="url(#bgCadbury)" stroke="#6b21a8" stroke-width="4"/>
      
      <!-- Brand & Product Header -->
      <text x="450" y="110" fill="#ffffff" font-size="44" font-weight="900" font-family="Georgia, serif" text-anchor="middle" letter-spacing="1">Cadbury</text>
      <text x="450" y="165" fill="url(#gold)" font-size="34" font-weight="bold" font-family="Arial, sans-serif" text-anchor="middle">DAIRY MILK SILK</text>
      <text x="450" y="200" fill="#e9d5ff" font-size="18" font-family="Arial, sans-serif" text-anchor="middle">Pure Milk Chocolate Slab</text>

      <!-- Principal Display Declarations Panel -->
      <rect x="50" y="230" width="800" height="620" rx="16" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
      
      <rect x="80" y="260" width="740" height="50" rx="8" fill="#faf5ff"/>
      <text x="100" y="294" fill="#581c87" font-size="24" font-weight="bold" font-family="Arial, sans-serif">Product: Cadbury Dairy Milk Silk Chocolate</text>

      <rect x="80" y="325" width="740" height="60" rx="8" fill="#f0fdf4" stroke="#86efac" stroke-width="1.5"/>
      <text x="100" y="365" fill="#166534" font-size="26" font-weight="bold" font-family="Arial, sans-serif">Net Weight: 150 g</text>

      <rect x="80" y="400" width="740" height="70" rx="8" fill="#fef2f2" stroke="#fca5a5" stroke-width="1.5"/>
      <text x="100" y="438" fill="#991b1b" font-size="25" font-weight="bold" font-family="Arial, sans-serif">MRP ₹ 175.00 (Incl. of all taxes)</text>
      <text x="100" y="462" fill="#7f1d1d" font-size="16" font-family="Arial, sans-serif">Unit Sale Price: ₹ 1.17 / g</text>

      <!-- Manufacturer & Address -->
      <text x="80" y="505" fill="#0f172a" font-size="18" font-weight="bold" font-family="Arial, sans-serif">Manufactured by:</text>
      <text x="80" y="535" fill="#334155" font-size="16" font-family="Arial, sans-serif">Mondelez India Foods Pvt Ltd, Unit No 2001, Central Wing, Thane West, MH - 400607</text>

      <!-- Dates & Batch -->
      <rect x="80" y="560" width="740" height="90" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1"/>
      <text x="100" y="595" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Date of Manufacture: 06/2026</text>
      <text x="500" y="595" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Batch No: BATCH-MDLZ-7721</text>
      <text x="100" y="630" fill="#475569" font-size="16" font-family="Arial, sans-serif">Best Before 12 Months from Packaging</text>

      <!-- Consumer Care & Origin -->
      <rect x="80" y="665" width="740" height="110" rx="8" fill="#f1f5f9"/>
      <text x="100" y="697" fill="#0f172a" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Consumer Care Cell:</text>
      <text x="100" y="725" fill="#334155" font-size="15" font-family="Arial, sans-serif">Toll Free Helpline: 1800-22-7080 | Email: suggestions@mdlz.com</text>
      <text x="100" y="755" fill="#0369a1" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Country of Origin: India</text>

      <text x="450" y="825" fill="#94a3b8" font-size="12" font-family="monospace" text-anchor="middle">LEGAL METROLOGY STATUTORY DECLARATION PANEL</text>
    </svg>`
  },
  {
    id: 'sample-honey',
    fileName: 'organic_raw_honey.png',
    title: 'NaturePure Organic Raw Honey 500g',
    category: 'Natural Foods / Honey',
    description: 'NaturePure 100% Pure Organic Raw Honey glass jar container label.',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="900" viewBox="0 0 900 900">
      <defs>
        <linearGradient id="bgHoney" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#fef3c7"/>
          <stop offset="100%" stop-color="#d97706"/>
        </linearGradient>
      </defs>
      <rect width="900" height="900" rx="24" fill="url(#bgHoney)" stroke="#b45309" stroke-width="4"/>
      
      <!-- Brand & Product Header -->
      <rect x="50" y="40" width="800" height="130" rx="16" fill="#78350f"/>
      <text x="450" y="100" fill="#fde68a" font-size="40" font-weight="900" font-family="Arial, sans-serif" text-anchor="middle">NaturePure Essentials</text>
      <text x="450" y="145" fill="#ffffff" font-size="26" font-weight="bold" font-family="Arial, sans-serif" text-anchor="middle">100% ORGANIC RAW HONEY</text>

      <!-- Principal Display Declarations Panel -->
      <rect x="50" y="190" width="800" height="660" rx="16" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
      
      <rect x="80" y="220" width="740" height="50" rx="8" fill="#fffbeb"/>
      <text x="100" y="254" fill="#92400e" font-size="24" font-weight="bold" font-family="Arial, sans-serif">Commodity: Natural Forest Honey</text>

      <rect x="80" y="290" width="740" height="60" rx="8" fill="#f0fdf4" stroke="#86efac" stroke-width="1.5"/>
      <text x="100" y="330" fill="#166534" font-size="26" font-weight="bold" font-family="Arial, sans-serif">Net Quantity: 500 g</text>

      <rect x="80" y="370" width="740" height="70" rx="8" fill="#fef2f2" stroke="#fca5a5" stroke-width="1.5"/>
      <text x="100" y="408" fill="#991b1b" font-size="25" font-weight="bold" font-family="Arial, sans-serif">MRP ₹ 349.00 (Incl. of all taxes)</text>
      <text x="100" y="432" fill="#7f1d1d" font-size="16" font-family="Arial, sans-serif">Unit Sale Price: ₹ 0.70 / g</text>

      <!-- Manufacturer & Address -->
      <text x="80" y="480" fill="#0f172a" font-size="18" font-weight="bold" font-family="Arial, sans-serif">Packed &amp; Marketed by:</text>
      <text x="80" y="510" fill="#334155" font-size="16" font-family="Arial, sans-serif">NaturePure Agro Foods Ltd, Plot 42, HSIIDC Industrial Area, Manesar, Gurgaon, Haryana - 122050</text>

      <!-- Dates & Batch -->
      <rect x="80" y="540" width="740" height="90" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1"/>
      <text x="100" y="575" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Date of Packing: 07/2026</text>
      <text x="500" y="575" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Batch No: NP-HNY-2607</text>
      <text x="100" y="610" fill="#475569" font-size="16" font-family="Arial, sans-serif">Best Before 18 Months from Packing Date</text>

      <!-- Consumer Care & Origin -->
      <rect x="80" y="650" width="740" height="110" rx="8" fill="#f1f5f9"/>
      <text x="100" y="682" fill="#0f172a" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Customer Care Desk:</text>
      <text x="100" y="710" fill="#334155" font-size="15" font-family="Arial, sans-serif">Phone: 0124-4908800 | Email: care@naturepure.in</text>
      <text x="100" y="740" fill="#0369a1" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Country of Origin: India</text>

      <text x="450" y="810" fill="#94a3b8" font-size="12" font-family="monospace" text-anchor="middle">LEGAL METROLOGY (PACKAGED COMMODITIES) RULES, 2011</text>
    </svg>`
  },
  {
    id: 'sample-shampoo',
    fileName: 'keval_herbal_shampoo.png',
    title: 'Keval Herbal Anti-Dandruff Shampoo 350ml',
    category: 'Personal Care / Cosmetics',
    description: 'Keval Herbal Cosmetics shampoo bottle label with complete statutory details.',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="900" viewBox="0 0 900 900">
      <defs>
        <linearGradient id="bgShampoo" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#064e3b"/>
          <stop offset="100%" stop-color="#022c22"/>
        </linearGradient>
      </defs>
      <rect width="900" height="900" rx="24" fill="url(#bgShampoo)" stroke="#047857" stroke-width="4"/>
      
      <!-- Brand & Product Header -->
      <text x="450" y="100" fill="#6ee7b7" font-size="44" font-weight="900" font-family="Arial, sans-serif" text-anchor="middle">KEVAL HERBALS</text>
      <text x="450" y="150" fill="#ffffff" font-size="28" font-weight="bold" font-family="Arial, sans-serif" text-anchor="middle">Anti-Dandruff Neem &amp; Aloe Vera Shampoo</text>

      <!-- Principal Display Declarations Panel -->
      <rect x="50" y="190" width="800" height="660" rx="16" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
      
      <rect x="80" y="220" width="740" height="50" rx="8" fill="#ecfdf5"/>
      <text x="100" y="254" fill="#065f46" font-size="24" font-weight="bold" font-family="Arial, sans-serif">Commodity: Cosmetic / Hair Cleanser</text>

      <rect x="80" y="290" width="740" height="60" rx="8" fill="#f0fdf4" stroke="#86efac" stroke-width="1.5"/>
      <text x="100" y="330" fill="#166534" font-size="26" font-weight="bold" font-family="Arial, sans-serif">Net Volume: 350 ml</text>

      <rect x="80" y="370" width="740" height="70" rx="8" fill="#fef2f2" stroke="#fca5a5" stroke-width="1.5"/>
      <text x="100" y="408" fill="#991b1b" font-size="25" font-weight="bold" font-family="Arial, sans-serif">MRP ₹ 245.00 (Incl. of all taxes)</text>
      <text x="100" y="432" fill="#7f1d1d" font-size="16" font-family="Arial, sans-serif">Unit Sale Price: ₹ 0.70 / ml</text>

      <!-- Manufacturer & Address -->
      <text x="80" y="480" fill="#0f172a" font-size="18" font-weight="bold" font-family="Arial, sans-serif">Manufactured &amp; Marketed by:</text>
      <text x="80" y="510" fill="#334155" font-size="16" font-family="Arial, sans-serif">Keval Personal Care Products Ltd., EPIP Industrial Area, Phase-II, Baddi, Solan, HP - 173205</text>

      <!-- Dates & Batch -->
      <rect x="80" y="540" width="740" height="90" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1"/>
      <text x="100" y="575" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Date of Mfg: 05/2026</text>
      <text x="500" y="575" fill="#1e293b" font-size="17" font-weight="bold" font-family="Arial, sans-serif">Batch No: KV-SH-2026-104</text>
      <text x="100" y="610" fill="#475569" font-size="16" font-family="Arial, sans-serif">Use Before 24 Months from Mfd Date</text>

      <!-- Consumer Care & Origin -->
      <rect x="80" y="650" width="740" height="110" rx="8" fill="#f1f5f9"/>
      <text x="100" y="682" fill="#0f172a" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Consumer Care Cell:</text>
      <text x="100" y="710" fill="#334155" font-size="15" font-family="Arial, sans-serif">Toll Free: 1800-419-5522 | Email: help@kevalherbals.com</text>
      <text x="100" y="740" fill="#0369a1" font-size="16" font-weight="bold" font-family="Arial, sans-serif">Country of Origin: India</text>

      <text x="450" y="810" fill="#94a3b8" font-size="12" font-family="monospace" text-anchor="middle">LEGAL METROLOGY (PACKAGED COMMODITIES) RULES, 2011</text>
    </svg>`
  }
];

export async function generateSampleAssets() {
  console.log('[samples] Generating high-resolution sample packaging images...');
  for (const s of samples) {
    const pngBuffer = await sharp(Buffer.from(s.svg)).png().toBuffer();
    
    // Save in server uploads
    const serverPath = path.join(SERVER_SAMPLES_DIR, s.fileName);
    fs.writeFileSync(serverPath, pngBuffer);

    // Save in client public
    const clientPath = path.join(CLIENT_SAMPLES_DIR, s.fileName);
    fs.writeFileSync(clientPath, pngBuffer);

    console.log(`  ✓ Generated ${s.fileName} (${pngBuffer.length} bytes)`);
  }
  console.log('[samples] All sample package assets generated successfully.');
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  generateSampleAssets().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
}

export { samples };
export default generateSampleAssets;
