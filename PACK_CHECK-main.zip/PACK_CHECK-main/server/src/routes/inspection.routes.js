import express from 'express';
import { getInspections, getInspectionById, createInspection, downloadInspectionPdfReport } from '../controllers/inspection.controller.js';
import { optionalAuth } from '../middleware/auth.middleware.js';
import { upload } from '../middleware/upload.middleware.js';

const router = express.Router();

// Both authenticated inspectors and public demo users can analyze packaging images
router.use(optionalAuth);

router.get('/', getInspections);
router.get('/:id', getInspectionById);
router.get('/:id/report/pdf', downloadInspectionPdfReport);
router.get('/:id/report', downloadInspectionPdfReport);

// Accept multipart/form-data with image file or JSON body
router.post('/analyze', upload.array('images', 10), createInspection);
router.post('/', upload.array('images', 10), createInspection);

export default router;
