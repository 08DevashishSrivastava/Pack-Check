import express from 'express';
import fs from 'fs/promises';
import { upload } from '../middleware/upload.middleware.js';
import { requireAuth } from '../middleware/auth.middleware.js';
import { analyzeImage } from '../services/geminiVision.service.js';

const router = express.Router();
router.use(requireAuth);

router.post('/test-image', upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, code: 'IMAGE_REQUIRED', message: 'An image file is required.' });
  try {
    const analysis = await analyzeImage({ filePath: req.file.path, mimeType: req.file.mimetype });
    return res.json({
      provider: analysis.provider,
      model: analysis.model,
      analysis_status: analysis.analysis_status,
      fields: analysis.fields,
      detected_text_regions: analysis.text_regions
    });
  } catch (error) {
    console.error('[GEMINI] test image failed:', error.message);
    return res.status(502).json({ success: false, code: 'GEMINI_ANALYSIS_FAILED', message: error.message });
  } finally {
    await fs.unlink(req.file.path).catch(() => {});
  }
});

export default router;
