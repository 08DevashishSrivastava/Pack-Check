import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const REGISTRY_PATH = path.join(__dirname, 'rule_registry.json');
let ruleRegistry = null;

export function getRuleRegistry() {
  if (!ruleRegistry) {
    const raw = fs.readFileSync(REGISTRY_PATH, 'utf-8');
    ruleRegistry = JSON.parse(raw);
  }
  return ruleRegistry;
}

const STATUTORY_DISCLAIMER = 'AI-assisted screening result — not a legally binding determination. Final legal determination remains with the competent authority / authorized inspector.';

/**
 * Evaluate structured fields extracted by Gemini Vision against the Legal Metrology Rule Registry.
 *
 * @param {Object} extractedFields - Normalized dictionary of extracted fields from geminiVision.service.js
 * @param {Object} rawGeminiResponse - Full Gemini response with text regions, product info, quality
 * @param {string} imageId - Image identifier
 * @returns {Object} Comprehensive evaluation result
 */
export function evaluateLegalMetrologyCompliance(extractedFields, rawGeminiResponse = {}, imageId = 'img-1') {
  const registry = getRuleRegistry();
  const rules = registry.rules || [];

  const declarations = [];
  const complianceResults = [];
  const violations = [];

  let passedCount = 0;
  let failedCount = 0;
  let warningCount = 0;

  const hasAnyText = rawGeminiResponse.analysis_status !== 'NO_TEXT_DETECTED' &&
    (rawGeminiResponse.text_regions?.length > 0 || (rawGeminiResponse.full_text && rawGeminiResponse.full_text.trim().length > 0));

  for (const rule of rules) {
    const fieldKey = rule.gemini_field;
    const fieldData = extractedFields[fieldKey] || extractedFields[rule.field] || {};

    const rawValue = fieldData.value ? String(fieldData.value).trim() : null;
    const isDetected = Boolean(rawValue && rawValue.length > 0 && fieldData.status !== 'NOT_DETECTED');
    const confidence = isDetected && typeof fieldData.confidence === 'number' ? Number(fieldData.confidence.toFixed(2)) : (isDetected ? 0.90 : null);
    const bbox = isDetected ? fieldData.bbox : null;

    // 1. Build standardized declaration item
    if (rule.field !== 'Numeral Height & Display Area') {
      declarations.push({
        id: `decl-${rule.id}`,
        rule_code: rule.rule_code,
        field: rule.field,
        value: isDetected ? rawValue : 'Not reliably detected',
        confidence: confidence,
        status: isDetected ? (fieldData.status || 'DETECTED') : 'NOT_DETECTED',
        image_id: imageId,
        bbox: bbox,
        legal_reference: rule.legal_reference
      });
    }

    // 2. Evaluate compliance per rule check type
    let ruleStatus = 'GREEN'; // GREEN | RED | AMBER
    let observedValue = rawValue;
    let failureReason = null;
    let recommendation = rule.recommendation;
    let severity = rule.severity || 'MEDIUM';

    if (rule.check_type === 'SCALE_AWARE') {
      // Schedule II font height: never invent fake millimeter measurements
      ruleStatus = 'AMBER';
      observedValue = 'Physical scale absent in 2D image';
      failureReason = 'Visual inspection cannot reliably establish the physical numeral height in millimetres from a 2D photograph without calibrated physical scale.';
      recommendation = 'Inspector must perform physical numeral height verification on-site with an optical scale gauge.';
      warningCount++;
    } else if (!hasAnyText) {
      // No text at all on image
      ruleStatus = 'AMBER';
      observedValue = 'No readable text identified';
      failureReason = 'Image quality or angle does not reveal readable package declarations.';
      recommendation = 'Retake a clear, high-resolution photograph of the packaging principal display panel.';
      warningCount++;
    } else if (!isDetected) {
      // Field is missing from a package where other text was detected
      if (rule.severity === 'HIGH') {
        ruleStatus = 'RED';
        observedValue = 'No reliable declaration detected';
        failureReason = rule.failure_reason || `Mandatory declaration "${rule.field}" not detected on the package.`;
        failedCount++;
      } else {
        ruleStatus = 'AMBER';
        observedValue = 'Not reliably detected';
        failureReason = rule.failure_reason || `Declaration "${rule.field}" was not detected. Verify if applicable for this specific commodity.`;
        warningCount++;
      }
    } else {
      // Field was detected — run contextual semantic checks
      if (rule.check_type === 'MRP_TAX_INCLUSIVE') {
        const lowerVal = rawValue.toLowerCase();
        const hasTaxMention = lowerVal.includes('incl') || lowerVal.includes('tax') || lowerVal.includes('all taxes');
        if (!hasTaxMention) {
          ruleStatus = 'AMBER';
          observedValue = rawValue;
          failureReason = 'MRP detected but statutory tax-inclusive phrase ("Incl. of all taxes") should be confirmed on the label.';
          recommendation = 'Ensure "Inclusive of all taxes" is explicitly stated alongside MRP as per Rule 6(1)(e).';
          warningCount++;
        } else {
          ruleStatus = 'GREEN';
          passedCount++;
        }
      } else if (rule.check_type === 'STANDARD_UNIT') {
        const lowerVal = rawValue.toLowerCase();
        const hasUnit = /\b(g|gm|gms|gram|grams|kg|ml|l|ltr|litre|litres|n|pcs|pieces|count|units)\b/i.test(lowerVal);
        if (!hasUnit) {
          ruleStatus = 'AMBER';
          observedValue = rawValue;
          failureReason = 'Net quantity value detected without standard metric unit of measurement.';
          recommendation = 'Ensure net quantity uses standard metric units (g, kg, ml, L, count) as required by Rule 6(1)(b).';
          warningCount++;
        } else {
          ruleStatus = 'GREEN';
          passedCount++;
        }
      } else {
        ruleStatus = 'GREEN';
        passedCount++;
      }
    }

    const finding = {
      id: `viol-${rule.id}`,
      rule_id: rule.id,
      rule_code: rule.rule_code,
      title: rule.title,
      field: rule.field,
      status: ruleStatus,
      severity: severity,
      observed_value: observedValue,
      expected_condition: rule.expected_condition,
      legal_reference: rule.legal_reference,
      reason: failureReason || 'Mandatory declaration requirement satisfied.',
      confidence: confidence || (ruleStatus === 'GREEN' ? 0.92 : 0.85),
      recommendation: recommendation,
      image_id: imageId,
      bbox: bbox
    };

    complianceResults.push(finding);

    // If RED or AMBER with an issue, add to violations list for UI highlight
    if (ruleStatus === 'RED' || (ruleStatus === 'AMBER' && rule.severity === 'HIGH')) {
      violations.push({
        id: `v-${rule.id}`,
        rule_code: rule.rule_code,
        title: `${ruleStatus === 'RED' ? 'Missing / Non-Compliant' : 'Review Required'}: ${rule.field}`,
        severity: severity,
        status: ruleStatus === 'RED' ? 'NON_COMPLIANT' : 'NEEDS_REVIEW',
        detected_value: observedValue,
        expected_condition: rule.expected_condition,
        confidence: confidence,
        recommendation: recommendation,
        legal_reference: rule.legal_reference,
        image_id: imageId,
        bbox: bbox
      });
    }
  }

  // Compute deterministic AI-assisted screening score:
  // Starts at 100. -16 for each RED failure, -5 for each AMBER warning.
  const computedScore = hasAnyText
    ? Math.max(0, Math.min(100, Math.round(100 - (failedCount * 16) - (warningCount * 5))))
    : 0;

  const overallStatus = failedCount > 0
    ? 'NON_COMPLIANT'
    : (warningCount > 0 || !hasAnyText ? 'NEEDS_REVIEW' : 'COMPLIANT');

  return {
    rule_registry_version: registry.version,
    rule_registry_authority: registry.authority,
    disclaimer: STATUTORY_DISCLAIMER,
    status: overallStatus,
    score: computedScore,
    passed_rules: passedCount,
    failed_rules: failedCount,
    warning_rules: warningCount,
    total_declarations: declarations.length,
    declarations,
    compliance_results: complianceResults,
    violations
  };
}

export default {
  getRuleRegistry,
  evaluateLegalMetrologyCompliance
};
