import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { v4 as uuidv4 } from 'uuid';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const UPLOADS_BASE = path.resolve(__dirname, '../../uploads/inspections');

// Ensure base directory exists
if (!fs.existsSync(UPLOADS_BASE)) {
  fs.mkdirSync(UPLOADS_BASE, { recursive: true });
}

// Allowed image MIME types
const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/gif'
]);

// Disk storage engine: files go into uploads/inspections/<temp>/
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Store in a temp folder first; the controller moves them to inspection-specific dirs
    const tempDir = path.join(UPLOADS_BASE, '_temp');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    cb(null, tempDir);
  },
  filename: (req, file, cb) => {
    // Safe filename: <faceType>-<uuid>.<ext>  (no user-controlled name)
    const ext = path.extname(file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '');
    const safeExt = ['.jpg', '.jpeg', '.png', '.webp', '.gif'].includes(ext) ? ext : '.jpg';
    const faceType = (req.body?.faceType || 'photo').toLowerCase().replace(/[^a-z0-9]/g, '');
    const id = uuidv4().substring(0, 8);
    cb(null, `${faceType}-${id}${safeExt}`);
  }
});

// File filter: reject non-image MIME types
const fileFilter = (req, file, cb) => {
  if (ALLOWED_MIME_TYPES.has(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error(`Unsupported file type: ${file.mimetype}. Only JPEG, PNG, WebP images are accepted.`));
  }
};

export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 15 * 1024 * 1024, // 15MB max per file
    files: 10                    // max 10 files per request
  }
});

// Helper: move uploaded file from temp dir to inspection-specific directory
export const moveToInspectionDir = (tempFilePath, inspectionId, originalFilename) => {
  const inspDir = path.join(UPLOADS_BASE, inspectionId);
  if (!fs.existsSync(inspDir)) fs.mkdirSync(inspDir, { recursive: true });

  const finalPath = path.join(inspDir, originalFilename);
  fs.renameSync(tempFilePath, finalPath);
  return `/uploads/inspections/${inspectionId}/${originalFilename}`;
};

// Helper: clean up temp directory files older than 1 hour
export const cleanTempDir = () => {
  const tempDir = path.join(UPLOADS_BASE, '_temp');
  if (!fs.existsSync(tempDir)) return;
  const now = Date.now();
  const files = fs.readdirSync(tempDir);
  files.forEach(file => {
    const filePath = path.join(tempDir, file);
    const stat = fs.statSync(filePath);
    if (now - stat.mtimeMs > 3600000) {
      fs.unlinkSync(filePath);
    }
  });
};

export default upload;
