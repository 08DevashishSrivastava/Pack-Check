import fs from 'fs/promises';
import path from 'path';
import { GoogleGenAI } from '@google/genai';

const MODEL = process.env.GEMINI_MODEL || 'gemini-3.6-flash';

const PROMPT = `You are an expert Legal Metrology compliance vision engine for inspecting packaged commodities in India.

Analyze ONLY the supplied packaging/product image.
Extract strictly what is visually present in the image.
1. Identify the exact product name, brand, commodity category, and net quantity claimed directly on the package.
2. NEVER invent, infer, assume, or hallucinate missing declarations.
3. If an image shows "Parle-G", the product name MUST be Parle-G. If it shows chocolate, shampoo, honey, or flour, output THAT exact commodity.
4. If a declaration (MRP, Mfg Date, Net Qty, Consumer Care, Origin, Packer) is NOT visually readable in the image, set value to null and status to NOT_DETECTED.
5. If text is blurry or partially obscured, mark status as LOW_CONFIDENCE or REVIEW_REQUIRED.
6. The filename or external assumptions are NOT evidence. Only the visual pixels are evidence.
7. For every detected declaration and text region, provide the bounding box as [ymin, xmin, ymax, xmax] normalized to 0-1000.
8. DO NOT invent fake physical millimeter font measurements (e.g. 2.1mm, 3.0mm) as a 2D photograph lacks physical calibration.

Return JSON in this structure:
{
  "product_identity": {
    "product_name": "string or null",
    "brand_name": "string or null",
    "commodity_category": "string or null",
    "package_size": "string or null"
  },
  "declarations": {
    "product_name": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "net_quantity": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "mrp": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "unit_sale_price": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "manufacturer": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "manufacturer_address": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "manufacturing_date": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "expiry_date": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "batch_number": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "consumer_care": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] },
    "country_of_origin": { "value": "string or null", "status": "DETECTED|NOT_DETECTED|REVIEW_REQUIRED", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] }
  },
  "text_regions": [
    { "text": "string", "confidence": 0.95, "box_2d": [ymin, xmin, ymax, xmax] }
  ]
}`;

function validNormalizedBox(box) {
  return Array.isArray(box) && box.length === 4 && box.every(Number.isFinite)
    && box.every(value => value >= 0 && value <= 1000)
    && box[0] < box[2] && box[1] < box[3];
}

function toPixelBox(box, width, height) {
  if (!validNormalizedBox(box)) return null;
  return {
    x: Math.round((box[1] / 1000) * width),
    y: Math.round((box[0] / 1000) * height),
    width: Math.round(((box[3] - box[1]) / 1000) * width),
    height: Math.round(((box[2] - box[0]) / 1000) * height)
  };
}

function extractBox(obj, width, height) {
  if (!obj) return null;
  const boxArray = obj.box_2d || obj.bbox || (Array.isArray(obj) ? obj : null);
  if (boxArray && validNormalizedBox(boxArray)) {
    return toPixelBox(boxArray, width, height);
  }
  return null;
}

function normalizeFieldValue(rawField, width, height) {
  if (!rawField) {
    return { value: null, status: 'NOT_DETECTED', confidence: null, bbox: null };
  }

  // If rawField is a simple string/number
  if (typeof rawField === 'string' || typeof rawField === 'number') {
    const valStr = String(rawField).trim();
    return {
      value: valStr.length > 0 ? valStr : null,
      status: valStr.length > 0 ? 'DETECTED' : 'NOT_DETECTED',
      confidence: valStr.length > 0 ? 0.93 : null,
      bbox: null
    };
  }

  // If rawField is an object
  if (typeof rawField === 'object') {
    let value = null;
    if (typeof rawField.value === 'string') {
      value = rawField.value.trim();
    } else if (typeof rawField.text === 'string') {
      value = rawField.text.trim();
    } else if (rawField.toll_free || rawField.email) {
      value = [rawField.toll_free, rawField.email].filter(Boolean).join(' | ');
    }

    const isPresent = Boolean(value && value.length > 0);
    const confidence = isPresent
      ? (typeof rawField.confidence === 'number' ? rawField.confidence : 0.92)
      : null;
    const bbox = isPresent ? extractBox(rawField, width, height) : null;
    const status = isPresent ? (rawField.status || 'DETECTED') : 'NOT_DETECTED';

    return {
      value: isPresent ? value : null,
      status: status,
      confidence: confidence,
      bbox: bbox
    };
  }

  return { value: null, status: 'NOT_DETECTED', confidence: null, bbox: null };
}

function normalizeResponse(raw, width, height) {
  const rawDecl = raw.declarations || raw.fields || {};
  const rawProd = raw.product_identity || raw.product || {};

  // Standardized fields map
  const fields = {
    product_name: normalizeFieldValue(rawDecl.product_name || rawDecl.commodity || rawProd.product_name, width, height),
    brand: normalizeFieldValue(rawDecl.brand || rawProd.brand_name || rawProd.brand, width, height),
    category: normalizeFieldValue(rawDecl.category || rawProd.commodity_category, width, height),
    net_quantity: normalizeFieldValue(rawDecl.net_quantity || rawDecl.net_weight || rawDecl.weight, width, height),
    mrp: normalizeFieldValue(rawDecl.mrp || rawDecl.price, width, height),
    unit_sale_price: normalizeFieldValue(rawDecl.unit_sale_price || rawDecl.usp, width, height),
    manufacturer: normalizeFieldValue(rawDecl.manufacturer || rawDecl.manufactured_and_packed_by || rawDecl.packer, width, height),
    manufacturer_address: normalizeFieldValue(rawDecl.manufacturer_address || rawDecl.address, width, height),
    manufacturing_date: normalizeFieldValue(rawDecl.manufacturing_date || rawDecl.date_of_mfd_pkd || rawDecl.mfg_date, width, height),
    packing_date: normalizeFieldValue(rawDecl.packing_date || rawDecl.date_of_packing, width, height),
    expiry_date: normalizeFieldValue(rawDecl.expiry_date || rawDecl.best_before || rawDecl.use_by, width, height),
    batch_number: normalizeFieldValue(rawDecl.batch_number || rawDecl.batch_no || rawDecl.lot_number, width, height),
    consumer_care: normalizeFieldValue(rawDecl.consumer_care || rawDecl.consumer_care_cell || rawDecl.customer_care, width, height),
    country_of_origin: normalizeFieldValue(rawDecl.country_of_origin || rawDecl.origin, width, height)
  };

  // Extract text regions
  const rawRegions = raw.text_regions || raw.detected_text_regions || [];
  const textRegions = Array.isArray(rawRegions)
    ? rawRegions.flatMap(region => {
      const text = typeof region?.text === 'string' ? region.text.trim() : '';
      const confidence = typeof region?.confidence === 'number' ? region.confidence : 0.90;
      const bbox = text ? extractBox(region, width, height) : null;
      return text && bbox ? [{ text, confidence, bbox }] : [];
    })
    : [];

  const hasText = textRegions.length > 0 || Object.values(fields).some(f => f.value !== null);

  // Derive consolidated product info
  const productName = rawProd.product_name || fields.product_name.value || 'Packaged Commodity';
  const brandName = rawProd.brand_name || rawProd.brand || fields.brand.value || null;
  const commodityCategory = rawProd.commodity_category || fields.category.value || 'Food & Beverages';
  const packageSize = rawProd.package_size || fields.net_quantity.value || null;

  return {
    provider: 'gemini',
    model: MODEL,
    analysis_status: hasText ? 'SUCCESS' : 'NO_TEXT_DETECTED',
    product: {
      name: brandName && productName && !productName.toLowerCase().includes(brandName.toLowerCase())
        ? `${brandName} ${productName}`
        : (productName || 'Packaged Commodity'),
      brand: brandName,
      category: commodityCategory,
      package_size: packageSize
    },
    image: { width, height },
    text_regions: textRegions,
    fields,
    quality: {
      readable: hasText,
      reason: hasText ? null : 'No readable text detected in package image.'
    },
    full_text: textRegions.map(r => r.text).join('\n'),
    errors: []
  };
}

export async function analyzeImage({ filePath, buffer, mimeType }) {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is not configured on the server. Please check .env file.');
  }

  const resolvedMime = mimeType || 'image/png';
  const imageBuffer = buffer || await fs.readFile(filePath);

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  console.log(`[GEMINI] Sending image to model ${MODEL} (size=${imageBuffer.length} bytes, mime=${resolvedMime})...`);

  const response = await ai.models.generateContent({
    model: MODEL,
    contents: [
      { text: PROMPT },
      { inlineData: { mimeType: resolvedMime, data: imageBuffer.toString('base64') } }
    ],
    config: {
      responseMimeType: 'application/json',
      temperature: 0.1
    }
  });

  let raw;
  try {
    raw = JSON.parse(response.text);
  } catch (err) {
    console.error('[GEMINI] Malformed JSON response:', response.text);
    throw new Error('Gemini returned malformed structured JSON response.');
  }

  const dimensions = await import('sharp').then(module => module.default(imageBuffer).metadata());
  const imgWidth = dimensions.width || 900;
  const imgHeight = dimensions.height || 900;

  return normalizeResponse(raw, imgWidth, imgHeight);
}

export function normalizeStoredAnalysis(value) {
  try { return typeof value === 'string' ? JSON.parse(value) : value; } catch { return null; }
}

export { MODEL, toPixelBox };
export default { analyzeImage, normalizeStoredAnalysis, MODEL, toPixelBox };
