import PDFDocument from 'pdfkit';

/**
 * Generates an official PackCheck Legal Metrology Compliance Inspection Audit Notice PDF.
 *
 * @param {Object} inspectionData - Full inspection details including declarations, violations, and inspector metadata.
 * @returns {Promise<Buffer>} - Resolves with the generated PDF Buffer.
 */
export const generateInspectionPdf = (inspectionData) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margin: 40,
        info: {
          Title: `PackCheck Audit Notice - ${inspectionData.id}`,
          Author: 'PackCheck Legal Metrology Enforcement Platform',
          Subject: `Compliance Inspection Report for ${inspectionData.product_name || 'Packaged Commodity'}`
        }
      });

      const buffers = [];
      doc.on('data', (chunk) => buffers.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(buffers)));
      doc.on('error', (err) => reject(err));

      const primaryBlue = '#1e3a8a';
      const slateDark = '#0f172a';
      const slateMuted = '#475569';
      const dangerRed = '#b91c1c';
      const warningAmber = '#b45309';
      const successGreen = '#047857';

      // ── Top Header Banner ──────────────────────────────────────────────────
      doc.rect(40, 40, 515, 65).fill(primaryBlue);

      doc.fillColor('#ffffff').fontSize(16).font('Helvetica-Bold')
         .text('PackCheck', 55, 52);

      doc.fontSize(10).font('Helvetica')
         .text('LEGAL METROLOGY COMPLIANCE AUDIT NOTICE', 55, 72);

      doc.fontSize(8).font('Helvetica-Oblique')
         .text('Packaged Commodities Rules, 2011 Enforcement Platform', 55, 87);

      // Right-aligned header badge
      doc.fontSize(9).font('Helvetica-Bold')
         .text(`RECORD: ${inspectionData.id}`, 360, 55, { align: 'right', width: 180 });
      doc.fontSize(8).font('Helvetica')
         .text(`Date: ${new Date(inspectionData.inspection_date || inspectionData.created_at || Date.now()).toLocaleDateString('en-IN')}`, 360, 70, { align: 'right', width: 180 });
      doc.text(`Rule Version: ${inspectionData.rule_registry_version || 'LM-PC-2026.08'}`, 360, 84, { align: 'right', width: 180 });

      doc.moveDown(3);

      let currentY = 120;

      // ── Commodity & Inspection Summary Box ────────────────────────────────
      doc.rect(40, currentY, 515, 80).fillAndStroke('#f8fafc', '#cbd5e1');

      doc.fillColor(slateDark).fontSize(9).font('Helvetica-Bold')
         .text('COMMODITY PARTICULARS & INSPECTION METADATA', 55, currentY + 10);

      doc.fontSize(8).font('Helvetica');
      doc.text(`Product Name:`, 55, currentY + 28).font('Helvetica-Bold').text(inspectionData.product_name || 'N/A', 130, currentY + 28);
      doc.font('Helvetica').text(`Brand:`, 55, currentY + 42).font('Helvetica-Bold').text(inspectionData.brand || 'N/A', 130, currentY + 42);
      doc.font('Helvetica').text(`Category:`, 55, currentY + 56).font('Helvetica-Bold').text(inspectionData.category || 'General', 130, currentY + 56);

      doc.font('Helvetica').text(`Auditing Inspector:`, 310, currentY + 28).font('Helvetica-Bold').text(inspectionData.inspector_name || 'Duty Inspector', 405, currentY + 28);
      doc.font('Helvetica').text(`Compliance Score:`, 310, currentY + 42).font('Helvetica-Bold').text(`${inspectionData.score || 0}%`, 405, currentY + 42);

      const statusColor = (inspectionData.status === 'COMPLIANT') ? successGreen : dangerRed;
      doc.font('Helvetica').text(`Screening Status:`, 310, currentY + 56).font('Helvetica-Bold').fillColor(statusColor).text(inspectionData.status || 'UNDER_REVIEW', 405, currentY + 56);

      currentY += 95;

      // ── Statutory Infractions / Violations Section ──────────────────────────
      const violations = inspectionData.violations || [];
      doc.fillColor(slateDark).fontSize(10).font('Helvetica-Bold')
         .text(`STATUTORY INFRACTIONS & NON-CONFORMITIES (${violations.length})`, 40, currentY);
      
      currentY += 16;

      if (violations.length === 0) {
        doc.rect(40, currentY, 515, 28).fillAndStroke('#ecfdf5', '#a7f3d0');
        doc.fillColor(successGreen).fontSize(8.5).font('Helvetica-Bold')
           .text('✓ All applicable mandatory declarations and Legal Metrology standards are satisfied.', 55, currentY + 9);
        currentY += 38;
      } else {
        violations.slice(0, 5).forEach((v, idx) => {
          const cardHeight = 44;
          doc.rect(40, currentY, 515, cardHeight).fillAndStroke('#fef2f2', '#fecaca');

          doc.fillColor(dangerRed).fontSize(8.5).font('Helvetica-Bold')
             .text(`${idx + 1}. ${v.title || v.rule_code}`, 50, currentY + 6);

          doc.fillColor(slateMuted).fontSize(7.5).font('Helvetica')
             .text(`Observed: ${v.detected_value || 'Not detected on packaging surface'}`, 50, currentY + 18)
             .text(`Statutory Requirement: ${v.expected_condition || 'Mandatory under Rule 6'}`, 50, currentY + 28);

          doc.fillColor(primaryBlue).fontSize(7.5).font('Helvetica-Bold')
             .text(`Action: ${v.recommendation || 'Rectify packaging label'}`, 310, currentY + 18, { width: 235 });

          currentY += cardHeight + 6;
        });
        currentY += 6;
      }

      // ── Extracted Mandatory Declarations (Rule 6) Table ───────────────────
      const declarations = inspectionData.declarations || [];
      if (declarations.length > 0) {
        doc.fillColor(slateDark).fontSize(10).font('Helvetica-Bold')
           .text('EXTRACTED MANDATORY DECLARATIONS (RULE 6)', 40, currentY);

        currentY += 15;

        // Table Header
        doc.rect(40, currentY, 515, 18).fill('#f1f5f9');
        doc.fillColor(slateDark).fontSize(8).font('Helvetica-Bold')
           .text('Declaration Field', 50, currentY + 5)
           .text('Observed Value', 200, currentY + 5)
           .text('Confidence', 400, currentY + 5)
           .text('Status', 480, currentY + 5);

        currentY += 18;

        // Table Rows
        declarations.slice(0, 8).forEach((d) => {
          doc.rect(40, currentY, 515, 16).fillAndStroke('#ffffff', '#e2e8f0');
          doc.fillColor(slateDark).fontSize(7.5).font('Helvetica')
             .text(d.field || 'Field', 50, currentY + 4, { width: 140 })
             .text((d.value || 'Not detected').slice(0, 42), 200, currentY + 4, { width: 190 })
             .text(d.confidence ? `${Math.round(d.confidence * 100)}%` : '—', 400, currentY + 4)
             .font('Helvetica-Bold')
             .fillColor(d.status === 'COMPLIANT' || d.status === 'DETECTED' ? successGreen : (d.status === 'WARNING' ? warningAmber : dangerRed))
             .text(d.status || 'N/A', 480, currentY + 4);

          currentY += 16;
        });

        currentY += 12;
      }

      // ── Statutory Disclaimer & Seal ───────────────────────────────────────
      doc.rect(40, currentY, 515, 32).fillAndStroke('#fffbeb', '#fde68a');
      doc.fillColor(warningAmber).fontSize(7).font('Helvetica')
         .text('DISCLAIMER: This electronic document is generated by the PackCheck AI-assisted Legal Metrology screening system. Findings serve as an enforcement aid and require verification by an authorized Inspector of Legal Metrology prior to final adjudication under the Legal Metrology Act, 2009.', 50, currentY + 6, { width: 495 });

      currentY += 45;

      // ── Official Signatures ───────────────────────────────────────────────
      doc.fillColor(slateDark).fontSize(8).font('Helvetica-Bold')
         .text('Legal Metrology Inspectorate', 40, currentY)
         .font('Helvetica').fontSize(7.5).text('Enforcement & Quality Assurance Division', 40, currentY + 12);

      doc.font('Helvetica-Bold').fontSize(8)
         .text('Officer Verification', 420, currentY, { align: 'right' })
         .font('Helvetica').fontSize(7.5).fillColor(primaryBlue)
         .text('VERIFIED ELECTRONICALLY', 420, currentY + 12, { align: 'right' });

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
};

export default {
  generateInspectionPdf
};
