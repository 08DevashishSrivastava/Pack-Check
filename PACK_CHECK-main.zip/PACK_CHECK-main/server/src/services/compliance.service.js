/**
 * compliance.service.js
 * Legal Metrology compliance engine service.
 * Evaluates extracted fields against authoritative Legal Metrology Packaged Commodities rules (LM-PC-2026.08).
 */

import { query } from '../config/db.js';
import { getRuleRegistry, evaluateLegalMetrologyCompliance } from '../compliance/complianceEngine.js';

export async function seedLegalRulesIfEmpty() {
  try {
    const registry = getRuleRegistry();
    const rows = await query('SELECT COUNT(*) as count FROM legal_rules');
    const count = Number(rows[0]?.count || 0);

    if (count === 0 && registry.rules) {
      console.log(`[compliance] Seeding ${registry.rules.length} authoritative rules from registry (${registry.version})...`);
      for (const rule of registry.rules) {
        await query(
          `INSERT IGNORE INTO legal_rules (id, rule_code, rule_name, legal_reference, category, field, description, severity, check_type, expected_value, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
          [
            rule.id,
            rule.rule_code,
            rule.title,
            rule.legal_reference,
            rule.category,
            rule.field,
            rule.description,
            rule.severity,
            rule.check_type,
            null
          ]
        );
      }
      console.log('[compliance] Authoritative Legal Metrology rules seeded successfully.');
    }
  } catch (err) {
    console.error('[compliance] Could not seed legal_rules:', err.message);
  }
}

/**
 * Main compliance evaluation function.
 * @param {string} inspectionId
 * @param {string} firstImageId
 * @param {Object} extractedFields
 * @param {Object} rawGeminiResponse
 * @returns {Object} { declarations, violations, compliance_results, score, status, passed, failed, warnings, disclaimer }
 */
export async function evaluateCompliance(inspectionId, firstImageId, extractedFields, rawGeminiResponse) {
  // Execute evaluation via complianceEngine
  const evaluation = evaluateLegalMetrologyCompliance(extractedFields, rawGeminiResponse, firstImageId);

  return {
    declarations: evaluation.declarations,
    violations: evaluation.violations,
    compliance_results: evaluation.compliance_results,
    score: evaluation.score,
    status: evaluation.status,
    passed: evaluation.passed_rules,
    failed: evaluation.failed_rules,
    warnings: evaluation.warning_rules,
    disclaimer: evaluation.disclaimer,
    rule_registry_version: evaluation.rule_registry_version
  };
}

export default {
  seedLegalRulesIfEmpty,
  evaluateCompliance
};
