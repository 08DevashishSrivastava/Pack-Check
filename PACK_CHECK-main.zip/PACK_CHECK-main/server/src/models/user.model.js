import { query, execute } from '../config/db.js';

export const UserModel = {
  findByEmail: async (email) => {
    if (!email) return null;
    const rows = await query('SELECT * FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1', [email.trim()]);
    return rows.length > 0 ? rows[0] : null;
  },

  findById: async (id) => {
    if (!id) return null;
    const rows = await query('SELECT * FROM users WHERE id = ? LIMIT 1', [id]);
    return rows.length > 0 ? rows[0] : null;
  },

  create: async (userData) => {
    const id = userData.id || `usr-${Date.now().toString(36)}`;
    const now = new Date();
    
    await execute(
      `INSERT INTO users (id, name, email, phone, department, password_hash, role, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        userData.name.trim(),
        userData.email.toLowerCase().trim(),
        userData.phone ? userData.phone.trim() : null,
        userData.department ? userData.department.trim() : 'Legal Metrology Enforcement',
        userData.password_hash,
        userData.role || 'INSPECTOR',
        now,
        now
      ]
    );

    return {
      id,
      name: userData.name.trim(),
      email: userData.email.toLowerCase().trim(),
      phone: userData.phone || '',
      department: userData.department || 'Legal Metrology Enforcement',
      role: userData.role || 'INSPECTOR',
      created_at: now.toISOString(),
      updated_at: now.toISOString()
    };
  }
};

export default UserModel;
