import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'metro_check',
  waitForConnections: true,
  connectionLimit: 15,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
};

// Create connection pool
export const pool = mysql.createPool(dbConfig);

// Helper for executing parameterized queries
export const query = async (sql, params = []) => {
  const [rows] = await pool.query(sql, params);
  return rows;
};

// Helper for executing parameterized statements
export const execute = async (sql, params = []) => {
  const [result] = await pool.execute(sql, params);
  return result;
};

// Helper for running queries in a managed transaction
export const transaction = async (callback) => {
  const connection = await pool.getConnection();
  await connection.beginTransaction();
  try {
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (err) {
    await connection.rollback();
    throw err;
  } finally {
    connection.release();
  }
};

// Health and connectivity verification helper
export const checkConnection = async () => {
  try {
    const [rows] = await pool.query('SELECT 1 as is_alive');
    return rows?.[0]?.is_alive === 1;
  } catch (error) {
    console.error('MySQL connection health check failed:', error.message);
    return false;
  }
};

// Graceful shutdown handling
process.on('SIGINT', async () => {
  console.log('\nClosing MySQL connection pool...');
  await pool.end();
  process.exit(0);
});

export default {
  pool,
  query,
  execute,
  transaction,
  checkConnection
};
