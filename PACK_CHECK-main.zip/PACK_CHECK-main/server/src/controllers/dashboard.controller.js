import { query } from '../config/db.js';

export const getDashboardStats = async (req, res) => {
  try {
    const userId = req.user?.id || null;

    // 1. Calculate Summary Counts from MySQL inspections table for this user
    let countSql = `
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'COMPLIANT' THEN 1 ELSE 0 END) as compliant,
        SUM(CASE WHEN status = 'NON_COMPLIANT' THEN 1 ELSE 0 END) as non_compliant,
        SUM(CASE WHEN status = 'NEEDS_REVIEW' THEN 1 ELSE 0 END) as needs_review
      FROM inspections
    `;
    const countParams = [];

    if (userId) {
      countSql += ' WHERE inspector_id = ?';
      countParams.push(userId);
    } else {
      countSql += ' WHERE inspector_id IS NULL OR inspector_name = "AI Screening Inspector" OR inspector_name = "Demo Inspector"';
    }

    const countRows = await query(countSql, countParams);

    const counts = countRows[0] || {};
    const total = Number(counts.total || 0);
    const compliant = Number(counts.compliant || 0);
    const nonCompliant = Number(counts.non_compliant || 0);
    const needsReview = Number(counts.needs_review || 0);
    const complianceRate = total > 0 ? Math.round((compliant / total) * 100) : 0;

    // 2. Fetch Violation Categories from MySQL violations table for this user's inspections
    let violationSql = `
      SELECT 
        CASE 
          WHEN v.rule_code LIKE '%NETQTY%' THEN 'Net Quantity / Numeral Height'
          WHEN v.rule_code LIKE '%USP%' THEN 'Unit Sale Price (USP)'
          WHEN v.rule_code LIKE '%MRP%' THEN 'MRP / Suffix Format'
          WHEN v.rule_code LIKE '%CARE%' OR v.rule_code LIKE '%CONSUMER%' THEN 'Consumer Care / Contact'
          WHEN v.rule_code LIKE '%DATE%' OR v.rule_code LIKE '%MFG%' THEN 'Date of Mfg / Packing Format'
          WHEN v.rule_code LIKE '%CONTRAST%' THEN 'Print Contrast & Legibility'
          ELSE 'General Mandatory Declarations'
        END as category,
        COUNT(*) as count
      FROM violations v
      JOIN inspections i ON i.id = v.inspection_id
    `;
    const violationParams = [];

    if (userId) {
      violationSql += ' WHERE i.inspector_id = ?';
      violationParams.push(userId);
    } else {
      violationSql += ' WHERE i.inspector_id IS NULL OR i.inspector_name = "AI Screening Inspector" OR i.inspector_name = "Demo Inspector"';
    }

    violationSql += ' GROUP BY 1 ORDER BY count DESC;';

    const violationRows = await query(violationSql, violationParams);

    const totalViolations = violationRows.reduce((acc, r) => acc + Number(r.count), 0);
    const violationCategories = violationRows.map(r => ({
      category: r.category,
      count: Number(r.count),
      percentage: totalViolations > 0 ? Math.round((Number(r.count) / totalViolations) * 100) : 0
    }));

    const displayViolationCategories = violationCategories.length > 0 ? violationCategories : [
      { category: 'Net Quantity / Numeral Height', count: 0, percentage: 0 },
      { category: 'Unit Sale Price (USP)', count: 0, percentage: 0 },
      { category: 'MRP / Suffix Format', count: 0, percentage: 0 },
      { category: 'Consumer Care / Contact', count: 0, percentage: 0 }
    ];

    // 3. Calculate Monthly Compliance Trend from MySQL inspections table for this user
    let trendSql = `
      SELECT 
        DATE_FORMAT(inspection_date, '%b') as month,
        DATE_FORMAT(inspection_date, '%Y-%m') as ym,
        COUNT(*) as inspections,
        SUM(CASE WHEN status = 'COMPLIANT' THEN 1 ELSE 0 END) as compliant,
        SUM(CASE WHEN status = 'NON_COMPLIANT' THEN 1 ELSE 0 END) as nonCompliant
      FROM inspections
    `;
    const trendParams = [];

    if (userId) {
      trendSql += ' WHERE inspector_id = ?';
      trendParams.push(userId);
    } else {
      trendSql += ' WHERE inspector_id IS NULL OR inspector_name = "AI Screening Inspector" OR inspector_name = "Demo Inspector"';
    }

    trendSql += ' GROUP BY ym, month ORDER BY ym ASC LIMIT 6;';

    const trendRows = await query(trendSql, trendParams);

    const complianceTrend = trendRows.map(r => ({
      month: r.month,
      inspections: Number(r.inspections),
      compliant: Number(r.compliant),
      nonCompliant: Number(r.nonCompliant)
    }));

    // For trend chart rendering when user has few or 0 inspections, show real user months or empty structure
    const displayTrend = complianceTrend.length > 0 ? complianceTrend : [
      { month: new Date().toLocaleString('default', { month: 'short' }), inspections: 0, compliant: 0, nonCompliant: 0 }
    ];

    // 4. Status Distribution
    const statusDistribution = [
      { name: 'Compliant', value: compliant, color: '#059669' },
      { name: 'Non-Compliant', value: nonCompliant, color: '#DC2626' },
      { name: 'Needs Review', value: needsReview, color: '#D97706' }
    ];

    // 5. Recent Inspections from MySQL for this user
    let recentSql = `
      SELECT id, product_name as product, brand, inspection_date as date, score, status, inspector_name as inspector
      FROM inspections
    `;
    const recentParams = [];

    if (userId) {
      recentSql += ' WHERE inspector_id = ?';
      recentParams.push(userId);
    } else {
      recentSql += ' WHERE inspector_id IS NULL OR inspector_name = "AI Screening Inspector" OR inspector_name = "Demo Inspector"';
    }

    recentSql += ' ORDER BY inspection_date DESC LIMIT 5;';

    const recentRows = await query(recentSql, recentParams);

    const recentInspections = recentRows.map(r => ({
      ...r,
      date: r.date ? new Date(r.date).toISOString() : new Date().toISOString()
    }));

    return res.status(200).json({
      success: true,
      data: {
        summary: {
          totalInspections: total,
          compliantCount: compliant,
          nonCompliantCount: nonCompliant,
          needsReviewCount: needsReview,
          complianceRate
        },
        violationCategories: displayViolationCategories,
        complianceTrend: displayTrend,
        statusDistribution,
        recentInspections
      }
    });
  } catch (error) {
    console.error('Dashboard stats MySQL error:', error);
    return res.status(500).json({ success: false, message: 'Failed to compute dashboard metrics from database.' });
  }
};
