import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import sharp from 'sharp';
import { query, transaction } from '../config/db.js';
import { moveToInspectionDir } from '../middleware/upload.middleware.js';
import { evaluateCompliance, seedLegalRulesIfEmpty } from '../services/compliance.service.js';
import { analyzeImage } from '../services/geminiVision.service.js';
import { generateInspectionPdf } from '../services/pdfReport.service.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SERVER_DIR = path.resolve(__dirname, '../..');
const UPLOADS_DIR = path.join(SERVER_DIR, 'uploads');
const SAMPLES_DIR = path.join(UPLOADS_DIR, 'samples');

// Helper to compute SHA-256 hash of a file
function computeFileHash(filePath) {
  try {
    const fileBuffer = fs.readFileSync(filePath);
    return crypto.createHash('sha256').update(fileBuffer).digest('hex');
  } catch {
    return null;
  }
}

// ── Unified Inspection Creation & AI Analysis Handler ──────────────────────────
export const createInspection = async (req, res) => {
  try {
    const { category, sample_id } = req.body;
    let imageFaceTypes = [];
    try {
      if (req.body.imageFaceTypes) {
        imageFaceTypes = typeof req.body.imageFaceTypes === 'string' 
          ? JSON.parse(req.body.imageFaceTypes) 
          : req.body.imageFaceTypes;
      }
    } catch {
      imageFaceTypes = [];
    }

    const inspector = req.user ? { id: req.user.id, name: req.user.name } : { id: null, name: 'AI Screening Inspector' };

    // Generate unique inspection ID (e.g. INSP-2026-0849)
    const countRows = await query('SELECT COUNT(*) as count FROM inspections');
    const seq = Number(countRows[0]?.count || 0) + 842;
    const inspectionId = `INSP-2026-${seq.toString().padStart(4, '0')}`;
    const now = new Date();

    const targetInspDir = path.join(UPLOADS_DIR, 'inspections', inspectionId);
    if (!fs.existsSync(targetInspDir)) {
      fs.mkdirSync(targetInspDir, { recursive: true });
    }

    const processedImages = [];

    // Case 1: Multiple physical files uploaded via multipart FormData
    if (req.files && req.files.length > 0) {
      for (let i = 0; i < req.files.length; i++) {
        const file = req.files[i];
        const faceType = imageFaceTypes[i] || (i === 0 ? 'FRONT' : i === 1 ? 'BACK' : 'OTHER');
        const relativeServedUrl = moveToInspectionDir(file.path, inspectionId, file.filename);
        const imagePath = path.join(UPLOADS_DIR, relativeServedUrl.replace(/^\/uploads\//, ''));
        
        let imgWidth = 900;
        let imgHeight = 900;
        try {
          const meta = await sharp(imagePath).metadata();
          imgWidth = meta.width || 900;
          imgHeight = meta.height || 900;
        } catch (e) {
          console.warn('[SHARP] Failed to get metadata for', imagePath);
        }

        const hash = computeFileHash(imagePath);
        processedImages.push({
          id: `img-${inspectionId}-${i + 1}`,
          type: faceType,
          filePath: imagePath,
          mimeType: file.mimetype || 'image/png',
          fileName: file.filename,
          relativeServedUrl,
          imageWidth: imgWidth,
          imageHeight: imgHeight,
          hash
        });
      }
    }
    // Case 2: Single file uploaded under req.file
    else if (req.file) {
      const file = req.file;
      const faceType = imageFaceTypes[0] || 'FRONT';
      const relativeServedUrl = moveToInspectionDir(file.path, inspectionId, file.filename);
      const imagePath = path.join(UPLOADS_DIR, relativeServedUrl.replace(/^\/uploads\//, ''));
      
      let imgWidth = 900;
      let imgHeight = 900;
      try {
        const meta = await sharp(imagePath).metadata();
        imgWidth = meta.width || 900;
        imgHeight = meta.height || 900;
      } catch (e) {
        console.warn('[SHARP] Failed to get metadata for', imagePath);
      }

      const hash = computeFileHash(imagePath);
      processedImages.push({
        id: `img-${inspectionId}-1`,
        type: faceType,
        filePath: imagePath,
        mimeType: file.mimetype || 'image/png',
        fileName: file.filename,
        relativeServedUrl,
        imageWidth: imgWidth,
        imageHeight: imgHeight,
        hash
      });
    }
    // Case 3: User selected a pre-configured sample product
    else if (sample_id || req.body.sample_image) {
      const requestedSample = (sample_id || req.body.sample_image || '').toLowerCase();
      let sourceSampleName = 'parle_g_biscuit_pack.png';

      if (requestedSample.includes('cadbury') || requestedSample.includes('chocolate') || requestedSample.includes('silk')) {
        sourceSampleName = 'cadbury_dairy_milk_silk.png';
      } else if (requestedSample.includes('honey') || requestedSample.includes('organic')) {
        sourceSampleName = 'organic_raw_honey.png';
      } else if (requestedSample.includes('shampoo') || requestedSample.includes('keval')) {
        sourceSampleName = 'keval_herbal_shampoo.png';
      } else if (requestedSample.includes('parle') || requestedSample.includes('biscuit')) {
        sourceSampleName = 'parle_g_biscuit_pack.png';
      }

      const sampleSrcPath = path.join(SAMPLES_DIR, sourceSampleName);
      if (!fs.existsSync(sampleSrcPath)) {
        return res.status(400).json({ success: false, message: `Sample asset ${sourceSampleName} not found.` });
      }

      const imageFileName = `sample-${Date.now()}-${sourceSampleName}`;
      const primaryImagePath = path.join(targetInspDir, imageFileName);
      fs.copyFileSync(sampleSrcPath, primaryImagePath);
      const relativeServedUrl = `/uploads/inspections/${inspectionId}/${imageFileName}`;
      
      let imgWidth = 900;
      let imgHeight = 900;
      try {
        const meta = await sharp(primaryImagePath).metadata();
        imgWidth = meta.width || 900;
        imgHeight = meta.height || 900;
      } catch (e) {}

      const hash = computeFileHash(primaryImagePath);
      processedImages.push({
        id: `img-${inspectionId}-1`,
        type: 'FRONT',
        filePath: primaryImagePath,
        mimeType: 'image/png',
        fileName: imageFileName,
        relativeServedUrl,
        imageWidth: imgWidth,
        imageHeight: imgHeight,
        hash
      });
    } else {
      return res.status(400).json({
        success: false,
        code: 'IMAGE_REQUIRED',
        message: 'A packaging image or valid sample selection is required for AI inspection screening.'
      });
    }

    if (processedImages.length === 0 || !fs.existsSync(processedImages[0].filePath)) {
      return res.status(400).json({
        success: false,
        message: 'Could not access uploaded image on the server storage layer.'
      });
    }

    const primaryImg = processedImages[0];
    console.log(`[INSPECTION] ${processedImages.length} image(s) received for ID=${inspectionId}, Primary=${primaryImg.filePath}`);

    // ── Call Gemini Vision Analysis for Front / Primary Image ────────────────
    console.log(`[GEMINI] Analyzing primary image (${primaryImg.type}) for ${inspectionId}...`);
    const aiResult = await analyzeImage({ filePath: primaryImg.filePath, mimeType: primaryImg.mimeType });

    // If a secondary back image exists, analyze it and merge detected declarations
    if (processedImages.length > 1) {
      const backImg = processedImages[1];
      try {
        console.log(`[GEMINI] Analyzing secondary image (${backImg.type}) for ${inspectionId}...`);
        const backAiResult = await analyzeImage({ filePath: backImg.filePath, mimeType: backImg.mimeType });
        if (backAiResult && backAiResult.fields) {
          // Merge missing or additional fields from the back image
          for (const [key, val] of Object.entries(backAiResult.fields)) {
            if (val && val.value && (!aiResult.fields[key] || !aiResult.fields[key].value || aiResult.fields[key].value === 'Not reliably detected')) {
              aiResult.fields[key] = val;
            }
          }
          if (backAiResult.text_regions) {
            aiResult.text_regions = [...(aiResult.text_regions || []), ...backAiResult.text_regions];
          }
        }
      } catch (backErr) {
        console.warn(`[GEMINI] Warning analyzing secondary image:`, backErr.message);
      }
    }

    // ── Ensure legal rules are seeded in DB ────────────────────────────────────
    await seedLegalRulesIfEmpty();

    // ── Evaluate Legal Metrology Compliance ──────────────────────────────────
    const firstImgId = primaryImg.id;
    const compliance = await evaluateCompliance(inspectionId, firstImgId, aiResult.fields, aiResult);

    const {
      declarations,
      violations,
      compliance_results,
      score,
      status,
      passed,
      failed,
      warnings,
      disclaimer,
      rule_registry_version
    } = compliance;

    const detectedProductName = req.body.product_name || aiResult.product?.name || aiResult.fields?.product_name?.value || 'Packaged Commodity';
    const detectedBrand = req.body.brand || aiResult.product?.brand || aiResult.fields?.brand?.value || null;
    const detectedCategory = category || req.body.category || aiResult.product?.category || 'Food & Beverages';
    const detectedBarcode = req.body.barcode || null;

    // ── Persist Investigation Record into MySQL ──────────────────────────────
    await transaction(async (conn) => {
      // 1. Insert into inspections table
      await conn.execute(
        `INSERT INTO inspections (
           id, product_id, product_name, brand, category, barcode,
           inspector_id, inspector_name, inspection_date, status, score, analysis_code,
           analysis_provider, analysis_model, analysis_status, raw_analysis,
           total_declarations, passed_rules, failed_rules, warning_rules,
           created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          inspectionId,
          null,
          detectedProductName,
          detectedBrand,
          detectedCategory,
          detectedBarcode,
          inspector.id || null,
          inspector.name || 'AI Screening Inspector',
          now,
          status,
          score,
          aiResult.analysis_status,
          aiResult.provider,
          aiResult.model,
          aiResult.analysis_status,
          JSON.stringify({ ...aiResult, image_hash: primaryImg.hash, rule_registry_version }),
          declarations.length,
          passed,
          failed,
          warnings,
          now,
          now
        ]
      );

      // 2. Insert all uploaded images into product_images table
      for (const img of processedImages) {
        await conn.execute(
          `INSERT INTO product_images (id, inspection_id, type, url, detected_text, file_name, image_width, image_height, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            img.id,
            inspectionId,
            img.type,
            img.relativeServedUrl,
            aiResult.full_text?.slice(0, 1000) || null,
            img.fileName,
            img.imageWidth,
            img.imageHeight,
            now
          ]
        );
      }

      // 3. Insert OCR / Text regions
      let itemSeq = 1;
      for (const item of aiResult.text_regions || []) {
        const bbox = item.bbox || { x: null, y: null, width: null, height: null };
        await conn.execute(
          `INSERT INTO ocr_items (inspection_id, image_id, item_order, text, confidence, status, bbox_x, bbox_y, bbox_width, bbox_height, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            inspectionId,
            firstImgId,
            itemSeq++,
            item.text,
            item.confidence || 0.90,
            'DETECTED',
            bbox.x,
            bbox.y,
            bbox.width,
            bbox.height,
            now
          ]
        );
      }

      // 4. Insert Declarations
      let declSeq = 1;
      for (const d of declarations) {
        const bbox = d.bbox || null;
        await conn.execute(
          `INSERT INTO declarations (
             id, inspection_id, field, value, confidence, status,
             image_id, bbox_x, bbox_y, bbox_width, bbox_height, created_at, updated_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            `decl-${inspectionId}-${declSeq++}`,
            inspectionId,
            d.field,
            d.value !== null ? String(d.value) : 'Not reliably detected',
            d.confidence,
            d.status || 'NOT_DETECTED',
            firstImgId,
            bbox ? bbox.x : null,
            bbox ? bbox.y : null,
            bbox ? bbox.width : null,
            bbox ? bbox.height : null,
            now,
            now
          ]
        );
      }

      // 5. Insert Violations
      let violSeq = 1;
      for (const v of violations) {
        const bbox = v.bbox || null;
        await conn.execute(
          `INSERT INTO violations (
             id, inspection_id, rule_code, title, severity, status,
             detected_value, expected_condition, confidence, recommendation,
             image_id, bbox_x, bbox_y, bbox_width, bbox_height, created_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            `viol-${inspectionId}-${violSeq++}`,
            inspectionId,
            v.rule_code || 'RULE-06',
            v.title,
            v.severity || 'HIGH',
            v.status || 'VIOLATION',
            v.detected_value || '',
            v.expected_condition || '',
            v.confidence || 0.90,
            v.recommendation || '',
            firstImgId,
            bbox ? bbox.x : null,
            bbox ? bbox.y : null,
            bbox ? bbox.width : null,
            bbox ? bbox.height : null,
            now
          ]
        );
      }
    });

    console.log(`[INSPECTION] Saved successfully: ID=${inspectionId}, Status=${status}, Score=${score}`);

    return res.status(201).json({
      success: true,
      data: {
        id: inspectionId,
        product_name: detectedProductName,
        brand: detectedBrand,
        category: detectedCategory,
        barcode: detectedBarcode,
        status,
        score,
        disclaimer,
        rule_registry_version,
        image_url: primaryImg.relativeServedUrl,
        image_hash: primaryImg.hash,
        images: processedImages.map(img => ({
          id: img.id,
          type: img.type,
          url: img.relativeServedUrl,
          fileName: img.fileName,
          image_width: img.imageWidth,
          image_height: img.imageHeight
        })),
        declarations,
        violations,
        compliance_results,
        ocr_items: aiResult.text_regions || []
      }
    });
  } catch (error) {
    console.error('[INSPECTION ERROR]:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Inspection analysis failed.'
    });
  }
};

// ── Get all inspections (User-Isolated) ────────────────────────────────────────
export const getInspections = async (req, res) => {
  try {
    const { status, search } = req.query;
    let sql = 'SELECT * FROM inspections WHERE 1=1';
    const params = [];

    // P1 Requirement: User Data Isolation
    if (req.user?.id) {
      sql += ' AND inspector_id = ?';
      params.push(req.user.id);
    } else {
      // Unauthenticated / Public Demo: only return unowned demo records
      sql += ' AND (inspector_id IS NULL OR inspector_name = "AI Screening Inspector" OR inspector_name = "Demo Inspector")';
    }

    if (status && status !== 'ALL') {
      sql += ' AND status = ?';
      params.push(status);
    }

    if (search && search.trim()) {
      const q = `%${search.trim()}%`;
      sql += ' AND (id LIKE ? OR product_name LIKE ? OR brand LIKE ? OR inspector_name LIKE ?)';
      params.push(q, q, q, q);
    }

    sql += ' ORDER BY inspection_date DESC';

    const rows = await query(sql, params);

    const formatted = rows.map(r => ({
      ...r,
      date: r.inspection_date ? new Date(r.inspection_date).toISOString() : new Date().toISOString()
    }));

    return res.status(200).json({
      success: true,
      count: formatted.length,
      data: formatted
    });
  } catch (error) {
    console.error('Error fetching inspections:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve inspections.' });
  }
};

// ── Get inspection by ID (With Authorization Check) ───────────────────────────
export const getInspectionById = async (req, res) => {
  try {
    const { id } = req.params;

    const inspRows = await query('SELECT * FROM inspections WHERE id = ? LIMIT 1', [id]);
    if (inspRows.length === 0) {
      return res.status(404).json({ success: false, message: `Inspection ${id} not found.` });
    }

    const inspection = inspRows[0];

    // P1 Requirement: Access Authorization Check
    if (inspection.inspector_id) {
      if (!req.user || (req.user.id !== inspection.inspector_id && req.user.role !== 'ADMIN')) {
        return res.status(403).json({
          success: false,
          message: 'Access denied. You do not have permission to view this inspection record.'
        });
      }
    }

    const [images, declarations, violations, ocrItems] = await Promise.all([
      query('SELECT * FROM product_images WHERE inspection_id = ? ORDER BY created_at ASC', [id]),
      query('SELECT * FROM declarations WHERE inspection_id = ? ORDER BY created_at ASC', [id]),
      query('SELECT * FROM violations WHERE inspection_id = ? ORDER BY created_at ASC', [id]),
      query('SELECT * FROM ocr_items WHERE inspection_id = ? ORDER BY id ASC', [id]).catch(() => [])
    ]);

    const reassembledDeclarations = declarations.map(d => ({
      id: d.id,
      field: d.field,
      value: d.value,
      confidence: d.confidence === null ? null : Number(d.confidence),
      status: d.status,
      image_id: d.image_id,
      bbox: d.bbox_x !== null && d.bbox_y !== null ? {
        x: d.bbox_x,
        y: d.bbox_y,
        width: d.bbox_width,
        height: d.bbox_height
      } : null
    }));

    const reassembledViolations = violations.map(v => ({
      id: v.id,
      rule_code: v.rule_code,
      title: v.title,
      severity: v.severity,
      status: v.status,
      detected_value: v.detected_value,
      expected_condition: v.expected_condition,
      confidence: v.confidence === null ? null : Number(v.confidence),
      recommendation: v.recommendation,
      image_id: v.image_id,
      bbox: v.bbox_x !== null && v.bbox_y !== null ? {
        x: v.bbox_x,
        y: v.bbox_y,
        width: v.bbox_width,
        height: v.bbox_height
      } : null
    }));

    const result = {
      ...inspection,
      date: inspection.inspection_date ? new Date(inspection.inspection_date).toISOString() : new Date().toISOString(),
      disclaimer: 'AI-assisted screening result — not a legally binding determination. Final legal determination remains with the competent authority / authorized inspector.',
      rule_registry_version: 'LM-PC-2026.08',
      image_url: images[0]?.url || null,
      images: images.map(img => ({
        id: img.id,
        type: img.type,
        url: img.url,
        detected_text: img.detected_text,
        fileName: img.file_name,
        image_width: img.image_width || null,
        image_height: img.image_height || null
      })),
      declarations: reassembledDeclarations,
      violations: reassembledViolations,
      ocr_items: ocrItems.map(item => ({
        ...item,
        confidence: Number(item.confidence),
        bbox: item.bbox_x === null ? null : { x: item.bbox_x, y: item.bbox_y, width: item.bbox_width, height: item.bbox_height }
      }))
    };

    return res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('Error fetching inspection by ID:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve inspection record.' });
  }
};

// ── Download Inspection PDF Report / Notice ──────────────────────────────────
export const downloadInspectionPdfReport = async (req, res) => {
  try {
    const { id } = req.params;
    const inspRows = await query('SELECT * FROM inspections WHERE id = ? LIMIT 1', [id]);
    if (inspRows.length === 0) {
      return res.status(404).json({ success: false, message: `Inspection ${id} not found.` });
    }

    const inspection = inspRows[0];

    // P1 Requirement: Authorization Check
    if (inspection.inspector_id) {
      if (req.user && req.user.id !== inspection.inspector_id && req.user.role !== 'ADMIN') {
        return res.status(403).json({
          success: false,
          message: 'Access denied. You do not have permission to generate this report.'
        });
      }
    }

    const [declarations, violations] = await Promise.all([
      query('SELECT * FROM declarations WHERE inspection_id = ? ORDER BY created_at ASC', [id]),
      query('SELECT * FROM violations WHERE inspection_id = ? ORDER BY created_at ASC', [id])
    ]);

    const inspectionData = {
      ...inspection,
      declarations,
      violations
    };

    const pdfBuffer = await generateInspectionPdf(inspectionData);

    const filename = `PackCheck-Notice-${id}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length');

    return res.status(200).send(pdfBuffer);
  } catch (error) {
    console.error('Error generating PDF report:', error);
    return res.status(500).json({ success: false, message: 'Failed to generate PDF report notice.' });
  }
};

export default {
  createInspection,
  getInspections,
  getInspectionById,
  downloadInspectionPdfReport
};
