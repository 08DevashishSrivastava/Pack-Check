/** Additive migration for real OCR audit data. It never drops existing tables. */
import { pool } from '../config/db.js';

const statements = [
  'ALTER TABLE inspections MODIFY product_name VARCHAR(255) NULL',
  'ALTER TABLE inspections MODIFY score INT NULL',
  'ALTER TABLE inspections ADD COLUMN analysis_code VARCHAR(50) NULL',
  'ALTER TABLE inspections ADD COLUMN analysis_provider VARCHAR(50) NULL',
  'ALTER TABLE inspections ADD COLUMN analysis_model VARCHAR(100) NULL',
  'ALTER TABLE inspections ADD COLUMN analysis_status VARCHAR(50) NULL',
  'ALTER TABLE inspections ADD COLUMN raw_analysis JSON NULL',
  'ALTER TABLE declarations MODIFY confidence DECIMAL(5,4) NULL',
  'ALTER TABLE violations MODIFY confidence DECIMAL(5,4) NULL',
  'ALTER TABLE product_images ADD COLUMN image_width INT NULL, ADD COLUMN image_height INT NULL',
  'ALTER TABLE legal_rules ADD COLUMN field VARCHAR(255) NULL',
  'ALTER TABLE legal_rules ADD COLUMN check_type VARCHAR(50) NULL',
  'ALTER TABLE legal_rules ADD COLUMN expected_value TEXT NULL',
  `CREATE TABLE IF NOT EXISTS ocr_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inspection_id VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    image_id VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    item_order INT NOT NULL,
    text TEXT NOT NULL,
    confidence DECIMAL(7,6) NULL,
    status VARCHAR(50) NOT NULL,
    bbox_x INT NOT NULL, bbox_y INT NOT NULL, bbox_width INT NOT NULL, bbox_height INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ocr_items_inspection (inspection_id),
    CONSTRAINT fk_ocr_items_inspection FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  'ALTER TABLE ocr_items MODIFY confidence DECIMAL(7,6) NULL'
];

async function hasColumn(table, column) {
  const [rows] = await pool.query(`SHOW COLUMNS FROM \`${table}\` LIKE ?`, [column]);
  return rows.length > 0;
}

async function run() {
  for (const sql of statements) {
    try {
      if (sql.startsWith('ALTER TABLE product_images') && await hasColumn('product_images', 'image_width')) continue;
      if (sql.includes(' ADD COLUMN field ') && await hasColumn('legal_rules', 'field')) continue;
      if (sql.includes(' ADD COLUMN check_type ') && await hasColumn('legal_rules', 'check_type')) continue;
      if (sql.includes(' ADD COLUMN expected_value ') && await hasColumn('legal_rules', 'expected_value')) continue;
      await pool.query(sql);
      console.log('[migration] applied:', sql.slice(0, 72));
    } catch (error) {
      if (error.code === 'ER_DUP_FIELDNAME') continue;
      throw error;
    }
  }
  await pool.end();
}

run().catch(async (error) => { console.error('[migration] failed:', error.message); await pool.end(); process.exitCode = 1; });
