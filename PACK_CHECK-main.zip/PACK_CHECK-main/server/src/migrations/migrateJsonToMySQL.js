import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, '../../data');
const DB_JSON_FILE = path.join(DATA_DIR, 'metro_check_db.json');
const BACKUP_JSON_FILE = path.join(DATA_DIR, 'metro_check_db.backup.json');

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'metro_check',
  multipleStatements: true
};

const sanitize = (val, fallback = null) => {
  return val === undefined ? fallback : val;
};

async function runMigration() {
  console.log('================================================================');
  console.log('  METRO-CHECK — Safe JSON Database to MySQL Migration Engine     ');
  console.log('================================================================\n');

  if (!fs.existsSync(DB_JSON_FILE)) {
    throw new Error(`Source JSON file not found at: ${DB_JSON_FILE}`);
  }

  console.log(`[1/6] Verifying JSON database source...`);
  const rawData = fs.readFileSync(DB_JSON_FILE, 'utf-8');
  const jsonData = JSON.parse(rawData);

  fs.copyFileSync(DB_JSON_FILE, BACKUP_JSON_FILE);
  console.log(`✓ Backup verified and secured at: ${BACKUP_JSON_FILE}`);

  const totalJsonUsers = jsonData.users?.length || 0;
  const totalJsonProducts = jsonData.products?.length || 0;
  const totalJsonInspections = jsonData.inspections?.length || 0;
  let totalJsonImages = 0;
  let totalJsonDeclarations = 0;
  let totalJsonViolations = 0;

  jsonData.inspections?.forEach(insp => {
    totalJsonImages += (insp.images?.length || 0);
    totalJsonDeclarations += (insp.declarations?.length || 0);
    totalJsonViolations += (insp.violations?.length || 0);
  });

  console.log(`\nSource JSON Records to Migrate:`);
  console.log(`  - Users:        ${totalJsonUsers}`);
  console.log(`  - Products:     ${totalJsonProducts}`);
  console.log(`  - Inspections:  ${totalJsonInspections}`);
  console.log(`  - Images:       ${totalJsonImages}`);
  console.log(`  - Declarations: ${totalJsonDeclarations}`);
  console.log(`  - Violations:   ${totalJsonViolations}\n`);

  // Connect to MySQL server
  console.log(`[2/6] Connecting to MySQL server (${dbConfig.host}:${dbConfig.port})...`);
  const rootConn = await mysql.createConnection({
    host: dbConfig.host,
    port: dbConfig.port,
    user: dbConfig.user,
    password: dbConfig.password
  });

  await rootConn.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
  await rootConn.end();
  console.log(`✓ MySQL database \`${dbConfig.database}\` confirmed / created.`);

  const connection = await mysql.createConnection(dbConfig);

  console.log(`[3/6] Initializing relational schema and tables...`);

  // Drop tables in foreign key order for clean migration idempotency
  await connection.query(`
    SET FOREIGN_KEY_CHECKS = 0;
    DROP TABLE IF EXISTS audit_logs;
    DROP TABLE IF EXISTS reports;
    DROP TABLE IF EXISTS legal_rules;
    DROP TABLE IF EXISTS violations;
    DROP TABLE IF EXISTS declarations;
    DROP TABLE IF EXISTS product_images;
    DROP TABLE IF EXISTS inspections;
    DROP TABLE IF EXISTS products;
    DROP TABLE IF EXISTS users;
    SET FOREIGN_KEY_CHECKS = 1;
  `);

  const schemaSQL = `
    -- 1. Users Table
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(50) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL UNIQUE,
      phone VARCHAR(50),
      department VARCHAR(255),
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('ADMIN', 'INSPECTOR', 'VIEWER') NOT NULL DEFAULT 'INSPECTOR',
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_users_email (email),
      INDEX idx_users_role (role)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 2. Products Table
    CREATE TABLE IF NOT EXISTS products (
      id VARCHAR(50) PRIMARY KEY,
      brand VARCHAR(255),
      name VARCHAR(255) NOT NULL,
      category VARCHAR(255),
      barcode VARCHAR(100),
      manufacturer TEXT,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_products_barcode (barcode),
      INDEX idx_products_brand (brand)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 3. Inspections Table
    CREATE TABLE IF NOT EXISTS inspections (
      id VARCHAR(50) PRIMARY KEY,
      product_id VARCHAR(50),
      product_name VARCHAR(255) NOT NULL,
      brand VARCHAR(255),
      category VARCHAR(255),
      barcode VARCHAR(100),
      inspector_id VARCHAR(50),
      inspector_name VARCHAR(255),
      inspection_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      status ENUM('COMPLIANT', 'NON_COMPLIANT', 'NEEDS_REVIEW') NOT NULL DEFAULT 'NEEDS_REVIEW',
      score INT NOT NULL DEFAULT 75,
      total_declarations INT NOT NULL DEFAULT 0,
      passed_rules INT NOT NULL DEFAULT 0,
      failed_rules INT NOT NULL DEFAULT 0,
      warning_rules INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_inspections_status (status),
      INDEX idx_inspections_inspector (inspector_id),
      INDEX idx_inspections_product (product_id),
      INDEX idx_inspections_date (inspection_date),
      CONSTRAINT fk_inspections_inspector FOREIGN KEY (inspector_id) REFERENCES users(id) ON DELETE SET NULL,
      CONSTRAINT fk_inspections_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 4. Product Images Table
    CREATE TABLE IF NOT EXISTS product_images (
      id VARCHAR(100) PRIMARY KEY,
      inspection_id VARCHAR(50) NOT NULL,
      type VARCHAR(50) NOT NULL DEFAULT 'FRONT',
      url TEXT NOT NULL,
      detected_text TEXT,
      file_name VARCHAR(255),
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_images_inspection (inspection_id),
      CONSTRAINT fk_images_inspection FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 5. Declarations Table
    CREATE TABLE IF NOT EXISTS declarations (
      id VARCHAR(100) PRIMARY KEY,
      inspection_id VARCHAR(50) NOT NULL,
      field VARCHAR(255) NOT NULL,
      value TEXT,
      confidence DECIMAL(5,4) NOT NULL DEFAULT 0.9000,
      status VARCHAR(50) NOT NULL DEFAULT 'DETECTED',
      image_id VARCHAR(100),
      bbox_x INT NULL,
      bbox_y INT NULL,
      bbox_width INT NULL,
      bbox_height INT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_declarations_inspection (inspection_id),
      CONSTRAINT fk_declarations_inspection FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 6. Violations Table
    CREATE TABLE IF NOT EXISTS violations (
      id VARCHAR(100) PRIMARY KEY,
      inspection_id VARCHAR(50) NOT NULL,
      rule_code VARCHAR(100) NOT NULL,
      title VARCHAR(255) NOT NULL,
      severity ENUM('CRITICAL', 'HIGH', 'MEDIUM', 'LOW') NOT NULL DEFAULT 'HIGH',
      status VARCHAR(50) NOT NULL DEFAULT 'VIOLATION',
      detected_value TEXT,
      expected_condition TEXT,
      confidence DECIMAL(5,4) NOT NULL DEFAULT 0.9000,
      recommendation TEXT,
      image_id VARCHAR(100),
      bbox_x INT NULL,
      bbox_y INT NULL,
      bbox_width INT NULL,
      bbox_height INT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_violations_inspection (inspection_id),
      INDEX idx_violations_rule_code (rule_code),
      INDEX idx_violations_severity (severity),
      CONSTRAINT fk_violations_inspection FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 7. Legal Rules Reference Table
    CREATE TABLE IF NOT EXISTS legal_rules (
      id VARCHAR(100) PRIMARY KEY,
      rule_code VARCHAR(100) NOT NULL UNIQUE,
      rule_name VARCHAR(255) NOT NULL,
      legal_reference VARCHAR(255),
      description TEXT,
      severity ENUM('CRITICAL', 'HIGH', 'MEDIUM', 'LOW') NOT NULL DEFAULT 'HIGH',
      category VARCHAR(100),
      rule_version VARCHAR(50) NOT NULL DEFAULT '2011.1',
      effective_from DATE NULL,
      effective_to DATE NULL,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_legal_rules_code (rule_code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 8. Reports Table
    CREATE TABLE IF NOT EXISTS reports (
      id VARCHAR(100) PRIMARY KEY,
      inspection_id VARCHAR(50) NOT NULL,
      title VARCHAR(255),
      status VARCHAR(50),
      pdf_url TEXT,
      generated_by VARCHAR(255),
      generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_reports_inspection (inspection_id),
      CONSTRAINT fk_reports_inspection FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    -- 9. Audit Logs Table
    CREATE TABLE IF NOT EXISTS audit_logs (
      id VARCHAR(100) PRIMARY KEY,
      user_id VARCHAR(50),
      action VARCHAR(100) NOT NULL,
      entity_type VARCHAR(100),
      entity_id VARCHAR(100),
      metadata JSON,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_audit_user (user_id),
      INDEX idx_audit_action (action),
      CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `;

  await connection.query(schemaSQL);
  console.log(`✓ All 9 MySQL tables successfully initialized.`);

  // 5. Begin Transaction & Data Migration
  console.log(`\n[4/6] Migrating records into MySQL tables within transaction...`);
  await connection.beginTransaction();

  try {
    // 5.1 Migrate Users
    for (const u of (jsonData.users || [])) {
      const createdAt = u.created_at ? new Date(u.created_at) : new Date();
      const updatedAt = u.updated_at ? new Date(u.updated_at) : new Date();
      await connection.execute(
        `INSERT INTO users (id, name, email, phone, department, password_hash, role, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           phone = VALUES(phone),
           department = VALUES(department),
           password_hash = VALUES(password_hash),
           role = VALUES(role),
           updated_at = VALUES(updated_at);`,
        [
          sanitize(u.id),
          sanitize(u.name),
          sanitize(u.email),
          sanitize(u.phone, null),
          sanitize(u.department, null),
          sanitize(u.password_hash),
          sanitize(u.role, 'INSPECTOR'),
          createdAt,
          updatedAt
        ]
      );
    }
    console.log(`  ✓ Users migrated: ${jsonData.users?.length || 0}`);

    // 5.2 Migrate Products
    for (const p of (jsonData.products || [])) {
      const createdAt = p.created_at ? new Date(p.created_at) : new Date();
      const updatedAt = p.updated_at ? new Date(p.updated_at) : createdAt;
      await connection.execute(
        `INSERT INTO products (id, brand, name, category, barcode, manufacturer, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           brand = VALUES(brand),
           name = VALUES(name),
           category = VALUES(category),
           barcode = VALUES(barcode),
           manufacturer = VALUES(manufacturer),
           updated_at = VALUES(updated_at);`,
        [
          sanitize(p.id),
          sanitize(p.brand, null),
          sanitize(p.name),
          sanitize(p.category, null),
          sanitize(p.barcode, null),
          sanitize(p.manufacturer, null),
          createdAt,
          updatedAt
        ]
      );
    }
    console.log(`  ✓ Products migrated: ${jsonData.products?.length || 0}`);

    // 5.3 Migrate Inspections and Child records (Images, Declarations, Violations)
    for (const insp of (jsonData.inspections || [])) {
      const inspDate = insp.date ? new Date(insp.date) : new Date();
      const createdAt = insp.created_at ? new Date(insp.created_at) : inspDate;
      const updatedAt = insp.updated_at ? new Date(insp.updated_at) : inspDate;

      let inspectorId = insp.inspector_id;
      if (inspectorId) {
        const [uRows] = await connection.execute('SELECT id FROM users WHERE id = ?', [inspectorId]);
        if (uRows.length === 0) inspectorId = null;
      }

      let productId = insp.product_id;
      if (productId) {
        const [pRows] = await connection.execute('SELECT id FROM products WHERE id = ?', [productId]);
        if (pRows.length === 0) productId = null;
      }

      await connection.execute(
        `INSERT INTO inspections (
           id, product_id, product_name, brand, category, barcode,
           inspector_id, inspector_name, inspection_date, status, score,
           total_declarations, passed_rules, failed_rules, warning_rules,
           created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           product_id = VALUES(product_id),
           product_name = VALUES(product_name),
           brand = VALUES(brand),
           category = VALUES(category),
           barcode = VALUES(barcode),
           inspector_id = VALUES(inspector_id),
           inspector_name = VALUES(inspector_name),
           inspection_date = VALUES(inspection_date),
           status = VALUES(status),
           score = VALUES(score),
           total_declarations = VALUES(total_declarations),
           passed_rules = VALUES(passed_rules),
           failed_rules = VALUES(failed_rules),
           warning_rules = VALUES(warning_rules),
           updated_at = VALUES(updated_at);`,
        [
          sanitize(insp.id),
          sanitize(productId, null),
          sanitize(insp.product_name || insp.product || 'Packaged Commodity'),
          sanitize(insp.brand, null),
          sanitize(insp.category, null),
          sanitize(insp.barcode, null),
          sanitize(inspectorId, null),
          sanitize(insp.inspector_name || insp.inspector || 'Duty Inspector'),
          inspDate,
          sanitize(insp.status, 'NEEDS_REVIEW'),
          sanitize(insp.score, 75),
          sanitize(insp.total_declarations || (insp.declarations?.length || 0), 0),
          sanitize(insp.passed_rules, 0),
          sanitize(insp.failed_rules || (insp.violations?.length || 0), 0),
          sanitize(insp.warning_rules, 0),
          createdAt,
          updatedAt
        ]
      );

      // 5.4 Migrate Images (Generate unique ID if needed: `${insp.id}_${img.id}`)
      let imgSeq = 1;
      for (const img of (insp.images || [])) {
        const rawImgId = img.id || `img-${imgSeq++}`;
        const uniqueImgId = rawImgId.startsWith(insp.id) ? rawImgId : `${insp.id}_${rawImgId}`;

        await connection.execute(
          `INSERT INTO product_images (id, inspection_id, type, url, detected_text, file_name, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             type = VALUES(type),
             url = VALUES(url),
             detected_text = VALUES(detected_text),
             file_name = VALUES(file_name);`,
          [
            sanitize(uniqueImgId),
            sanitize(insp.id),
            sanitize(img.type, 'FRONT'),
            sanitize(img.url, 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e'),
            sanitize(img.detected_text, null),
            sanitize(img.fileName, null),
            createdAt
          ]
        );
      }

      // 5.5 Migrate Declarations
      let declSeq = 1;
      for (const d of (insp.declarations || [])) {
        const rawDeclId = d.id || `decl-${declSeq++}`;
        const uniqueDeclId = rawDeclId.startsWith(insp.id) ? rawDeclId : `${insp.id}_${rawDeclId}`;
        const bbox = d.bbox || null;
        const mappedImageId = d.image_id ? (d.image_id.startsWith(insp.id) ? d.image_id : `${insp.id}_${d.image_id}`) : null;

        await connection.execute(
          `INSERT INTO declarations (
             id, inspection_id, field, value, confidence, status,
             image_id, bbox_x, bbox_y, bbox_width, bbox_height, created_at, updated_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             field = VALUES(field),
             value = VALUES(value),
             confidence = VALUES(confidence),
             status = VALUES(status),
             image_id = VALUES(image_id),
             bbox_x = VALUES(bbox_x),
             bbox_y = VALUES(bbox_y),
             bbox_width = VALUES(bbox_width),
             bbox_height = VALUES(bbox_height),
             updated_at = VALUES(updated_at);`,
          [
            sanitize(uniqueDeclId),
            sanitize(insp.id),
            sanitize(d.field),
            sanitize(d.value, ''),
            sanitize(d.confidence, 0.90),
            sanitize(d.status, 'DETECTED'),
            sanitize(mappedImageId, null),
            bbox && bbox.x !== undefined ? bbox.x : null,
            bbox && bbox.y !== undefined ? bbox.y : null,
            bbox && bbox.width !== undefined ? bbox.width : null,
            bbox && bbox.height !== undefined ? bbox.height : null,
            createdAt,
            updatedAt
          ]
        );
      }

      // 5.6 Migrate Violations
      let violSeq = 1;
      for (const v of (insp.violations || [])) {
        const rawViolId = v.id || `viol-${violSeq++}`;
        const uniqueViolId = rawViolId.startsWith(insp.id) ? rawViolId : `${insp.id}_${rawViolId}`;
        const bbox = v.bbox || null;
        const mappedImageId = v.image_id ? (v.image_id.startsWith(insp.id) ? v.image_id : `${insp.id}_${v.image_id}`) : null;

        await connection.execute(
          `INSERT INTO violations (
             id, inspection_id, rule_code, title, severity, status,
             detected_value, expected_condition, confidence, recommendation,
             image_id, bbox_x, bbox_y, bbox_width, bbox_height, created_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             rule_code = VALUES(rule_code),
             title = VALUES(title),
             severity = VALUES(severity),
             status = VALUES(status),
             detected_value = VALUES(detected_value),
             expected_condition = VALUES(expected_condition),
             confidence = VALUES(confidence),
             recommendation = VALUES(recommendation),
             image_id = VALUES(image_id),
             bbox_x = VALUES(bbox_x),
             bbox_y = VALUES(bbox_y),
             bbox_width = VALUES(bbox_width),
             bbox_height = VALUES(bbox_height);`,
          [
            sanitize(uniqueViolId),
            sanitize(insp.id),
            sanitize(v.rule_code, 'LM-RULE-06'),
            sanitize(v.title, 'Packaging Rule Non-Compliance'),
            sanitize(v.severity, 'HIGH'),
            sanitize(v.status, 'VIOLATION'),
            sanitize(v.detected_value, ''),
            sanitize(v.expected_condition, ''),
            sanitize(v.confidence, 0.90),
            sanitize(v.recommendation, ''),
            sanitize(mappedImageId, null),
            bbox && bbox.x !== undefined ? bbox.x : null,
            bbox && bbox.y !== undefined ? bbox.y : null,
            bbox && bbox.width !== undefined ? bbox.width : null,
            bbox && bbox.height !== undefined ? bbox.height : null,
            createdAt
          ]
        );
      }
    }
    console.log(`  ✓ Inspections migrated:    ${jsonData.inspections?.length || 0}`);
    console.log(`  ✓ Product Images migrated: ${totalJsonImages}`);
    console.log(`  ✓ Declarations migrated:   ${totalJsonDeclarations}`);
    console.log(`  ✓ Violations migrated:     ${totalJsonViolations}`);

    // Commit Transaction
    await connection.commit();
    console.log(`✓ Database transaction committed successfully.`);
  } catch (err) {
    await connection.rollback();
    console.error(`✗ Migration transaction failed. Rolled back successfully. Error:`, err);
    throw err;
  }

  // 6. Automated Count Comparison & Verification
  console.log(`\n[5/6] Performing automated row count integrity verification...`);

  const [uCountRows] = await connection.execute('SELECT COUNT(*) as count FROM users');
  const [pCountRows] = await connection.execute('SELECT COUNT(*) as count FROM products');
  const [iCountRows] = await connection.execute('SELECT COUNT(*) as count FROM inspections');
  const [imgCountRows] = await connection.execute('SELECT COUNT(*) as count FROM product_images');
  const [dCountRows] = await connection.execute('SELECT COUNT(*) as count FROM declarations');
  const [vCountRows] = await connection.execute('SELECT COUNT(*) as count FROM violations');

  const mysqlUsers = Number(uCountRows[0].count);
  const mysqlProducts = Number(pCountRows[0].count);
  const mysqlInspections = Number(iCountRows[0].count);
  const mysqlImages = Number(imgCountRows[0].count);
  const mysqlDeclarations = Number(dCountRows[0].count);
  const mysqlViolations = Number(vCountRows[0].count);

  console.log(`-------------------------------------------------------------`);
  console.log(`Entity        | JSON Source Count | MySQL Migrated Count | Match`);
  console.log(`-------------------------------------------------------------`);
  console.log(`Users         | ${String(totalJsonUsers).padEnd(17)} | ${String(mysqlUsers).padEnd(20)} | ${totalJsonUsers === mysqlUsers ? '✓ OK' : '✗ MISMATCH'}`);
  console.log(`Products      | ${String(totalJsonProducts).padEnd(17)} | ${String(mysqlProducts).padEnd(20)} | ${totalJsonProducts === mysqlProducts ? '✓ OK' : '✗ MISMATCH'}`);
  console.log(`Inspections   | ${String(totalJsonInspections).padEnd(17)} | ${String(mysqlInspections).padEnd(20)} | ${totalJsonInspections === mysqlInspections ? '✓ OK' : '✗ MISMATCH'}`);
  console.log(`Images        | ${String(totalJsonImages).padEnd(17)} | ${String(mysqlImages).padEnd(20)} | ${totalJsonImages === mysqlImages ? '✓ OK' : '✗ MISMATCH'}`);
  console.log(`Declarations  | ${String(totalJsonDeclarations).padEnd(17)} | ${String(mysqlDeclarations).padEnd(20)} | ${totalJsonDeclarations === mysqlDeclarations ? '✓ OK' : '✗ MISMATCH'}`);
  console.log(`Violations    | ${String(totalJsonViolations).padEnd(17)} | ${String(mysqlViolations).padEnd(20)} | ${totalJsonViolations === mysqlViolations ? '✓ OK' : '✗ MISMATCH'}`);
  console.log(`-------------------------------------------------------------`);

  if (
    mysqlUsers !== totalJsonUsers ||
    mysqlProducts !== totalJsonProducts ||
    mysqlInspections !== totalJsonInspections ||
    mysqlImages !== totalJsonImages ||
    mysqlDeclarations !== totalJsonDeclarations ||
    mysqlViolations !== totalJsonViolations
  ) {
    throw new Error('Verification failed: Record count mismatch between JSON and MySQL tables!');
  }

  console.log(`\n[6/6] ✓ DATA INTEGRITY 100% VERIFIED.`);
  console.log(`Migration from JSON to MySQL completed successfully.\n`);

  await connection.end();
}

runMigration().catch(err => {
  console.error('\n✗ Migration terminated with error:', err.message);
  process.exit(1);
});
