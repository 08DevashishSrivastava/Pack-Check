import dotenv from 'dotenv';
dotenv.config();

import app from './app.js';

const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0';

app.listen(PORT, HOST, () => {
  console.log(`====================================================`);
  console.log(`  PackCheck Compliance Inspection Backend Running     `);
  console.log(`  Port: ${PORT} | Host: ${HOST} | Env: ${process.env.NODE_ENV || 'development'}`);
  console.log(`  Local: http://localhost:${PORT}/api/health        `);
  console.log(`  LAN:   http://10.0.58.1:${PORT}/api/health        `);
  console.log(`====================================================`);
});
