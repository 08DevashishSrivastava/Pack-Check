import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import authRoutes from './routes/auth.routes.js';
import inspectionRoutes from './routes/inspection.routes.js';
import dashboardRoutes from './routes/dashboard.routes.js';
import aiRoutes from './routes/ai.routes.js';
import { optionalAuth } from './middleware/auth.middleware.js';
import { query, checkConnection } from './config/db.js';
import { downloadInspectionPdfReport } from './controllers/inspection.controller.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Enhanced CORS middleware to support Desktop web, Android WebView, Capacitor, and mobile devices
const allowedOrigins = [
  'http://localhost:5173',
  'http://localhost:5000',
  'http://localhost',
  'https://localhost',
  'capacitor://localhost',
  'ionic://localhost',
  ...(process.env.CLIENT_URL ? process.env.CLIENT_URL.split(',').map(u => u.trim()) : [])
];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    if (
      allowedOrigins.includes(origin) ||
      /^http:\/\/(localhost|127\.0\.0\.1|10\.0\.2\.2|192\.168\.\d+\.\d+|172\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+)(:\d+)?$/.test(origin) ||
      origin.startsWith('capacitor://') ||
      origin.startsWith('ionic://') ||
      origin.startsWith('http://localhost') ||
      origin.startsWith('https://localhost')
    ) {
      return callback(null, true);
    }
    return callback(null, true);
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept']
}));

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// ─── Static file serving for uploaded images ──────────────────────────────────
// Serves server/uploads/ at /uploads (e.g. GET /uploads/inspections/<id>/<file>)
const uploadsDir = path.resolve(__dirname, '../uploads');
app.use('/uploads', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Cross-Origin-Resource-Policy', 'cross-origin');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
}, express.static(uploadsDir, {
  maxAge: '7d',           // cache images for 7 days
  etag: true,
  lastModified: true
}));

// Health Check with MySQL connection verification
app.get('/api/health', async (req, res) => {
  const isDbConnected = await checkConnection();

  if (!isDbConnected) {
    return res.status(500).json({
      status: 'error',
      database: 'disconnected',
      service: 'packcheck-api',
      message: 'Database connection failed. MySQL is unreachable.'
    });
  }

  return res.status(200).json({
    status: 'ok',
    database: 'connected',
    service: 'packcheck-api',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Products API querying MySQL
app.get('/api/products', async (req, res) => {
  try {
    const products = await query(`
      SELECT 
        p.*,
        COUNT(i.id) as inspectionCount,
        COALESCE(
          (SELECT status FROM inspections WHERE product_id = p.id OR product_name = p.name ORDER BY inspection_date DESC LIMIT 1),
          'COMPLIANT'
        ) as latestStatus
      FROM products p
      LEFT JOIN inspections i ON i.product_id = p.id OR i.product_name = p.name
      GROUP BY p.id;
    `);
    res.status(200).json({ success: true, data: products });
  } catch (error) {
    console.error('Error fetching products from MySQL:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve products from database.' });
  }
});

app.get('/api/products/:id', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM products WHERE id = ? LIMIT 1', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    res.status(200).json({ success: true, data: rows[0] });
  } catch (error) {
    console.error('Error fetching product by ID from MySQL:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve product.' });
  }
});

// Violations API - Isolated by user inspection ownership
app.get('/api/violations', optionalAuth, async (req, res) => {
  try {
    const { inspection_id, severity } = req.query;
    const userId = req.user?.id || null;
    let sql = `
      SELECT v.* 
      FROM violations v
      JOIN inspections i ON i.id = v.inspection_id
      WHERE 1=1
    `;
    const params = [];

    if (userId) {
      sql += ' AND i.inspector_id = ?';
      params.push(userId);
    } else {
      sql += ' AND (i.inspector_id IS NULL OR i.inspector_name = "AI Screening Inspector" OR i.inspector_name = "Demo Inspector")';
    }

    if (inspection_id) { sql += ' AND v.inspection_id = ?'; params.push(inspection_id); }
    if (severity) { sql += ' AND v.severity = ?'; params.push(severity); }
    sql += ' ORDER BY v.created_at DESC';
    const rows = await query(sql, params);
    return res.status(200).json({ success: true, count: rows.length, data: rows });
  } catch (e) {
    return res.status(500).json({ success: false, message: 'Failed to retrieve violations.' });
  }
});

// Reports API - User-isolated aggregation from inspections
app.get('/api/reports', optionalAuth, async (req, res) => {
  try {
    const userId = req.user?.id || null;
    let sql = `
      SELECT
        i.id as inspection_id,
        i.product_name,
        i.brand,
        i.category,
        i.status,
        i.score,
        i.total_declarations,
        i.passed_rules,
        i.failed_rules,
        i.warning_rules,
        i.inspector_name,
        i.inspection_date,
        COUNT(v.id) as violation_count
      FROM inspections i
      LEFT JOIN violations v ON v.inspection_id = i.id
      WHERE 1=1
    `;
    const params = [];

    if (userId) {
      sql += ' AND i.inspector_id = ?';
      params.push(userId);
    } else {
      sql += ' AND (i.inspector_id IS NULL OR i.inspector_name = "AI Screening Inspector" OR i.inspector_name = "Demo Inspector")';
    }

    sql += `
      GROUP BY i.id
      ORDER BY i.inspection_date DESC
    `;
    const rows = await query(sql, params);
    return res.status(200).json({ success: true, count: rows.length, data: rows });
  } catch (e) {
    return res.status(500).json({ success: false, message: 'Failed to retrieve reports.' });
  }
});

// Single Inspection Report PDF Download endpoint
app.get('/api/reports/:id/pdf', optionalAuth, downloadInspectionPdfReport);
app.get('/api/reports/:id/download', optionalAuth, downloadInspectionPdfReport);

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/inspections', inspectionRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/dashboard', dashboardRoutes);

// 404 Handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Endpoint ${req.method} ${req.originalUrl} not found.`
  });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);

  // Multer-specific errors
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ success: false, message: 'File too large. Maximum size is 15MB per image.' });
  }
  if (err.code === 'LIMIT_FILE_COUNT') {
    return res.status(400).json({ success: false, message: 'Too many files. Maximum 10 images per inspection.' });
  }

  res.status(500).json({
    success: false,
    message: err.message || 'Internal server error occurred.'
  });
});

export default app;
