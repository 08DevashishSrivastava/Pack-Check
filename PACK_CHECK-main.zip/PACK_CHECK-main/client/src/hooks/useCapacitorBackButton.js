import { useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { App as CapApp } from '@capacitor/app';

/**
 * Handles Android hardware back button events inside Capacitor.
 * 
 * Rules:
 * 1. If a mobile drawer / modal is open, close it.
 * 2. If inside a sub-route (e.g. /inspections/123 -> /inspections), go back.
 * 3. If on a top-level route (/dashboard, /, /login), double-press exits the app.
 */
export function useCapacitorBackButton() {
  const navigate = useNavigate();
  const location = useLocation();
  const lastBackRef = useRef(0);

  useEffect(() => {
    let listener = null;

    const setupListener = async () => {
      try {
        listener = await CapApp.addListener('backButton', ({ canGoBack }) => {
          // Check if any open drawer or overlay consumed the event
          window.__drawerWasOpen = false;
          window.dispatchEvent(new CustomEvent('closeMobileDrawers'));

          if (window.__drawerWasOpen) {
            return;
          }

          const topLevelRoutes = ['/', '/dashboard', '/login'];
          const isTopLevel = topLevelRoutes.includes(location.pathname);

          if (isTopLevel) {
            const now = Date.now();
            if (now - lastBackRef.current < 2000) {
              CapApp.exitApp();
            } else {
              lastBackRef.current = now;
            }
          } else {
            navigate(-1);
          }
        });
      } catch {
        // Running in desktop browser where CapApp bridge is inactive
      }
    };

    setupListener();

    return () => {
      if (listener && typeof listener.remove === 'function') {
        listener.remove();
      }
    };
  }, [navigate, location]);
}

export default useCapacitorBackButton;
