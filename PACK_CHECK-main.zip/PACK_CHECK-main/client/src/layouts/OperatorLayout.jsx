import React, { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  ScanLine,
  FileCheck2,
  PackageCheck,
  AlertOctagon,
  FileSpreadsheet,
  BarChart3,
  User,
  Settings,
  LogOut,
  Menu,
  X,
  Plus,
  Scale,
  Bell,
  Search,
  Shield
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { cn } from '../utils/cn';

export const OperatorLayout = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  React.useEffect(() => {
    const handleDrawerClose = () => {
      if (sidebarOpen) {
        window.__drawerWasOpen = true;
        setSidebarOpen(false);
      }
    };
    window.addEventListener('closeMobileDrawers', handleDrawerClose);
    return () => window.removeEventListener('closeMobileDrawers', handleDrawerClose);
  }, [sidebarOpen]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'New Inspection', path: '/inspections/new', icon: ScanLine, highlight: true },
    { label: 'Inspection History', path: '/inspections', icon: FileCheck2 },
    { label: 'Product Catalog', path: '/products', icon: PackageCheck },
    { label: 'Violations Registry', path: '/violations', icon: AlertOctagon },
    { label: 'Inspection Reports', path: '/reports', icon: FileSpreadsheet },
    { label: 'Analytics & Trends', path: '/analytics', icon: BarChart3 },
  ];

  const secondaryNav = [
    { label: 'Inspector Profile', path: '/profile', icon: User },
    { label: 'System Settings', path: '/settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Mobile Drawer Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 z-50 lg:hidden backdrop-blur-xs transition-opacity"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Layout Shell */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside
          className={cn(
            'fixed lg:static inset-y-0 left-0 z-50 w-64 bg-slate-900 text-slate-300 flex flex-col justify-between transition-transform duration-200 ease-in-out border-r border-slate-800',
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          )}
        >
          {/* Logo & Header */}
          <div>
            <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800 bg-slate-950/60">
              <Link to="/dashboard" className="flex items-center gap-2.5">
                <img
                  src="/logo.png"
                  alt="PackCheck"
                  className="h-8 w-8 object-contain"
                />
                <span className="font-extrabold text-base text-white tracking-tight">
                  Pack<span className="text-blue-400">Check</span>
                </span>
              </Link>
              <button
                onClick={() => setSidebarOpen(false)}
                className="lg:hidden text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Main Navigation Items */}
            <div className="px-3 py-4 space-y-1">
              <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                Enforcement Actions
              </p>
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path || 
                  (item.path !== '/dashboard' && location.pathname.startsWith(item.path) && item.path !== '/inspections/new');

                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={() => setSidebarOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-colors duration-150',
                      item.highlight && !isActive
                        ? 'bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30'
                        : '',
                      isActive
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    )}
                  >
                    <Icon className={cn('w-4 h-4', isActive ? 'text-white' : item.highlight ? 'text-blue-400' : 'text-slate-400')} />
                    <span>{item.label}</span>
                    {item.highlight && (
                      <span className="ml-auto text-[9px] bg-blue-500 text-white px-1.5 py-0.5 rounded font-bold uppercase">
                        +Scan
                      </span>
                    )}
                  </NavLink>
                );
              })}
            </div>

            {/* Secondary Navigation */}
            <div className="px-3 py-2 space-y-1 border-t border-slate-800/80 mt-2">
              <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                Configuration
              </p>
              {secondaryNav.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={() => setSidebarOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors',
                      isActive
                        ? 'bg-slate-800 text-white font-semibold'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    )}
                  >
                    <Icon className="w-4 h-4 text-slate-500" />
                    <span>{item.label}</span>
                  </NavLink>
                );
              })}
            </div>
          </div>

          {/* User Badge & Logout */}
          <div className="p-3 border-t border-slate-800 bg-slate-950/40">
            <div className="flex items-center gap-3 px-2 py-2 rounded-lg bg-slate-800/60 mb-2">
              <div className="w-8 h-8 rounded-full bg-blue-700 text-white flex items-center justify-center font-bold text-xs shrink-0">
                {user?.name ? user.name.charAt(0).toUpperCase() : 'I'}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-semibold text-white truncate">{user?.name || 'Duty Inspector'}</p>
                <p className="text-[10px] text-slate-400 truncate">{user?.role || 'INSPECTOR'}</p>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition-colors border border-rose-900/30"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
          </div>
        </aside>

        {/* Content Area */}
        <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
          {/* Top Operator Header */}
          <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 shadow-2xs">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
                aria-label="Open Sidebar"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                <span className="hidden sm:inline font-semibold text-slate-800">Legal Metrology Inspectorate</span>
                <span className="hidden sm:inline">•</span>
                <span className="text-slate-600 font-mono text-[11px] bg-slate-100 px-2 py-0.5 rounded">
                  {user?.department || 'Zone-Delhi'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Link
                to="/inspections/new"
                className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white px-3.5 py-1.5 rounded-lg text-xs font-bold shadow-sm transition"
              >
                <Plus className="w-4 h-4" />
                <span>New Inspection</span>
              </Link>
            </div>
          </header>

          {/* Page Body */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
};

export default OperatorLayout;
