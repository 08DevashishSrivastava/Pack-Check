import React, { useState } from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { Scale, Menu, X, ArrowRight, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const PublicLayout = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  React.useEffect(() => {
    const handleDrawerClose = () => {
      if (mobileMenuOpen) {
        window.__drawerWasOpen = true;
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('closeMobileDrawers', handleDrawerClose);
    return () => window.removeEventListener('closeMobileDrawers', handleDrawerClose);
  }, [mobileMenuOpen]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-900">
      {/* Main Navbar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group">
              <img
                src="/logo.png"
                alt="PackCheck"
                className="h-9 w-9 object-contain"
              />
              <span className="font-extrabold text-lg text-slate-900 tracking-tight">
                Pack<span className="text-blue-700">Check</span>
              </span>
              <div className="hidden lg:block border-l border-slate-200 pl-3">
                <p className="text-[11px] text-slate-600 font-semibold leading-tight">
                  Packaged Commodities AI Compliance Engine
                </p>
                <p className="text-[9.5px] text-slate-400 font-medium">
                  Legal Metrology Rules, 2011
                </p>
              </div>
            </Link>

            {/* Desktop Nav Links */}
            <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
              <Link to="/" className="hover:text-blue-700 transition-colors">Home</Link>
              <a href="/#how-it-works" className="hover:text-blue-700 transition-colors">How It Works</a>
              <a href="/#capabilities" className="hover:text-blue-700 transition-colors">Capabilities</a>
              <Link to="/demo" className="hover:text-blue-700 transition-colors flex items-center gap-1">
                <span>Try Demo</span>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded-full border border-emerald-300">
                  Instant
                </span>
              </Link>
              <Link to="/about" className="hover:text-blue-700 transition-colors">LM Rules 2011</Link>
            </nav>

            {/* Auth Actions */}
            <div className="hidden md:flex items-center gap-3">
              {isAuthenticated ? (
                <Link
                  to="/dashboard"
                  className="inline-flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition shadow-sm hover:shadow"
                >
                  <span>Operator Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              ) : (
                <>
                  <Link
                    to="/login"
                    className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-700 hover:text-blue-700 px-3 py-2 rounded-lg hover:bg-slate-100 transition"
                  >
                    <Lock className="w-4 h-4 text-slate-400" />
                    <span>Inspector Login</span>
                  </Link>
                  <Link
                    to="/demo"
                    className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition shadow-sm"
                  >
                    <span>Start Inspection</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                aria-label="Toggle Navigation Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden border-b border-slate-200 bg-white px-4 pt-2 pb-6 space-y-3 shadow-lg">
            <Link
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:bg-slate-100"
            >
              Home
            </Link>
            <Link
              to="/demo"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-blue-700 hover:bg-blue-50"
            >
              Try Public Demo
            </Link>
            <Link
              to="/about"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:bg-slate-100"
            >
              Legal Metrology Rules 2011 Guide
            </Link>
            <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
              {isAuthenticated ? (
                <Link
                  to="/dashboard"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full text-center bg-blue-700 text-white font-semibold py-2.5 rounded-lg shadow-sm"
                >
                  Go to Operator Dashboard
                </Link>
              ) : (
                <>
                  <Link
                    to="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="w-full text-center border border-slate-300 text-slate-800 font-semibold py-2 rounded-lg"
                  >
                    Inspector Login
                  </Link>
                  <Link
                    to="/signup"
                    onClick={() => setMobileMenuOpen(false)}
                    className="w-full text-center bg-blue-700 text-white font-semibold py-2 rounded-lg shadow-sm"
                  >
                    Register Inspector Account
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Page Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-sm border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-1 space-y-3">
              <div className="flex items-center gap-2.5 text-white font-bold text-lg">
                <img src="/logo.png" alt="PackCheck" className="h-7 w-7 object-contain" />
                <span>Pack<span className="text-blue-400">Check</span></span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Standardized AI compliance screening system for packaged commodity labels under the Legal Metrology (Packaged Commodities) Rules, 2011.
              </p>
              <div className="text-xs text-slate-500 pt-2">
                Problem Statement ID: 26034
              </div>
            </div>

            <div>
              <p className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">Platform</p>
              <ul className="space-y-2 text-xs">
                <li><Link to="/" className="hover:text-white transition">Overview</Link></li>
                <li><Link to="/demo" className="hover:text-white transition">Try Public Demo</Link></li>
                <li><Link to="/login" className="hover:text-white transition">Operator Portal</Link></li>
                <li><Link to="/signup" className="hover:text-white transition">Inspector Registration</Link></li>
              </ul>
            </div>

            <div>
              <p className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">Legal Framework</p>
              <ul className="space-y-2 text-xs">
                <li><Link to="/about" className="hover:text-white transition">Rules 2011 Schedule II</Link></li>
                <li><Link to="/about" className="hover:text-white transition">MRP & USP Guidelines</Link></li>
                <li><Link to="/about" className="hover:text-white transition">Net Quantity Tables</Link></li>
                <li><Link to="/about" className="hover:text-white transition">Consumer Care Redressal</Link></li>
              </ul>
            </div>

            <div>
              <p className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">Legal Disclaimer</p>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                This platform generates AI-assisted screening results based on configured Legal Metrology rules. Results serve as an enforcement aid and do not constitute a final legal adjudication without inspector review.
              </p>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-800 text-xs text-slate-500 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p>© 2026 PackCheck Enforcement Platform. All rights reserved.</p>
            <div className="flex items-center gap-4">
              <span>National Compliance Initiative</span>
              <span>•</span>
              <span>Privacy & Security Assured</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PublicLayout;
