/**
 * Centralized image URL resolver for PackCheck.
 *
 * Resolves image URLs from the database to actual fetchable HTTP URLs.
 *
 * Database stores either:
 *   - Relative paths:  /uploads/inspections/INSP-2026-0847/front-abc123.jpg
 *   - External CDN:    https://images.unsplash.com/...
 *   - Data URI / Base64: data:image/png;base64,...
 */

export const getBackendBaseUrl = () => {
  const envUrl = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/+$/, '');
  if (envUrl) {
    return envUrl;
  }
  // In Capacitor Android WebView, window.location.origin is https://localhost or capacitor://localhost
  // If no env variable is set, default to LAN or local port 5000
  if (typeof window !== 'undefined') {
    if (
      window.location.origin.includes('localhost') && 
      (window.location.protocol === 'capacitor:' || window.location.protocol === 'http:' || window.location.port === '')
    ) {
      // Running inside Capacitor webview without explicit base URL
      return 'http://10.0.58.1:5000';
    }
  }
  return '';
};

/**
 * Resolves a stored image URL/path to a usable src for <img> elements.
 *
 * @param {string|null|undefined} urlPath - The value from DB or API response.
 * @returns {string} A URL safe to use in <img src="">.
 */
export const getImageUrl = (urlPath) => {
  if (!urlPath || typeof urlPath !== 'string' || !urlPath.trim()) {
    return getFallbackImage();
  }

  const trimmed = urlPath.trim();

  // Already an absolute external URL (CDN, http/https) or data/blob URI — use as-is
  if (
    trimmed.startsWith('http://') || 
    trimmed.startsWith('https://') || 
    trimmed.startsWith('data:image/') ||
    trimmed.startsWith('blob:')
  ) {
    return trimmed;
  }

  // Normalize Windows backslashes if any exist in the path
  const normalized = trimmed.replace(/\\/g, '/');

  // If path contains /uploads/ anywhere (e.g. from absolute file path or relative path)
  const uploadsIdx = normalized.indexOf('/uploads/');
  if (uploadsIdx !== -1) {
    const relativePart = normalized.slice(uploadsIdx);
    const base = getBackendBaseUrl();
    return base ? `${base}${relativePart}` : relativePart;
  }

  if (normalized.startsWith('uploads/')) {
    const base = getBackendBaseUrl();
    return base ? `${base}/${normalized}` : `/${normalized}`;
  }

  if (normalized.startsWith('/api/')) {
    const base = getBackendBaseUrl();
    return base ? `${base}${normalized}` : normalized;
  }

  // Unknown format — attempt relative prepend if base exists
  const base = getBackendBaseUrl();
  if (base && normalized.startsWith('/')) {
    return `${base}${normalized}`;
  }

  return normalized;
};

/**
 * Returns an inline SVG data URL as a fallback placeholder for missing images.
 */
export const getFallbackImage = () => {
  return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='600' viewBox='0 0 600 600'%3E%3Crect width='600' height='600' fill='%230f172a'/%3E%3Ccircle cx='300' cy='260' r='60' fill='%231e293b' stroke='%23334155' stroke-width='2'/%3E%3Cpath d='M270 240 L330 300 M330 240 L270 300' stroke='%2394a3b8' stroke-width='4' stroke-linecap='round'/%3E%3Ctext x='300' y='360' fill='%2394a3b8' font-size='16' font-family='sans-serif' text-anchor='middle'%3EImage Not Available%3C/text%3E%3Ctext x='300' y='385' fill='%2364748b' font-size='12' font-family='sans-serif' text-anchor='middle'%3EProduct evidence image could not be loaded%3C/text%3E%3C/svg%3E`;
};

export default getImageUrl;
