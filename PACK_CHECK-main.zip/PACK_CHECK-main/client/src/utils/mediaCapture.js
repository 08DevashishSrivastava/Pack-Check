import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';

/**
 * Converts a Capacitor webPath or dataUrl into a standard Web File object
 */
async function uriToFile(uri, fileName = `capture-${Date.now()}.jpg`, mimeType = 'image/jpeg') {
  const response = await fetch(uri);
  const blob = await response.blob();
  return new File([blob], fileName, { type: blob.type || mimeType });
}

/**
 * Capture a photo using the native field camera or web camera input
 */
export async function capturePhotoFromCamera(options = {}) {
  try {
    const isNative = Capacitor.isNativePlatform();

    const photo = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      promptLabelHeader: 'Camera',
      promptLabelPhoto: 'Take Photo',
      ...options
    });

    if (!photo || !photo.webPath) {
      return null;
    }

    const fileName = `camera-${Date.now()}.${photo.format || 'jpg'}`;
    const file = await uriToFile(photo.webPath, fileName, `image/${photo.format || 'jpeg'}`);

    return {
      file,
      previewUrl: photo.webPath,
      fileName
    };
  } catch (error) {
    if (error.message?.includes('cancelled') || error.message?.includes('User cancelled') || error.message?.includes('no image picked')) {
      return null; // User simply backed out or cancelled
    }
    console.warn('[Camera] Capture error or cancelled:', error.message);
    throw error;
  }
}

/**
 * Pick an existing photo from the photo library / gallery
 */
export async function pickPhotoFromGallery(options = {}) {
  try {
    const photo = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.Uri,
      source: CameraSource.Photos,
      promptLabelHeader: 'Select Photo',
      promptLabelPhoto: 'Choose from Gallery',
      ...options
    });

    if (!photo || !photo.webPath) {
      return null;
    }

    const fileName = `gallery-${Date.now()}.${photo.format || 'jpg'}`;
    const file = await uriToFile(photo.webPath, fileName, `image/${photo.format || 'jpeg'}`);

    return {
      file,
      previewUrl: photo.webPath,
      fileName
    };
  } catch (error) {
    if (error.message?.includes('cancelled') || error.message?.includes('User cancelled') || error.message?.includes('no image picked')) {
      return null;
    }
    console.warn('[Gallery] Pick error or cancelled:', error.message);
    throw error;
  }
}

export default {
  capturePhotoFromCamera,
  pickPhotoFromGallery
};
