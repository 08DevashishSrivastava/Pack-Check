import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import api from '../services/api';

/**
 * Converts an ArrayBuffer to a Base64 string.
 */
function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

/**
 * Downloads, saves, and opens/shares an inspection PDF report.
 * Works seamlessly across both Web Browser and Native Capacitor Android.
 *
 * @param {string} inspectionId - The inspection ID (e.g. INSP-2026-0855)
 * @param {string} productName - Product name for display/title
 * @returns {Promise<{ success: boolean, message?: string }>}
 */
export const exportInspectionPdf = async (inspectionId, productName = 'Packaged Commodity') => {
  try {
    const filename = `PackCheck-Notice-${inspectionId}.pdf`;

    // Fetch PDF binary directly from the authenticated API
    const response = await api.get(`/inspections/${inspectionId}/report/pdf`, {
      responseType: 'arraybuffer'
    });

    const pdfBuffer = response.data || response;

    if (!pdfBuffer || pdfBuffer.byteLength === 0) {
      throw new Error('Received empty PDF data from server.');
    }

    const isNative = Capacitor.isNativePlatform();

    if (isNative) {
      // ── Capacitor Native Android Workflow ─────────────────────────────────
      const base64Data = arrayBufferToBase64(pdfBuffer);

      // Write PDF to device Cache directory
      const fileResult = await Filesystem.writeFile({
        path: filename,
        data: base64Data,
        directory: Directory.Cache
      });

      console.log('[PDF Export] Native file written at:', fileResult.uri);

      // Open Android native share / open sheet
      await Share.share({
        title: 'PackCheck Audit Notice',
        text: `Legal Metrology Inspection Notice for ${productName} (${inspectionId})`,
        url: fileResult.uri,
        dialogTitle: 'Open / Save PackCheck Audit Notice'
      });

      return { success: true, message: 'Inspection Notice opened on device.' };
    } else {
      // ── Desktop Web Browser Workflow ──────────────────────────────────────
      const blob = new Blob([pdfBuffer], { type: 'application/pdf' });
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => window.URL.revokeObjectURL(downloadUrl), 2000);

      return { success: true, message: 'Inspection Notice downloaded successfully.' };
    }
  } catch (error) {
    console.error('[PDF Export Error]:', error);
    throw error;
  }
};

export default exportInspectionPdf;
