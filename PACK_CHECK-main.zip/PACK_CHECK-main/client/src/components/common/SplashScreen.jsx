import React from 'react';

export const SplashScreen = () => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900 text-white select-none">
      <div className="flex flex-col items-center space-y-4">
        <div className="flex items-center gap-3">
          <img
            src="/logo.png"
            alt="PackCheck Logo"
            className="h-14 w-14 object-contain"
          />
          <span className="text-2xl font-extrabold tracking-tight text-white">
            Pack<span className="text-blue-500">Check</span>
          </span>
        </div>
        <div className="flex items-center gap-2 pt-2">
          <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs font-semibold tracking-wider text-slate-400">Verifying session...</span>
        </div>
      </div>
      <div className="absolute bottom-8 text-center">
        <p className="text-[10px] text-slate-500 font-bold tracking-wider uppercase">
          Legal Metrology Compliance Enforcement • Govt. Portal
        </p>
      </div>
    </div>
  );
};

export default SplashScreen;
