import React from 'react';
import { CheckCircle2, XCircle, AlertTriangle, HelpCircle, ShieldAlert } from 'lucide-react';
import { cn } from '../../utils/cn';

export const StatusBadge = ({ status, size = 'md', className = '' }) => {
  const normalized = (status || '').toUpperCase();

  const configs = {
    COMPLIANT: {
      label: 'COMPLIANT',
      icon: CheckCircle2,
      bg: 'bg-emerald-50 text-emerald-800 border-emerald-200 ring-1 ring-emerald-500/20',
      dot: 'bg-emerald-500'
    },
    NON_COMPLIANT: {
      label: 'NON-COMPLIANT',
      icon: XCircle,
      bg: 'bg-rose-50 text-rose-800 border-rose-200 ring-1 ring-rose-500/20',
      dot: 'bg-rose-500'
    },
    NEEDS_REVIEW: {
      label: 'NEEDS REVIEW',
      icon: AlertTriangle,
      bg: 'bg-amber-50 text-amber-800 border-amber-200 ring-1 ring-amber-500/20',
      dot: 'bg-amber-500'
    },
    VIOLATION: {
      label: 'VIOLATION',
      icon: ShieldAlert,
      bg: 'bg-rose-50 text-rose-800 border-rose-200 ring-1 ring-rose-500/20',
      dot: 'bg-rose-500'
    },
    WARNING: {
      label: 'WARNING',
      icon: AlertTriangle,
      bg: 'bg-amber-50 text-amber-800 border-amber-200 ring-1 ring-amber-500/20',
      dot: 'bg-amber-500'
    },
    DETECTED: {
      label: 'DETECTED',
      icon: CheckCircle2,
      bg: 'bg-blue-50 text-blue-800 border-blue-200 ring-1 ring-blue-500/20',
      dot: 'bg-blue-500'
    },
    MISSING: {
      label: 'MISSING',
      icon: XCircle,
      bg: 'bg-rose-50 text-rose-800 border-rose-200 ring-1 ring-rose-500/20',
      dot: 'bg-rose-500'
    },
    CRITICAL: {
      label: 'CRITICAL',
      icon: ShieldAlert,
      bg: 'bg-rose-100 text-rose-900 border-rose-300 font-semibold',
      dot: 'bg-rose-600'
    },
    HIGH: {
      label: 'HIGH',
      icon: AlertTriangle,
      bg: 'bg-orange-50 text-orange-800 border-orange-200',
      dot: 'bg-orange-500'
    },
    MEDIUM: {
      label: 'MEDIUM',
      icon: AlertTriangle,
      bg: 'bg-amber-50 text-amber-800 border-amber-200',
      dot: 'bg-amber-500'
    },
    LOW: {
      label: 'LOW',
      icon: HelpCircle,
      bg: 'bg-slate-100 text-slate-700 border-slate-200',
      dot: 'bg-slate-400'
    }
  };

  const config = configs[normalized] || {
    label: status || 'UNKNOWN',
    icon: HelpCircle,
    bg: 'bg-slate-50 text-slate-700 border-slate-200',
    dot: 'bg-slate-400'
  };

  const Icon = config.icon;

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5 font-medium',
    lg: 'text-sm px-3 py-1.5 gap-2 font-semibold'
  };

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border shadow-2xs transition-colors',
        config.bg,
        sizeClasses[size] || sizeClasses.md,
        className
      )}
    >
      <Icon className={cn(size === 'sm' ? 'w-3 h-3' : size === 'lg' ? 'w-4 h-4' : 'w-3.5 h-3.5')} />
      <span>{config.label}</span>
    </span>
  );
};

export default StatusBadge;
