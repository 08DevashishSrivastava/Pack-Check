import React from 'react';
import { cn } from '../../utils/cn';

export const StatCard = ({ title, value, subtitle, icon: Icon, color = 'blue', trend }) => {
  const colorMap = {
    blue: {
      iconBg: 'bg-blue-100 text-blue-700',
      border: 'border-slate-200 hover:border-blue-300'
    },
    emerald: {
      iconBg: 'bg-emerald-100 text-emerald-700',
      border: 'border-slate-200 hover:border-emerald-300'
    },
    rose: {
      iconBg: 'bg-rose-100 text-rose-700',
      border: 'border-slate-200 hover:border-rose-300'
    },
    amber: {
      iconBg: 'bg-amber-100 text-amber-700',
      border: 'border-slate-200 hover:border-amber-300'
    }
  };

  const theme = colorMap[color] || colorMap.blue;

  return (
    <div className={cn('bg-white p-5 rounded-xl border shadow-subtle transition-all duration-200 hover:shadow-card', theme.border)}>
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{title}</p>
        {Icon && (
          <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center', theme.iconBg)}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>
      <div className="mt-3 flex items-baseline gap-2">
        <p className="text-3xl font-bold tracking-tight text-slate-900">{value}</p>
        {trend && (
          <span className={cn('text-xs font-medium', trend > 0 ? 'text-emerald-600' : 'text-slate-500')}>
            {trend > 0 ? `+${trend}%` : `${trend}%`} vs last mo.
          </span>
        )}
      </div>
      {subtitle && <p className="mt-1 text-xs text-slate-500">{subtitle}</p>}
    </div>
  );
};

export default StatCard;
