import React, { useState, useRef, useEffect } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Eye } from 'lucide-react';
import { cn } from '../../utils/cn';
import { getImageUrl, getFallbackImage } from '../../utils/imageUrl';

export const EvidenceViewer = ({
  imageUrl,
  boundingBoxes = [],
  activeBoxId = null,
  onSelectBox = null,
  title = 'Product Label & Evidence Region',
  // Optional: server-provided image dimensions (from OCR service)
  imageWidth = null,
  imageHeight = null
}) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [showBoxes, setShowBoxes] = useState(true);
  const [imgSrc, setImgSrc] = useState(() => getImageUrl(imageUrl));
  const [imgError, setImgError] = useState(false);
  // Natural image dimensions for accurate SVG viewBox
  const [naturalWidth, setNaturalWidth] = useState(imageWidth || 800);
  const [naturalHeight, setNaturalHeight] = useState(imageHeight || 800);
  const imgRef = useRef(null);

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.25, 2.5));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.25, 0.75));
  const handleResetZoom = () => setZoomLevel(1);

  // Sync state whenever imageUrl prop updates
  useEffect(() => {
    const resolved = getImageUrl(imageUrl);
    console.log('[EvidenceViewer] Rendering image URL:', resolved);
    setImgSrc(resolved);
    setImgError(false);
  }, [imageUrl]);

  // When the image loads, read its natural dimensions so SVG viewBox is exact
  const handleImageLoad = (e) => {
    const { naturalWidth: nw, naturalHeight: nh } = e.target;
    if (nw > 0 && nh > 0 && !imgError) {
      setNaturalWidth(nw);
      setNaturalHeight(nh);
    }
  };

  const handleImageError = () => {
    if (!imgError) {
      console.warn('[EvidenceViewer] Image load failed for source:', imgSrc);
      setImgError(true);
      setImgSrc(getFallbackImage());
    }
  };

  // If server provided dimensions, use those immediately
  useEffect(() => {
    if (imageWidth && imageHeight) {
      setNaturalWidth(imageWidth);
      setNaturalHeight(imageHeight);
    }
  }, [imageWidth, imageHeight]);

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden border border-slate-800 text-white shadow-elevated">
      {/* Header controls */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-950/80 border-b border-slate-800 backdrop-blur-xs">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-blue-400" />
          <span className="text-xs font-semibold text-slate-200 tracking-wide uppercase">{title}</span>
        </div>
        <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setShowBoxes(!showBoxes)}
            className={cn(
              'px-2 py-1 text-xs rounded font-medium transition-colors',
              showBoxes ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            )}
            title="Toggle Bounding Boxes"
          >
            {showBoxes ? 'BBoxes ON' : 'BBoxes OFF'}
          </button>
          <div className="h-4 w-px bg-slate-700 mx-1" />
          <button
            onClick={handleZoomOut}
            className="p-1 text-slate-400 hover:text-white transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-[11px] font-mono text-slate-400 min-w-8 text-center">
            {Math.round(zoomLevel * 100)}%
          </span>
          <button
            onClick={handleZoomIn}
            className="p-1 text-slate-400 hover:text-white transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={handleResetZoom}
            className="p-1 text-slate-400 hover:text-white transition-colors"
            title="Reset Zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Image & Overlay Canvas Container */}
      <div className="relative flex-1 min-h-[380px] max-h-[550px] overflow-auto flex items-center justify-center p-4 bg-slate-950/40">
        <div
          className="relative inline-block transition-transform duration-150 origin-center select-none"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          <img
            ref={imgRef}
            src={imgSrc}
            alt="Product Evidence"
            crossOrigin="anonymous"
            className="max-h-[460px] w-auto object-contain rounded-lg border border-slate-800 shadow-2xl block"
            onLoad={handleImageLoad}
            onError={handleImageError}
          />

          {/* SVG Overlay for Bounding Boxes — viewBox uses real image pixel dimensions */}
          {showBoxes && boundingBoxes.some(b => b.bbox) && (
            <svg
              className="absolute inset-0 w-full h-full pointer-events-auto"
              viewBox={`0 0 ${naturalWidth} ${naturalHeight}`}
              preserveAspectRatio="none"
            >
              {boundingBoxes.map((item, idx) => {
                if (!item.bbox) return null;
                const { x, y, width, height } = item.bbox;
                if (width <= 0 || height <= 0) return null;

                const isViolation = item.status === 'VIOLATION' || item.status === 'NON_COMPLIANT';
                const isWarning = item.status === 'WARNING' || item.status === 'NEEDS_REVIEW';
                const isActive = activeBoxId === (item.id || item.field || idx);

                let strokeColor = '#3B82F6'; // blue = compliant
                let fillColor = 'rgba(59, 130, 246, 0.18)';
                if (isViolation) {
                  strokeColor = '#EF4444'; // red
                  fillColor = 'rgba(239, 68, 68, 0.25)';
                } else if (isWarning) {
                  strokeColor = '#F59E0B'; // amber
                  fillColor = 'rgba(245, 158, 11, 0.22)';
                }
                if (isActive) {
                  strokeColor = '#FACC15';
                  fillColor = 'rgba(250, 204, 21, 0.35)';
                }

                const labelFontSize = Math.max(8, Math.round(naturalWidth / 80));
                const labelHeight = labelFontSize + 4;

                return (
                  <g
                    key={item.id || idx}
                    className="cursor-pointer transition-all duration-200 group"
                    onClick={() => onSelectBox && onSelectBox(item)}
                  >
                    <rect
                      x={x}
                      y={y}
                      width={width}
                      height={height}
                      fill={fillColor}
                      stroke={strokeColor}
                      strokeWidth={isActive ? 3 : 1.5}
                      strokeDasharray={isWarning ? '4 2' : undefined}
                      rx={2}
                      className="transition-colors hover:fill-opacity-40"
                    />
                    {/* Bounding box label */}
                    <rect
                      x={x}
                      y={Math.max(0, y - labelHeight)}
                      width={Math.min(width, Math.max(40, ((item.field || item.text || '').length * (labelFontSize * 0.6) + 6)))}
                      height={labelHeight}
                      fill={strokeColor}
                      rx={1}
                    />
                    <text
                      x={x + 3}
                      y={Math.max(labelFontSize, y - 2)}
                      fill="#FFFFFF"
                      fontSize={labelFontSize}
                      fontFamily="monospace"
                      fontWeight="bold"
                      className="pointer-events-none select-none"
                    >
                      {(item.field || item.text || '').slice(0, 16)}
                    </text>
                  </g>
                );
              })}
            </svg>
          )}
        </div>
      </div>

      {/* Footer Instructions */}
      <div className="px-4 py-2 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <span>Click highlighted regions to inspect statutory clauses</span>
        <span className="font-mono text-slate-500">
          Source Resolution: {naturalWidth} × {naturalHeight} px
        </span>
      </div>
    </div>
  );
};

export default EvidenceViewer;
