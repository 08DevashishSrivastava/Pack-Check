import React from 'react';
import { cn } from '../../utils/cn';

export const ScoreBadge = ({ score, size = 'md' }) => {
  const hasScore = score !== null && score !== undefined && Number.isFinite(Number(score));
  const numScore = hasScore ? Number(score) : null;

  let colorClasses = 'text-emerald-700 bg-emerald-50 border-emerald-300';
  if (!hasScore) {
    colorClasses = 'text-slate-600 bg-slate-50 border-slate-300';
  } else if (numScore < 70) {
    colorClasses = 'text-rose-700 bg-rose-50 border-rose-300';
  } else if (numScore < 85) {
    colorClasses = 'text-amber-700 bg-amber-50 border-amber-300';
  }

  const sizes = {
    sm: 'text-xs px-2 py-0.5 font-semibold',
    md: 'text-sm px-2.5 py-1 font-bold',
    lg: 'text-base px-3.5 py-1.5 font-extrabold'
  };

  return (
    <span className={cn('inline-flex items-center gap-1 rounded-md border', colorClasses, sizes[size])}>
      <span>{hasScore ? `${numScore}%` : 'Score unavailable'}</span>
      <span className="text-[10px] font-medium opacity-80 uppercase">Score</span>
    </span>
  );
};

export default ScoreBadge;
