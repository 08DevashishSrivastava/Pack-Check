import api from './api';

export const inspectionApi = {
  getInspections: async (params) => {
    try {
      const res = await api.get('/inspections', { params });
      return res;
    } catch (err) {
      throw err;
    }
  },

  getInspectionById: async (id) => {
    try {
      const res = await api.get(`/inspections/${id}`);
      return res;
    } catch (err) {
      throw err;
    }
  },

  /**
   * Create a new inspection.
   * Accepts either a plain JSON object or a FormData instance.
   * When FormData is passed (multipart file upload), the Content-Type header
   * is cleared so the browser automatically sets multipart boundaries.
   */
  createInspection: async (data) => {
    try {
      const isFormData = data instanceof FormData;
      const res = await api.post('/inspections', data, {
        headers: isFormData
          ? { 'Content-Type': undefined }   // let browser set multipart/form-data + boundary
          : { 'Content-Type': 'application/json' },
        // Increase timeout for file uploads
        timeout: 60000
      });
      return res;
    } catch (err) {
      throw err;
    }
  }
};

export default inspectionApi;
