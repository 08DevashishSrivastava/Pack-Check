import api from './api';

export const productApi = {
  getProducts: async () => {
    try {
      const res = await api.get('/products');
      return res.data?.data || res.data || [];
    } catch {
      return [];
    }
  },

  getProductById: async (id) => {
    try {
      const res = await api.get(`/products/${id}`);
      return res.data?.data || res.data || null;
    } catch {
      return null;
    }
  }
};

export const violationApi = {
  getViolations: async (params = {}) => {
    try {
      const res = await api.get('/violations', { params });
      return res.data?.data || res.data || [];
    } catch (err) {
      console.error('Failed to fetch violations from API:', err.message);
      return [];
    }
  },

  getViolationsByInspection: async (inspectionId) => {
    try {
      const res = await api.get('/violations', { params: { inspection_id: inspectionId } });
      return res.data?.data || res.data || [];
    } catch (err) {
      console.error('Failed to fetch violations for inspection:', err.message);
      return [];
    }
  }
};

export const reportApi = {
  getReports: async () => {
    try {
      const res = await api.get('/reports');
      // Normalize to expected shape
      const rows = res.data?.data || res.data || [];
      return rows.map(r => ({
        id: r.inspection_id,
        inspection_id: r.inspection_id,
        title: `Compliance Inspection Report — ${r.product_name || 'Unknown Product'}`,
        product: r.product_name || 'Unknown Product',
        brand: r.brand,
        category: r.category,
        date: r.inspection_date ? new Date(r.inspection_date).toISOString() : new Date().toISOString(),
        status: r.status,
        score: r.score,
        violations_count: r.violation_count || r.failed_rules || 0,
        passed_rules: r.passed_rules || 0,
        failed_rules: r.failed_rules || 0,
        warning_rules: r.warning_rules || 0,
        generated_by: r.inspector_name || 'Duty Inspector'
      }));
    } catch (err) {
      console.error('Failed to fetch reports from API:', err.message);
      return [];
    }
  }
};
