import api from './api';

export const demoSampleProducts = [
  {
    id: 'sample-parle-g',
    name: 'Parle-G Original Gluco Biscuits',
    category: 'Food & Beverages / Biscuits',
    image: '/samples/parle_g_biscuit_pack.png',
    description: 'Parle-G glucose biscuits principal display panel with standard mandatory declarations.'
  },
  {
    id: 'sample-cadbury',
    name: 'Cadbury Dairy Milk Silk 150g',
    category: 'Confectionery / Chocolate',
    image: '/samples/cadbury_dairy_milk_silk.png',
    description: 'Milk chocolate packaging wrapper with nutritional and manufacturer declarations.'
  },
  {
    id: 'sample-honey',
    name: 'NaturePure Organic Raw Honey 500g',
    category: 'Natural Foods / Honey',
    image: '/samples/organic_raw_honey.png',
    description: 'Raw forest honey container label with statutory packing details.'
  },
  {
    id: 'sample-shampoo',
    name: 'Keval Herbal Shampoo 350ml',
    category: 'Personal Care / Cosmetics',
    image: '/samples/keval_herbal_shampoo.png',
    description: 'Cosmetic packaged bottle with consumer care, MRP, and origin labeling.'
  }
];

export const demoService = {
  /**
   * Run real AI compliance analysis on a package image via backend Gemini Vision & Rule Engine.
   * @param {Object} options - { file: File, sampleId: string, onProgress: Function }
   */
  analyzePackageImage: async ({ file, sampleId, onProgress }) => {
    const steps = [
      { step: 1, text: 'Uploading inspection image...' },
      { step: 2, text: 'Executing Gemini Vision AI analysis on package...' },
      { step: 3, text: 'Extracting mandatory Legal Metrology declarations...' },
      { step: 4, text: 'Evaluating Legal Metrology Rules & Amendments (LM-PC-2026.08)...' },
      { step: 5, text: 'Generating compliance score & saving investigation...' }
    ];

    if (onProgress) onProgress(steps[0]);

    const formData = new FormData();
    if (file) {
      formData.append('images', file, file.name);
    } else if (sampleId) {
      formData.append('sample_id', sampleId);
    } else {
      formData.append('sample_id', 'sample-parle-g');
    }

    // Step progression timer for smooth user experience while backend processes
    let stepIndex = 0;
    const progressTimer = setInterval(() => {
      stepIndex = Math.min(stepIndex + 1, steps.length - 2);
      if (onProgress) onProgress(steps[stepIndex]);
    }, 1800);

    try {
      const response = await api.post('/inspections/analyze', formData, {
        headers: { 'Content-Type': undefined },
        timeout: 90000
      });

      clearInterval(progressTimer);
      if (onProgress) onProgress(steps[steps.length - 1]);

      const result = response.data || response;
      return result;
    } catch (error) {
      clearInterval(progressTimer);
      throw error;
    }
  }
};

export default demoService;
