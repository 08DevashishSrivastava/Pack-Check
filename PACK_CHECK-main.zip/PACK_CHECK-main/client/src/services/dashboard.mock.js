export const mockDashboardData = {
  summary: {
    totalInspections: 135,
    compliantCount: 94,
    nonCompliantCount: 28,
    needsReviewCount: 13,
    complianceRate: 70
  },
  complianceTrend: [
    { month: 'Mar', inspections: 42, compliant: 35, nonCompliant: 7 },
    { month: 'Apr', inspections: 58, compliant: 46, nonCompliant: 12 },
    { month: 'May', inspections: 74, compliant: 58, nonCompliant: 16 },
    { month: 'Jun', inspections: 89, compliant: 72, nonCompliant: 17 },
    { month: 'Jul', inspections: 112, compliant: 88, nonCompliant: 24 },
    { month: 'Aug', inspections: 135, compliant: 94, nonCompliant: 28 }
  ],
  violationCategories: [
    { category: 'Net Quantity / Numeral Height', count: 22, percentage: 35 },
    { category: 'Unit Sale Price (USP)', count: 16, percentage: 25 },
    { category: 'MRP / Suffix Format', count: 12, percentage: 19 },
    { category: 'Consumer Care Hotline', count: 8, percentage: 13 },
    { category: 'Date of Mfg / Packing Format', count: 5, percentage: 8 }
  ],
  statusDistribution: [
    { name: 'Compliant', value: 94, color: '#059669' },
    { name: 'Non-Compliant', value: 28, color: '#DC2626' },
    { name: 'Needs Review', value: 13, color: '#D97706' }
  ],
  recentInspections: [
    {
      id: 'INSP-2026-0841',
      product: 'NutriCrunch Digestive Oats & Honey Biscuits 200g',
      date: '2026-08-22T10:30:00Z',
      score: 64,
      status: 'NON_COMPLIANT',
      inspector: 'Inspector Rajesh Sharma'
    },
    {
      id: 'INSP-2026-0840',
      product: 'PureGlo Revitalizing Aloe Vera Face Wash 150ml',
      date: '2026-08-21T14:10:00Z',
      score: 96,
      status: 'COMPLIANT',
      inspector: 'Inspector Rajesh Sharma'
    },
    {
      id: 'INSP-2026-0839',
      product: 'SunSpice Organic Turmeric Powder 500g',
      date: '2026-08-20T11:45:00Z',
      score: 76,
      status: 'NEEDS_REVIEW',
      inspector: 'Inspector Rajesh Sharma'
    },
    {
      id: 'INSP-2026-0838',
      product: 'SparkleTech Multi-Surface Disinfectant Spray 500ml',
      date: '2026-08-19T16:20:00Z',
      score: 55,
      status: 'NON_COMPLIANT',
      inspector: 'Inspector Rajesh Sharma'
    },
    {
      id: 'INSP-2026-0837',
      product: 'Himalayan Spring Herbal Green Tea 100g',
      date: '2026-08-18T09:15:00Z',
      score: 92,
      status: 'COMPLIANT',
      inspector: 'Inspector Rajesh Sharma'
    }
  ]
};
