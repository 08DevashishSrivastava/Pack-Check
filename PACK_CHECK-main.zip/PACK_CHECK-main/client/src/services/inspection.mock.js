export const mockInspections = [
  {
    id: 'INSP-2026-0841',
    product_name: 'NutriCrunch Digestive Oats & Honey Biscuits 200g',
    brand: 'NutriCrunch Foods',
    category: 'Food & Beverages',
    inspector_name: 'Inspector Rajesh Sharma',
    date: '2026-08-22T10:30:00Z',
    status: 'NON_COMPLIANT',
    score: 64,
    total_declarations: 8,
    passed_rules: 5,
    failed_rules: 2,
    warning_rules: 1,
    images: [
      {
        id: 'img-1',
        type: 'FRONT',
        url: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800&auto=format&fit=crop&q=80',
        detected_text: 'NutriCrunch Digestive Biscuits 200g MRP Rs 45.00'
      },
      {
        id: 'img-2',
        type: 'BACK',
        url: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800&auto=format&fit=crop&q=80',
        detected_text: 'Mfg Date: 05/2026, Best Before: 9 Months, Consumer Care: customercare@nutricrunch.in, Lic No: 10014022002341'
      }
    ],
    declarations: [
      { field: 'Product Name', value: 'Digestive Oats & Honey Biscuits', confidence: 0.98, status: 'DETECTED', image_id: 'img-1', bbox: { x: 120, y: 80, width: 280, height: 45 } },
      { field: 'Net Quantity', value: '200 g (Font height 2.2mm)', confidence: 0.94, status: 'NON_COMPLIANT', image_id: 'img-1', bbox: { x: 150, y: 220, width: 140, height: 35 } },
      { field: 'Maximum Retail Price (MRP)', value: '₹45.00 (Inclusive of all taxes)', confidence: 0.96, status: 'WARNING', image_id: 'img-1', bbox: { x: 320, y: 220, width: 160, height: 40 } },
      { field: 'Manufacturer Name & Address', value: 'NutriCrunch Consumer Products Pvt Ltd, Solan, HP', confidence: 0.91, status: 'DETECTED', image_id: 'img-2', bbox: { x: 80, y: 110, width: 320, height: 60 } },
      { field: 'Date of Manufacture / Packing', value: '05/2026', confidence: 0.95, status: 'DETECTED', image_id: 'img-2', bbox: { x: 80, y: 190, width: 220, height: 35 } },
      { field: 'Consumer Care Details', value: 'customercare@nutricrunch.in, Tel: 1800-200-1122', confidence: 0.97, status: 'DETECTED', image_id: 'img-2', bbox: { x: 80, y: 240, width: 340, height: 40 } },
      { field: 'Country of Origin', value: 'India', confidence: 0.93, status: 'DETECTED', image_id: 'img-2', bbox: { x: 80, y: 290, width: 150, height: 30 } },
      { field: 'Unit Sale Price (USP)', value: 'NOT DECLARED', confidence: 0.89, status: 'MISSING', image_id: 'img-1', bbox: null }
    ],
    violations: [
      {
        id: 'viol-001',
        rule_code: 'LM-RULE-06-NETQTY-FONT',
        title: 'Net Quantity Font Height Below Minimum Statutory Size',
        severity: 'HIGH',
        status: 'VIOLATION',
        detected_value: '2.2 mm font height for 200g package',
        expected_condition: 'Minimum 3.0 mm numeral height required for packages between 100g and 500g under Schedule II, Table-I',
        confidence: 0.94,
        recommendation: 'Enforce minimum 3.0 mm numeral height across all principal display surfaces.',
        image_id: 'img-1',
        bbox: { x: 150, y: 220, width: 140, height: 35 }
      },
      {
        id: 'viol-002',
        rule_code: 'LM-RULE-06-USP',
        title: 'Mandatory Unit Sale Price (USP) Declaration Missing',
        severity: 'CRITICAL',
        status: 'VIOLATION',
        detected_value: 'Unit Sale Price (e.g. ₹0.225 / g or ₹22.50 / 100g) absent on principal display panel',
        expected_condition: 'Mandatory declaration of Unit Sale Price alongside MRP for packages containing net quantity > 1 unit/100g/100ml under amended Rule 6(1)(h)',
        confidence: 0.96,
        recommendation: 'Add Unit Sale Price declaration e.g. "₹22.50 per 100 g" prominently alongside MRP.',
        image_id: 'img-1',
        bbox: null
      }
    ]
  },
  {
    id: 'INSP-2026-0840',
    product_name: 'PureGlo Revitalizing Aloe Vera Face Wash 150ml',
    brand: 'PureGlo Skincare',
    category: 'Personal Care / Cosmetics',
    inspector_name: 'Inspector Rajesh Sharma',
    date: '2026-08-21T14:10:00Z',
    status: 'COMPLIANT',
    score: 96,
    total_declarations: 8,
    passed_rules: 8,
    failed_rules: 0,
    warning_rules: 0,
    images: [
      {
        id: 'img-1',
        type: 'FRONT',
        url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800&auto=format&fit=crop&q=80',
        detected_text: 'PureGlo Aloe Vera Face Wash 150 ml'
      }
    ],
    declarations: [
      { field: 'Product Name', value: 'Aloe Vera Face Wash', confidence: 0.99, status: 'DETECTED', image_id: 'img-1', bbox: { x: 100, y: 70, width: 250, height: 40 } },
      { field: 'Net Quantity', value: '150 ml (Font height 4.1mm)', confidence: 0.97, status: 'DETECTED', image_id: 'img-1', bbox: { x: 140, y: 210, width: 120, height: 30 } },
      { field: 'Maximum Retail Price (MRP)', value: '₹199.00 (Incl. of all taxes) | USP: ₹1.33 / ml', confidence: 0.98, status: 'DETECTED', image_id: 'img-1', bbox: { x: 280, y: 210, width: 180, height: 35 } },
      { field: 'Manufacturer Name & Address', value: 'Aura Cosmeceuticals Ltd, Baddi, HP', confidence: 0.95, status: 'DETECTED', image_id: 'img-1', bbox: { x: 90, y: 260, width: 300, height: 45 } },
      { field: 'Consumer Care Details', value: 'care@pureglo.in, Tel: 1800-419-8800', confidence: 0.98, status: 'DETECTED', image_id: 'img-1', bbox: { x: 90, y: 315, width: 320, height: 35 } }
    ],
    violations: []
  }
];
