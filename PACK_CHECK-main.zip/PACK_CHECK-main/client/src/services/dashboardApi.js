import api from './api';
import { mockDashboardData } from './dashboard.mock';

export const dashboardApi = {
  getStats: async () => {
    try {
      const res = await api.get('/dashboard/stats');
      return res.data || res;
    } catch (err) {
      console.error('[Dashboard API] Error fetching stats:', err);
      throw err;
    }
  }
};

export default dashboardApi;
