import axios from 'axios';
import { getBackendBaseUrl } from '../utils/imageUrl';

const API_BASE = getBackendBaseUrl();

const api = axios.create({
  baseURL: `${API_BASE}/api`,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor: Inject JWT
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('packcheck_auth_token') || localStorage.getItem('metro_auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor: Handle 401 Unauthenticated
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response && error.response.status === 401) {
      // If unauthorized and not on public pages, clear token
      if (window.location.pathname !== '/login' && 
          window.location.pathname !== '/signup' && 
          window.location.pathname !== '/' && 
          window.location.pathname !== '/demo') {
        localStorage.removeItem('packcheck_auth_token');
        localStorage.removeItem('packcheck_auth_user');
        localStorage.removeItem('metro_auth_token');
        localStorage.removeItem('metro_auth_user');
        window.location.href = '/login';
      }
    }
    const message = error.response?.data?.message || error.message || 'An unexpected error occurred.';
    return Promise.reject(new Error(message));
  }
);

export default api;
