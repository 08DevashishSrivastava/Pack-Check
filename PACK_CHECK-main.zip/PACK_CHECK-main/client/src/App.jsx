import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Capacitor } from '@capacitor/core';
import { AuthProvider, useAuth } from './context/AuthContext';

// Layouts & Guards
import PublicLayout from './layouts/PublicLayout';
import OperatorLayout from './layouts/OperatorLayout';
import ProtectedRoute from './layouts/ProtectedRoute';
import { SplashScreen as CapSplashScreen } from '@capacitor/splash-screen';
import SplashScreen from './components/common/SplashScreen';

// Public Pages
import LandingPage from './pages/public/LandingPage';
import LoginPage from './pages/public/LoginPage';
import SignupPage from './pages/public/SignupPage';
import DemoPage from './pages/public/DemoPage';
import AboutPage from './pages/public/AboutPage';

// Operator Pages
import DashboardPage from './pages/operator/DashboardPage';
import NewInspectionPage from './pages/operator/NewInspectionPage';
import AnalysisProgressPage from './pages/operator/AnalysisProgressPage';
import InspectionResultPage from './pages/operator/InspectionResultPage';
import InspectionHistoryPage from './pages/operator/InspectionHistoryPage';
import ProductsPage from './pages/operator/ProductsPage';
import ProductDetailPage from './pages/operator/ProductDetailPage';
import ViolationsPage from './pages/operator/ViolationsPage';
import ReportsPage from './pages/operator/ReportsPage';
import ReportDetailPage from './pages/operator/ReportDetailPage';
import AnalyticsPage from './pages/operator/AnalyticsPage';
import ProfilePage from './pages/operator/ProfilePage';
import SettingsPage from './pages/operator/SettingsPage';

import { useCapacitorBackButton } from './hooks/useCapacitorBackButton';

/**
 * Smart Native Android Entry:
 * - Shows SplashScreen while verifying session tokens
 * - Redirects to /dashboard if authenticated
 * - Redirects to /login if unauthenticated
 */
function NativeMobileEntry() {
  const { isAuthenticated, loading } = useAuth();
  if (loading) {
    return <SplashScreen />;
  }
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }
  return <Navigate to="/login" replace />;
}

function AppRoutes() {
  useCapacitorBackButton();
  const { loading, isAuthenticated } = useAuth();
  const isNative = Capacitor.isNativePlatform();

  React.useEffect(() => {
    if (!loading && isNative) {
      CapSplashScreen.hide().catch(() => {});
    }
  }, [loading, isNative]);

  // Show app splash during initial auth hydration
  if (loading) {
    return <SplashScreen />;
  }

  return (
    <Routes>
      {/* Public Routes */}
      <Route element={<PublicLayout />}>
        {/* On Native Android: enters NativeMobileEntry (auth check -> Login or Dashboard) */}
        {/* On Web Browser: renders standard public LandingPage */}
        <Route
          path="/"
          element={isNative ? <NativeMobileEntry /> : <LandingPage />}
        />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/demo" element={<DemoPage />} />
        <Route path="/about" element={<AboutPage />} />
      </Route>

      {/* Protected Operator Routes */}
      <Route element={<ProtectedRoute />}>
        <Route element={<OperatorLayout />}>
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/inspections" element={<InspectionHistoryPage />} />
          <Route path="/inspections/new" element={<NewInspectionPage />} />
          <Route path="/inspections/:id" element={<InspectionResultPage />} />
          <Route path="/inspections/:id/analyzing" element={<AnalysisProgressPage />} />
          <Route path="/inspections/:id/result" element={<InspectionResultPage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/products/:id" element={<ProductDetailPage />} />
          <Route path="/violations" element={<ViolationsPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/reports/:id" element={<ReportDetailPage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>
      </Route>

      {/* Fallback */}
      <Route
        path="*"
        element={
          <Navigate
            to={isNative ? (isAuthenticated ? '/dashboard' : '/login') : '/'}
            replace
          />
        }
      />
    </Routes>
  );
}

export function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
