import React, { useState } from 'react';
import { Settings, Bell, Shield, Sliders, Moon, Check } from 'lucide-react';

export const SettingsPage = () => {
  const [notifications, setNotifications] = useState(true);
  const [autoRotate, setAutoRotate] = useState(true);
  const [highContrast, setHighContrast] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">System &amp; Inspection Settings</h1>
          <p className="text-xs text-slate-500 mt-1">Configure inspectorate preferences, scanning defaults, and alerts.</p>
        </div>
        <button
          onClick={handleSave}
          className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow transition"
        >
          {saved ? <Check className="w-4 h-4" /> : null}
          <span>{saved ? 'Preferences Saved' : 'Save Changes'}</span>
        </button>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-6">
        <div className="space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600 border-b border-slate-100 pb-2">
            Inspection &amp; Screener Preferences
          </h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-800">Auto-Detect Principal Display Panel</p>
                <p className="text-[11px] text-slate-500">Automatically classify camera capture as FRONT / PDP</p>
              </div>
              <input
                type="checkbox"
                checked={autoRotate}
                onChange={() => setAutoRotate(!autoRotate)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-800">High Contrast Bounding Box Mode</p>
                <p className="text-[11px] text-slate-500">Render high-visibility borders in evidence viewer for outdoor sunlight use</p>
              </div>
              <input
                type="checkbox"
                checked={highContrast}
                onChange={() => setHighContrast(!highContrast)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-800">Infraction Notice Notifications</p>
                <p className="text-[11px] text-slate-500">Receive alerts when non-compliant commodities are flagged</p>
              </div>
              <input
                type="checkbox"
                checked={notifications}
                onChange={() => setNotifications(!notifications)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
          <span>Legal Metrology Engine: <strong>Rules 2011 (v1.0-STABLE)</strong></span>
          <span className="font-mono text-[11px]">Problem Statement ID: 26034</span>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
