import React from 'react';
import { User, Mail, Phone, Building2, Shield, Calendar, Award } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const ProfilePage = () => {
  const { user } = useAuth();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">Inspector Official Profile</h1>
          <p className="text-xs text-slate-500 mt-1">Legal Metrology Enforcement Officer Credentials</p>
        </div>
        <span className="bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full uppercase">
          {user?.role || 'INSPECTOR'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Officer Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle text-center space-y-4 flex flex-col items-center justify-center">
          <div className="w-20 h-20 rounded-full bg-blue-700 text-white flex items-center justify-center text-2xl font-bold shadow-md">
            {user?.name ? user.name.charAt(0).toUpperCase() : 'I'}
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">{user?.name || 'Duty Inspector'}</h2>
            <p className="text-xs text-slate-500 font-medium">{user?.department || 'Legal Metrology Inspectorate'}</p>
          </div>
          <div className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            <span>● Official Active Duty</span>
          </div>
        </div>

        {/* Details */}
        <div className="md:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 border-b border-slate-100 pb-2">
            Officer Particulars
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <p className="text-slate-400 font-semibold flex items-center gap-1.5 mb-1">
                <User className="w-3.5 h-3.5" /> Full Name
              </p>
              <p className="font-bold text-slate-800 text-sm">{user?.name || 'Inspector Rajesh Sharma'}</p>
            </div>

            <div>
              <p className="text-slate-400 font-semibold flex items-center gap-1.5 mb-1">
                <Mail className="w-3.5 h-3.5" /> Official Email
              </p>
              <p className="font-bold text-slate-800 text-sm">{user?.email || 'inspector@metrocheck.gov.in'}</p>
            </div>

            <div>
              <p className="text-slate-400 font-semibold flex items-center gap-1.5 mb-1">
                <Phone className="w-3.5 h-3.5" /> Contact Phone
              </p>
              <p className="font-bold text-slate-800 text-sm">{user?.phone || '+91 98765 43210'}</p>
            </div>

            <div>
              <p className="text-slate-400 font-semibold flex items-center gap-1.5 mb-1">
                <Building2 className="w-3.5 h-3.5" /> Department / Zone
              </p>
              <p className="font-bold text-slate-800 text-sm">{user?.department || 'Legal Metrology Department, Delhi Zone'}</p>
            </div>

            <div>
              <p className="text-slate-400 font-semibold flex items-center gap-1.5 mb-1">
                <Shield className="w-3.5 h-3.5" /> Designated Role
              </p>
              <p className="font-mono font-bold text-blue-700">{user?.role || 'INSPECTOR'}</p>
            </div>

            <div>
              <p className="text-slate-400 font-semibold flex items-center gap-1.5 mb-1">
                <Calendar className="w-3.5 h-3.5" /> Account Created
              </p>
              <p className="font-medium text-slate-700">{user?.created_at ? new Date(user.created_at).toLocaleDateString() : 'Active'}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
