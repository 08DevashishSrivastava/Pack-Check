import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, PackageCheck, Building2, Barcode, Scale, Plus } from 'lucide-react';
import { productApi } from '../../services/entityApis';
import StatusBadge from '../../components/common/StatusBadge';

export const ProductDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      try {
        const data = await productApi.getProductById(id);
        setProduct(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  if (loading || !product) {
    return (
      <div className="py-20 text-center space-y-2">
        <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-slate-500">Loading commodity profile...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/products')}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-xl font-extrabold text-slate-900">{product.name}</h1>
            <p className="text-xs text-slate-500">{product.brand} • Commodity Record</p>
          </div>
        </div>
        <button
          onClick={() => navigate('/inspections/new')}
          className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow"
        >
          <Plus className="w-4 h-4" />
          <span>New Inspection for Product</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600">Product Metadata</h2>
          <div className="space-y-3 text-xs">
            <div>
              <p className="text-slate-400 font-semibold">Commodity Name</p>
              <p className="font-bold text-slate-800 text-sm mt-0.5">{product.name}</p>
            </div>
            <div>
              <p className="text-slate-400 font-semibold">Brand / Trademark</p>
              <p className="font-medium text-slate-800 mt-0.5">{product.brand}</p>
            </div>
            <div>
              <p className="text-slate-400 font-semibold">Commodity Category</p>
              <p className="font-medium text-slate-800 mt-0.5">{product.category}</p>
            </div>
            <div>
              <p className="text-slate-400 font-semibold">Standard Barcode</p>
              <p className="font-mono font-bold text-slate-800 mt-0.5">{product.barcode}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600">Manufacturer &amp; Compliance</h2>
          <div className="space-y-3 text-xs">
            <div>
              <p className="text-slate-400 font-semibold">Manufacturer / Packer Address</p>
              <p className="font-medium text-slate-800 mt-0.5 leading-relaxed">{product.manufacturer}</p>
            </div>
            <div>
              <p className="text-slate-400 font-semibold">Total Audits Conducted</p>
              <p className="font-bold text-slate-800 text-sm mt-0.5">{product.inspectionCount || 1} Inspections</p>
            </div>
            <div>
              <p className="text-slate-400 font-semibold">Latest Compliance Status</p>
              <div className="mt-1">
                <StatusBadge status={product.latestStatus || 'COMPLIANT'} size="md" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
