import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FileCheck2,
  Search,
  Filter,
  Plus,
  ArrowUpDown,
  ChevronRight,
  RefreshCw
} from 'lucide-react';
import inspectionApi from '../../services/inspectionApi';
import DataTable from '../../components/common/DataTable';
import StatusBadge from '../../components/common/StatusBadge';
import ScoreBadge from '../../components/common/ScoreBadge';
import { formatDate } from '../../utils/cn';

export const InspectionHistoryPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [inspections, setInspections] = useState([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const fetchInspections = async () => {
    setLoading(true);
    try {
      const res = await inspectionApi.getInspections({
        search: search.trim() || undefined,
        status: statusFilter !== 'ALL' ? statusFilter : undefined
      });
      // API returns { success: true, count, data: [...] }
      setInspections(res?.data || res || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInspections();
  }, [statusFilter]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchInspections();
  };

  const columns = [
    {
      header: 'Inspection ID',
      accessorKey: 'id',
      cell: (row) => <span className="font-mono font-bold text-xs text-blue-700">{row.id}</span>
    },
    {
      header: 'Packaged Commodity',
      accessorKey: 'product_name',
      cell: (row) => (
        <div>
          <p className="font-bold text-xs text-slate-900">{row.product_name || row.product}</p>
          <p className="text-[11px] text-slate-500">{row.brand || 'Packaged Commodity'}</p>
        </div>
      )
    },
    {
      header: 'Inspection Date',
      accessorKey: 'date',
      cell: (row) => <span className="text-xs text-slate-600">{formatDate(row.date)}</span>
    },
    {
      header: 'Score',
      accessorKey: 'score',
      cell: (row) => <ScoreBadge score={row.score} size="sm" />
    },
    {
      header: 'Compliance Status',
      accessorKey: 'status',
      cell: (row) => <StatusBadge status={row.status} size="sm" />
    },
    {
      header: 'Inspector',
      accessorKey: 'inspector_name',
      cell: (row) => <span className="text-xs text-slate-600">{row.inspector_name || 'Inspector Rajesh Sharma'}</span>
    },
    {
      header: 'Action',
      cell: (row) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/inspections/${row.id}/result`);
          }}
          className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900"
        >
          <span>View Audit</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <FileCheck2 className="w-4 h-4" />
            </span>
            <h1 className="text-xl font-extrabold text-slate-900">Inspection History</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Complete registry of all Legal Metrology package compliance inspections.
          </p>
        </div>

        <button
          onClick={() => navigate('/inspections/new')}
          className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>New Inspection</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-subtle flex flex-col md:flex-row items-center justify-between gap-3">
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 w-full md:w-80">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by ID, product, or brand..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-hidden focus:ring-1 focus:ring-blue-600 focus:bg-white"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
          >
            Search
          </button>
        </form>

        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
          {['ALL', 'COMPLIANT', 'NON_COMPLIANT', 'NEEDS_REVIEW'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition shrink-0 ${
                statusFilter === status
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {status.replace('_', ' ')}
            </button>
          ))}
          <button
            onClick={fetchInspections}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="py-16 text-center space-y-2 bg-white rounded-2xl border border-slate-200">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500 font-medium">Filtering inspection records...</p>
        </div>
      ) : (
        <DataTable
          columns={columns}
          data={inspections}
          onRowClick={(row) => navigate(`/inspections/${row.id}/result`)}
          emptyMessage="No inspection records found matching your filters."
        />
      )}
    </div>
  );
};

export default InspectionHistoryPage;
