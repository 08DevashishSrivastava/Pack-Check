import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Plus,
  FileCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Scale,
  Calendar,
  Layers,
  ChevronRight
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import { useAuth } from '../../context/AuthContext';
import dashboardApi from '../../services/dashboardApi';
import StatCard from '../../components/common/StatCard';
import StatusBadge from '../../components/common/StatusBadge';
import ScoreBadge from '../../components/common/ScoreBadge';
import DataTable from '../../components/common/DataTable';
import { formatDate } from '../../utils/cn';

export const DashboardPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);

  useEffect(() => {
    const fetchDashboard = async () => {
      setLoading(true);
      try {
        const res = await dashboardApi.getStats();
        setData(res);
      } catch (err) {
        console.error('Error loading dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  const summary = data?.summary || {
    totalInspections: 135,
    compliantCount: 94,
    nonCompliantCount: 28,
    needsReviewCount: 13,
    complianceRate: 70
  };

  const trendData = data?.complianceTrend || [];
  const violationData = data?.violationCategories || [];
  const statusData = data?.statusDistribution || [
    { name: 'Compliant', value: 94, color: '#059669' },
    { name: 'Non-Compliant', value: 28, color: '#DC2626' },
    { name: 'Needs Review', value: 13, color: '#D97706' }
  ];

  const recentInspections = data?.recentInspections || [];

  const columns = [
    {
      header: 'Inspection ID',
      accessorKey: 'id',
      cell: (row) => <span className="font-mono font-bold text-xs text-blue-700">{row.id}</span>
    },
    {
      header: 'Product / Commodity',
      accessorKey: 'product',
      cell: (row) => (
        <div>
          <p className="font-bold text-xs text-slate-900">{row.product || row.product_name}</p>
          <p className="text-[11px] text-slate-500">{row.brand || 'Packaged Goods'}</p>
        </div>
      )
    },
    {
      header: 'Date',
      accessorKey: 'date',
      cell: (row) => <span className="text-xs text-slate-600">{formatDate(row.date)}</span>
    },
    {
      header: 'Score',
      accessorKey: 'score',
      cell: (row) => <ScoreBadge score={row.score} size="sm" />
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (row) => <StatusBadge status={row.status} size="sm" />
    },
    {
      header: 'Inspector',
      accessorKey: 'inspector',
      cell: (row) => <span className="text-xs text-slate-600">{row.inspector || row.inspector_name}</span>
    },
    {
      header: 'Action',
      cell: (row) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/inspections/${row.id}/result`);
          }}
          className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900"
        >
          <span>View Audit</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      )
    }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Good Day, {user?.name?.split(' ')[0] || 'Inspector'}
            </h1>
            <span className="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
              {user?.role || 'INSPECTOR'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {user?.department || 'Legal Metrology Enforcement Division'} • Real-Time Enforcement Hub
          </p>
        </div>

        <Link
          to="/inspections/new"
          className="inline-flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md hover:shadow transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ New Inspection</span>
        </Link>
      </div>

      {/* Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Inspections"
          value={summary.totalInspections}
          subtitle="Packaged commodities audited"
          icon={FileCheck}
          color="blue"
          trend={14}
        />
        <StatCard
          title="Compliant Units"
          value={summary.compliantCount}
          subtitle={`${summary.complianceRate}% adherence rate`}
          icon={CheckCircle2}
          color="emerald"
          trend={8}
        />
        <StatCard
          title="Non-Compliant Flagged"
          value={summary.nonCompliantCount}
          subtitle="Violations requiring notice"
          icon={XCircle}
          color="rose"
          trend={-4}
        />
        <StatCard
          title="Needs Review"
          value={summary.needsReviewCount}
          subtitle="Low confidence / print issues"
          icon={AlertTriangle}
          color="amber"
          trend={2}
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Compliance Trend Chart */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Compliance Inspection Trend</h2>
              <p className="text-xs text-slate-500">Monthly inspection volume vs compliance outcomes</p>
            </div>
            <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
              Last 6 Months
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="compliantGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="nonCompliantGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#DC2626" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#DC2626" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
                <Area type="monotone" dataKey="compliant" name="Compliant" stroke="#059669" strokeWidth={2} fillOpacity={1} fill="url(#compliantGrad)" />
                <Area type="monotone" dataKey="nonCompliant" name="Non-Compliant" stroke="#DC2626" strokeWidth={2} fillOpacity={1} fill="url(#nonCompliantGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Donut Distribution */}
        <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Status Breakdown</h2>
            <p className="text-xs text-slate-500">Distribution across active inspections</p>
          </div>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color || '#3b82f6'} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-slate-100">
            {statusData.map((item, idx) => (
              <div key={idx} className="p-1.5 rounded-lg bg-slate-50">
                <p className="text-xs font-bold" style={{ color: item.color }}>{item.value}</p>
                <p className="text-[10px] text-slate-500 truncate">{item.name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Violation Categories Bar Chart */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Statutory Violation Categories</h2>
            <p className="text-xs text-slate-500">Most frequent non-compliance issues detected under Legal Metrology 2011</p>
          </div>
        </div>

        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={violationData} layout="vertical" margin={{ top: 5, right: 20, left: 40, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis type="number" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis dataKey="category" type="category" width={160} tick={{ fontSize: 11, fill: '#334155' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="count" name="Violations Count" fill="#3B82F6" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Inspections Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Recent Product Inspections</h2>
            <p className="text-xs text-slate-500">Latest packaged commodities inspected in your zone</p>
          </div>
          <Link
            to="/inspections"
            className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900"
          >
            <span>View All Inspections</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <DataTable
          columns={columns}
          data={recentInspections}
          onRowClick={(row) => navigate(`/inspections/${row.id}/result`)}
        />
      </div>
    </div>
  );
};

export default DashboardPage;
