import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileSpreadsheet, Download, FileText, ChevronRight, Scale } from 'lucide-react';
import { reportApi } from '../../services/entityApis';
import DataTable from '../../components/common/DataTable';
import StatusBadge from '../../components/common/StatusBadge';
import { formatDate } from '../../utils/cn';

export const ReportsPage = () => {
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReports = async () => {
      setLoading(true);
      try {
        const data = await reportApi.getReports();
        setReports(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchReports();
  }, []);

  const columns = [
    {
      header: 'Report ID',
      accessorKey: 'id',
      cell: (row) => <span className="font-mono font-bold text-xs text-blue-700">{row.id}</span>
    },
    {
      header: 'Report Title & Product',
      accessorKey: 'title',
      cell: (row) => (
        <div>
          <p className="font-bold text-xs text-slate-900">{row.title}</p>
          <p className="text-[11px] text-slate-500">{row.product}</p>
        </div>
      )
    },
    {
      header: 'Generated Date',
      accessorKey: 'date',
      cell: (row) => <span className="text-xs text-slate-600">{formatDate(row.date)}</span>
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (row) => <StatusBadge status={row.status} size="sm" />
    },
    {
      header: 'Officer',
      accessorKey: 'generated_by',
      cell: (row) => <span className="text-xs text-slate-600">{row.generated_by}</span>
    },
    {
      header: 'Actions',
      cell: (row) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/reports/${row.id}`);
          }}
          className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900"
        >
          <span>View Report</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-4 h-4" />
            </span>
            <h1 className="text-xl font-extrabold text-slate-900">Inspection Reports &amp; Notices</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Generated statutory compliance certificates and non-compliance advisory notices.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="py-16 text-center space-y-2 bg-white rounded-2xl border border-slate-200">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500">Loading inspection reports...</p>
        </div>
      ) : (
        <DataTable
          columns={columns}
          data={reports}
          onRowClick={(row) => navigate(`/reports/${row.id}`)}
          emptyMessage="No reports generated yet."
        />
      )}
    </div>
  );
};

export default ReportsPage;
