import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertOctagon, Filter, ChevronRight, ShieldAlert } from 'lucide-react';
import { violationApi } from '../../services/entityApis';
import DataTable from '../../components/common/DataTable';
import StatusBadge from '../../components/common/StatusBadge';
import { formatDate } from '../../utils/cn';

export const ViolationsPage = () => {
  const navigate = useNavigate();
  const [violations, setViolations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [severityFilter, setSeverityFilter] = useState('ALL');

  useEffect(() => {
    const fetchViolations = async () => {
      setLoading(true);
      try {
        const data = await violationApi.getViolations();
        setViolations(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchViolations();
  }, []);

  const filtered = severityFilter === 'ALL'
    ? violations
    : violations.filter(v => v.severity === severityFilter);

  const columns = [
    {
      header: 'Rule Code',
      accessorKey: 'rule_code',
      cell: (row) => <span className="font-mono font-bold text-xs bg-rose-100 text-rose-800 px-2 py-0.5 rounded">{row.rule_code}</span>
    },
    {
      header: 'Severity',
      accessorKey: 'severity',
      cell: (row) => <StatusBadge status={row.severity} size="sm" />
    },
    {
      header: 'Violation Title & Commodity',
      accessorKey: 'title',
      cell: (row) => (
        <div>
          <p className="font-bold text-xs text-slate-900">{row.title}</p>
          <p className="text-[11px] text-slate-500">{row.product}</p>
        </div>
      )
    },
    {
      header: 'Detected Value',
      accessorKey: 'detected_value',
      cell: (row) => <span className="text-xs text-slate-600 line-clamp-1">{row.detected_value}</span>
    },
    {
      header: 'Date',
      accessorKey: 'date',
      cell: (row) => <span className="text-xs text-slate-500">{formatDate(row.date)}</span>
    },
    {
      header: 'Action',
      cell: (row) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/inspections/${row.inspection_id}/result`);
          }}
          className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900"
        >
          <span>Audit Evidence</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
              <AlertOctagon className="w-4 h-4" />
            </span>
            <h1 className="text-xl font-extrabold text-slate-900">Violations Registry</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Tracking all statutory Legal Metrology 2011 packaging non-conformities.
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-subtle flex items-center gap-2 overflow-x-auto">
        <span className="text-xs font-bold text-slate-500 uppercase px-2">Severity:</span>
        {['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((sev) => (
          <button
            key={sev}
            onClick={() => setSeverityFilter(sev)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
              severityFilter === sev
                ? 'bg-rose-700 text-white shadow-xs'
                : 'bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            {sev}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="py-16 text-center space-y-2 bg-white rounded-2xl border border-slate-200">
          <div className="w-8 h-8 border-2 border-rose-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500">Loading violations registry...</p>
        </div>
      ) : (
        <DataTable
          columns={columns}
          data={filtered}
          onRowClick={(row) => navigate(`/inspections/${row.inspection_id}/result`)}
          emptyMessage="No statutory violations found matching severity filter."
        />
      )}
    </div>
  );
};

export default ViolationsPage;
