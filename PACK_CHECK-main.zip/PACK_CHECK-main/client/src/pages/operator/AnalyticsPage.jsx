import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Award, ShieldAlert, FileText } from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import StatCard from '../../components/common/StatCard';
import dashboardApi from '../../services/dashboardApi';

export const AnalyticsPage = () => {
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({ complianceRate: 0, totalInspections: 0, nonCompliantCount: 0, needsReviewCount: 0 });
  const [complianceTrend, setComplianceTrend] = useState([]);
  const [violationCategories, setViolationCategories] = useState([]);
  const [statusDistribution, setStatusDistribution] = useState([]);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const data = await dashboardApi.getStats();
        const d = data?.data || data;
        setSummary(d?.summary || {});
        setComplianceTrend(d?.complianceTrend || []);
        setViolationCategories(d?.violationCategories || []);
        setStatusDistribution(d?.statusDistribution || []);
      } catch (err) {
        console.error('Analytics load error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, []);

  if (loading) {
    return (
      <div className="py-20 text-center space-y-3">
        <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-slate-500 font-medium">Loading compliance analytics from database...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle">
        <div className="flex items-center gap-2">
          <span className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
            <BarChart3 className="w-4 h-4" />
          </span>
          <h1 className="text-xl font-extrabold text-slate-900">Compliance Analytics &amp; Enforcement Trends</h1>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Live audit metrics, violation heatmaps, and category adherence rates from the MySQL database.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Overall Compliance"
          value={`${summary.complianceRate || 0}%`}
          subtitle="Cumulative pass rate"
          icon={Award}
          color="emerald"
        />
        <StatCard
          title="Total Inspected Units"
          value={summary.totalInspections || 0}
          subtitle="Saved in database"
          icon={FileText}
          color="blue"
        />
        <StatCard
          title="Non-Compliant"
          value={summary.nonCompliantCount || 0}
          subtitle="Actionable legal notices"
          icon={ShieldAlert}
          color="rose"
        />
        <StatCard
          title="Needs Review"
          value={summary.needsReviewCount || 0}
          subtitle="Pending manual verification"
          icon={TrendingUp}
          color="amber"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Trend */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Cumulative Monthly Compliance Trajectory</h2>
          {complianceTrend.length > 0 ? (
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={complianceTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="compGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#059669" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#059669" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="noncompGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#dc2626" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#dc2626" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                  <Legend />
                  <Area type="monotone" dataKey="compliant" name="Compliant" stroke="#059669" strokeWidth={2} fill="url(#compGrad)" />
                  <Area type="monotone" dataKey="nonCompliant" name="Non-Compliant" stroke="#dc2626" strokeWidth={2} fill="url(#noncompGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-72 flex items-center justify-center text-xs text-slate-400">
              Not enough data yet — complete more inspections to see trends.
            </div>
          )}
        </div>

        {/* Status Distribution Pie */}
        <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Enforcement Outcome Ratios</h2>
          {statusDistribution.some(s => s.value > 0) ? (
            <>
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {statusDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || '#3b82f6'} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 pt-2 border-t border-slate-100">
                {statusDistribution.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 font-medium text-slate-700">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                      {item.name}
                    </span>
                    <span className="font-bold text-slate-900">{item.value} units</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="h-56 flex items-center justify-center text-xs text-slate-400">
              No inspection data yet. Run inspections from the Demo or Inspector portal.
            </div>
          )}
        </div>
      </div>

      {/* Violation Category Breakdown */}
      {violationCategories.length > 0 && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Statutory Violation Category Frequency</h2>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={violationCategories} margin={{ top: 5, right: 10, left: -20, bottom: 50 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748b' }} angle={-35} textAnchor="end" />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                <Bar dataKey="count" name="Violations" fill="#dc2626" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalyticsPage;
