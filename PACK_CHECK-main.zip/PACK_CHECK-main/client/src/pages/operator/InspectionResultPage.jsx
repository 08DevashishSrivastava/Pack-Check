import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  FileText,
  Download,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Share2,
  Eye,
  ShieldCheck,
  Scale,
  Calendar,
  User,
  Package,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';
import inspectionApi from '../../services/inspectionApi';
import EvidenceViewer from '../../components/common/EvidenceViewer';
import StatusBadge from '../../components/common/StatusBadge';
import ScoreBadge from '../../components/common/ScoreBadge';
import { formatDate } from '../../utils/cn';
import { getImageUrl } from '../../utils/imageUrl';
import { exportInspectionPdf } from '../../utils/pdfExport';

export const InspectionResultPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [inspection, setInspection] = useState(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [activeBoxId, setActiveBoxId] = useState(null);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [pdfGenerating, setPdfGenerating] = useState(false);

  const handleExportPdf = async () => {
    if (!inspection) return;
    setPdfGenerating(true);
    try {
      await exportInspectionPdf(inspection.id, inspection.product_name);
      setReportModalOpen(false);
    } catch (err) {
      console.error('PDF export failed:', err);
      alert('Failed to generate PDF audit notice: ' + (err.message || 'Server error'));
    } finally {
      setPdfGenerating(false);
    }
  };

  useEffect(() => {
    const fetchInspection = async () => {
      setLoading(true);
      try {
        const res = await inspectionApi.getInspectionById(id);
        // API returns { success: true, data: { ...inspection } }
        setInspection(res?.data || res);
      } catch (err) {
        console.error('Error fetching inspection:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchInspection();
  }, [id]);

  if (loading || !inspection) {
    return (
      <div className="py-20 text-center space-y-3">
        <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-slate-500 font-medium">Loading inspection audit details...</p>
      </div>
    );
  }

  const images = (inspection.images && inspection.images.length > 0) 
    ? inspection.images 
    : [{ id: 'img-1', type: 'FRONT', url: inspection.image_url || '' }];

  const currentImage = images[selectedImageIndex] || images[0] || { url: '', type: 'FRONT' };

  const declarations = inspection.declarations || [];
  const violations = inspection.violations || [];
  const ocrItems = inspection.ocr_items || [];

  const handleSelectBox = (item) => {
    setActiveBoxId(item.field || item.id || item.title);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Navigation & Action Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/inspections')}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition"
            title="Back to Inspection History"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
                {inspection.product_name || 'Packaged Commodity Audit'}
              </h1>
              <span className="font-mono font-bold text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                {inspection.id}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Audited by <strong>{inspection.inspector_name || 'Duty Inspector'}</strong> • {formatDate(inspection.date)}
            </p>
          </div>
        </div>

        {/* Status Badges and Report Actions */}
        <div className="flex items-center gap-3 flex-wrap">
          <StatusBadge status={inspection.status} size="lg" />
          <ScoreBadge score={inspection.score} size="lg" />
          <button
            onClick={() => setReportModalOpen(true)}
            className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition"
          >
            <FileText className="w-4 h-4" />
            <span>Generate Notice / Report</span>
          </button>
        </div>
      </div>

      {inspection.analysis_code && inspection.analysis_code !== 'OK' && (
        <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-medium">
          Analysis status: {inspection.analysis_code}
        </div>
      )}

      {/* Main Dual-Pane Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Multi-Face Image Tabs & Interactive Evidence Viewer */}
        <div className="lg:col-span-6 space-y-4">
          {/* Packaging Faces Selector Tabs */}
          {images.length > 1 && (
            <div className="flex items-center gap-2 bg-white p-1.5 rounded-xl border border-slate-200 shadow-2xs overflow-x-auto">
              {images.map((img, idx) => (
                <button
                  key={img.id || idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                    selectedImageIndex === idx
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Surface: {img.type || `Face ${idx + 1}`}
                </button>
              ))}
            </div>
          )}

          {/* Evidence Viewer */}
          <div className="sticky top-20">
            <EvidenceViewer
              imageUrl={getImageUrl(currentImage.url)}
              boundingBoxes={[...ocrItems.map(item => ({ ...item, field: item.text })), ...declarations, ...violations]}
              activeBoxId={activeBoxId}
              onSelectBox={handleSelectBox}
              title={`${inspection.product_name || 'Packaged Commodity'} — ${currentImage.type || 'FRONT'} Surface`}
              imageWidth={currentImage.image_width || 900}
              imageHeight={currentImage.image_height || 900}
            />

            {/* Quick Metadata Box */}
            <div className="mt-3 bg-white p-3.5 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-800">Brand:</span> {inspection.brand || 'N/A'}
              </div>
              <div>
                <span className="font-bold text-slate-800">Category:</span> {inspection.category || 'General'}
              </div>
              <div>
                <span className="font-bold text-slate-800">Barcode:</span> <span className="font-mono">{inspection.barcode || 'N/A'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Compliance Summary, Violations, Declarations Checklist */}
        <div className="lg:col-span-6 space-y-6">
          {/* Audit Metrics Summary Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-blue-700" />
                <span>Statutory Compliance Metrics (Rules 2011)</span>
              </h2>
              <span className="text-[11px] font-bold text-slate-500">
                {declarations.length} Declarations Verified
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-lg font-extrabold text-slate-800">{inspection.total_declarations || declarations.length}</p>
                <p className="text-[10px] text-slate-500 font-semibold uppercase">Total</p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <p className="text-lg font-extrabold text-emerald-700">{inspection.passed_rules ?? 0}</p>
                <p className="text-[10px] text-emerald-600 font-semibold uppercase">Passed</p>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200">
                <p className="text-lg font-extrabold text-rose-700">{inspection.failed_rules ?? violations.length}</p>
                <p className="text-[10px] text-rose-600 font-semibold uppercase">Failed</p>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                <p className="text-lg font-extrabold text-amber-700">{inspection.warning_rules || 0}</p>
                <p className="text-[10px] text-amber-600 font-semibold uppercase">Warnings</p>
              </div>
            </div>
          </div>

          {/* Section: Statutory Violations Flagged */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-rose-800 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>Statutory Violations &amp; Infractions ({violations.length})</span>
              </h2>
              {violations.length === 0 && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  Zero Violations Detected
                </span>
              )}
            </div>

            {violations.length === 0 ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>All mandatory packaging declarations conform to Legal Metrology (Packaged Commodities) Rules, 2011.</span>
              </div>
            ) : (
              <div className="space-y-3">
                {violations.map((viol, vIdx) => (
                  <div
                    key={viol.id || vIdx}
                    onClick={() => handleSelectBox(viol)}
                    className="p-4 rounded-xl border border-rose-200 bg-rose-50/40 hover:bg-rose-50 transition space-y-2.5 cursor-pointer shadow-2xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-mono font-bold bg-rose-200 text-rose-900 px-1.5 py-0.5 rounded">
                          {viol.rule_code}
                        </span>
                        <h3 className="font-bold text-xs text-rose-950 mt-1">{viol.title}</h3>
                      </div>
                      <StatusBadge status={viol.severity} size="sm" />
                    </div>

                    <div className="text-xs space-y-1 bg-white/80 p-2.5 rounded-lg border border-rose-100">
                      <p className="text-slate-800">
                        <strong className="text-slate-600">Detected Value:</strong> {viol.detected_value}
                      </p>
                      <p className="text-slate-700">
                        <strong className="text-slate-600">Statutory Requirement:</strong> {viol.expected_condition}
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-1">
                      <span className="text-blue-900 font-semibold">
                        💡 <strong>Recommendation:</strong> {viol.recommendation}
                      </span>
                      {viol.bbox && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelectBox(viol);
                          }}
                          className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Box</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section: Rule 6 Mandatory Declarations Checklist */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-700" />
                <span>Mandatory Declarations Audit (Rule 6)</span>
              </h2>
              <span className="text-[11px] text-slate-500">Click field to locate bounding box</span>
            </div>

            <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
              {declarations.map((decl, dIdx) => {
                const isActive = activeBoxId === decl.field;

                return (
                  <div
                    key={dIdx}
                    onClick={() => handleSelectBox(decl)}
                    className={`py-3 px-3 rounded-lg flex items-center justify-between gap-4 cursor-pointer transition ${
                      isActive ? 'bg-blue-50/90 font-semibold' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="space-y-0.5 flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-900">{decl.field}</p>
                      <p className="text-[11.5px] text-slate-600 font-mono truncate">{decl.value ?? 'NOT DETECTED'}</p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-[10px] text-slate-400 font-mono">
                        {decl.confidence == null ? '—' : `${Math.round(decl.confidence * 100)}% conf`}
                      </span>
                      <StatusBadge status={decl.status} size="sm" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* PDF Report Generation Modal */}
      {reportModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white max-w-lg w-full rounded-2xl p-6 space-y-5 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-700" />
                <h3 className="font-bold text-base text-slate-900">Legal Metrology Inspection Notice</h3>
              </div>
              <button
                onClick={() => setReportModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600">
              <p>
                This action prepares an official Legal Metrology Compliance Inspection Audit Notice for{' '}
                <strong className="text-slate-900">{inspection.product_name}</strong> (Inspection ID: <span className="font-mono font-bold text-blue-700">{inspection.id}</span>).
              </p>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                <p><strong>Inspector:</strong> {inspection.inspector_name || 'Inspector Rajesh Sharma'}</p>
                <p><strong>Overall Score:</strong> {inspection.score}% ({inspection.status})</p>
                <p><strong>Flagged Violations:</strong> {violations.length} statutory infractions</p>
              </div>
              <p className="text-[11px] text-slate-500">
                Official statutory report formatted under Legal Metrology (Packaged Commodities) Rules, 2011.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setReportModalOpen(false)}
                disabled={pdfGenerating}
                className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-xl transition disabled:opacity-50"
              >
                Close
              </button>
              <button
                onClick={handleExportPdf}
                disabled={pdfGenerating}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl shadow transition disabled:opacity-50"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{pdfGenerating ? 'Generating PDF Notice...' : 'Export & Share PDF Notice'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InspectionResultPage;
