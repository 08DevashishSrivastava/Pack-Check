import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, Printer, Scale, AlertTriangle, ShieldCheck, FileText } from 'lucide-react';
import inspectionApi from '../../services/inspectionApi';
import StatusBadge from '../../components/common/StatusBadge';
import ScoreBadge from '../../components/common/ScoreBadge';
import { formatDate } from '../../utils/cn';
import { getImageUrl } from '../../utils/imageUrl';
import { exportInspectionPdf } from '../../utils/pdfExport';

export const ReportDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [inspection, setInspection] = useState(null);
  const [pdfGenerating, setPdfGenerating] = useState(false);

  const handleDownloadPdf = async () => {
    if (!inspection) return;
    setPdfGenerating(true);
    try {
      await exportInspectionPdf(inspection.id, inspection.product_name);
    } catch (err) {
      console.error('PDF export failed:', err);
      alert('Failed to generate PDF notice: ' + (err.message || 'Server error'));
    } finally {
      setPdfGenerating(false);
    }
  };

  useEffect(() => {
    const fetchInspection = async () => {
      setLoading(true);
      try {
        const res = await inspectionApi.getInspectionById(id);
        setInspection(res?.data || res);
      } catch (err) {
        console.error('Error loading inspection report:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchInspection();
  }, [id]);

  if (loading || !inspection) {
    return (
      <div className="py-20 text-center space-y-3">
        <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-slate-500 font-medium">Generating official audit notice...</p>
      </div>
    );
  }

  const primaryImage = inspection.images?.[0];
  const declarations = inspection.declarations || [];
  const violations = inspection.violations || [];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Action Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-xl font-extrabold text-slate-900">Legal Metrology Compliance Audit Notice</h1>
            <p className="text-xs text-slate-500">Inspection ID: <span className="font-mono text-blue-700 font-bold">{inspection.id}</span></p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="p-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 transition cursor-pointer"
            title="Print Report"
          >
            <Printer className="w-4 h-4" />
          </button>
          <button
            onClick={handleDownloadPdf}
            disabled={pdfGenerating}
            className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow transition cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{pdfGenerating ? 'Generating...' : 'Download / Share PDF'}</span>
          </button>
        </div>
      </div>

      {/* Report Document Shell */}
      <div className="bg-white p-8 sm:p-12 rounded-2xl border border-slate-200 shadow-card space-y-8 text-slate-800">
        {/* Document Header */}
        <div className="border-b-2 border-slate-900 pb-6 flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-lg">
              <Scale className="w-6 h-6 text-blue-700" />
              <span>LEGAL METROLOGY INSPECTION ENFORCEMENT AUDIT</span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Packaged Commodity Compliance Assessment under Legal Metrology (Packaged Commodities) Rules, 2011 &amp; Amendments ({inspection.rule_registry_version || 'LM-PC-2026.08'})
            </p>
          </div>
          <div className="text-right text-xs">
            <p className="font-bold text-slate-900">Record #{inspection.id}</p>
            <p className="text-slate-500">Date: {formatDate(inspection.date)}</p>
          </div>
        </div>

        {/* Commodity Particulars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div>
            <p className="text-slate-500">Commodity Inspected:</p>
            <p className="font-bold text-slate-900 text-sm mt-0.5">{inspection.product_name || 'Packaged Commodity'}</p>
            {inspection.brand && <p className="text-xs text-blue-700 font-semibold">{inspection.brand}</p>}
          </div>
          <div>
            <p className="text-slate-500">Auditing Inspector:</p>
            <p className="font-bold text-slate-900 mt-0.5">{inspection.inspector_name || 'Duty Inspector'}</p>
          </div>
          <div>
            <p className="text-slate-500">Category / Surface:</p>
            <p className="font-semibold text-slate-800">{inspection.category || 'Food & Beverages'}</p>
          </div>
          <div>
            <p className="text-slate-500">Screening Status &amp; Score:</p>
            <div className="mt-1 flex items-center gap-2">
              <StatusBadge status={inspection.status} size="sm" />
              <ScoreBadge score={inspection.score} size="sm" />
            </div>
          </div>
        </div>

        {/* Package Visual Evidence Preview */}
        {primaryImage && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-2">
              Packaging Evidence Image
            </h3>
            <div className="p-2 bg-slate-900 rounded-xl overflow-hidden flex items-center justify-center max-h-[300px]">
              <img
                src={getImageUrl(primaryImage.url)}
                alt="Packaged Commodity Evidence"
                className="max-h-[280px] w-auto object-contain rounded"
              />
            </div>
          </div>
        )}

        {/* Flagged Non-Compliance Issues */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-2">
            Statutory Infractions &amp; Non-Conformities ({violations.length})
          </h3>
          {violations.length === 0 ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-semibold flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>No non-compliance infractions detected. All applicable mandatory package declarations are satisfied.</span>
            </div>
          ) : (
            <div className="space-y-2">
              {violations.map((viol, idx) => (
                <div key={viol.id || idx} className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-rose-950">{idx + 1}. {viol.title}</p>
                    <StatusBadge status={viol.severity} size="sm" />
                  </div>
                  <p className="text-rose-900"><strong>Observed:</strong> {viol.detected_value || 'Not detected on package label'}</p>
                  <p className="text-slate-600"><strong>Statutory Requirement:</strong> {viol.expected_condition}</p>
                  {viol.legal_reference && (
                    <p className="text-[10.5px] text-slate-500 font-mono"><strong>Legal Reference:</strong> {viol.legal_reference}</p>
                  )}
                  <p className="text-[11px] text-blue-900 bg-white/70 p-2 rounded border border-rose-200 font-medium">
                    💡 <strong>Action Required:</strong> {viol.recommendation}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Extracted Declarations Record */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-2">
            Extracted Mandatory Declarations (Rule 6)
          </h3>
          <div className="rounded-xl border border-slate-200 overflow-hidden text-xs">
            <table className="w-full text-left divide-y divide-slate-200">
              <thead className="bg-slate-50 font-bold text-slate-700">
                <tr>
                  <th className="p-2.5">Declaration Field</th>
                  <th className="p-2.5">Observed Value</th>
                  <th className="p-2.5">Confidence</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {declarations.map((d, idx) => (
                  <tr key={d.id || idx}>
                    <td className="p-2.5 font-semibold text-slate-900">{d.field}</td>
                    <td className="p-2.5 font-mono text-[11px]">{d.value || 'Not detected'}</td>
                    <td className="p-2.5 font-mono text-[11px] text-slate-500">{d.confidence ? `${Math.round(d.confidence * 100)}%` : '—'}</td>
                    <td className="p-2.5"><StatusBadge status={d.status} size="sm" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Statutory Disclaimer */}
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 font-medium flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
          <span>{inspection.disclaimer}</span>
        </div>

        {/* Signatures */}
        <div className="pt-8 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div>
            <p className="font-bold text-slate-900">Legal Metrology Inspectorate</p>
            <p>Government Enforcement Portal</p>
          </div>
          <div className="text-right">
            <p className="font-bold text-slate-900">Officer Signature / Seal</p>
            <p className="font-mono text-[10px]">VERIFIED ELECTRONICALLY</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportDetailPage;
