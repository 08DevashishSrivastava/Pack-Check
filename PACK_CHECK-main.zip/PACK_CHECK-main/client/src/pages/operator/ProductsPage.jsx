import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PackageCheck, Search, Plus, Building2, Barcode, ChevronRight } from 'lucide-react';
import { productApi } from '../../services/entityApis';
import DataTable from '../../components/common/DataTable';
import StatusBadge from '../../components/common/StatusBadge';

export const ProductsPage = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const data = await productApi.getProducts();
        setProducts(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.brand.toLowerCase().includes(search.toLowerCase()) ||
    p.barcode.includes(search)
  );

  const columns = [
    {
      header: 'Commodity / Product',
      accessorKey: 'name',
      cell: (row) => (
        <div>
          <p className="font-bold text-xs text-slate-900">{row.name}</p>
          <p className="text-[11px] text-slate-500 font-medium">{row.brand}</p>
        </div>
      )
    },
    {
      header: 'Category',
      accessorKey: 'category',
      cell: (row) => <span className="text-xs text-slate-600">{row.category}</span>
    },
    {
      header: 'Barcode (EAN-13)',
      accessorKey: 'barcode',
      cell: (row) => <span className="font-mono text-xs text-slate-700 bg-slate-100 px-2 py-0.5 rounded">{row.barcode}</span>
    },
    {
      header: 'Manufacturer / Packer',
      accessorKey: 'manufacturer',
      cell: (row) => <span className="text-xs text-slate-600 line-clamp-1 max-w-xs">{row.manufacturer}</span>
    },
    {
      header: 'Inspections',
      accessorKey: 'inspectionCount',
      cell: (row) => <span className="text-xs font-bold text-slate-800">{row.inspectionCount || 1} Audits</span>
    },
    {
      header: 'Latest Status',
      accessorKey: 'latestStatus',
      cell: (row) => <StatusBadge status={row.latestStatus} size="sm" />
    },
    {
      header: 'Action',
      cell: (row) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/products/${row.id}`);
          }}
          className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900"
        >
          <span>Catalog Record</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <PackageCheck className="w-4 h-4" />
            </span>
            <h1 className="text-xl font-extrabold text-slate-900">Product Repository</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Registered packaged commodities, manufacturers, and cumulative compliance status.
          </p>
        </div>

        <button
          onClick={() => navigate('/inspections/new')}
          className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Audit New Product</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-subtle">
        <div className="relative max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search commodities by name, brand, or barcode..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-1 focus:ring-blue-600 focus:bg-white"
          />
        </div>
      </div>

      {loading ? (
        <div className="py-16 text-center space-y-2 bg-white rounded-2xl border border-slate-200">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500">Loading catalog...</p>
        </div>
      ) : (
        <DataTable
          columns={columns}
          data={filtered}
          onRowClick={(row) => navigate(`/products/${row.id}`)}
          emptyMessage="No products found in repository."
        />
      )}
    </div>
  );
};

export default ProductsPage;
