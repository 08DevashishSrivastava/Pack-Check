import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ScanLine,
  Camera,
  Upload,
  Trash2,
  Image as ImageIcon,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Package,
  Layers,
  FileImage,
  RefreshCw
} from 'lucide-react';
import inspectionApi from '../../services/inspectionApi';
import { capturePhotoFromCamera, pickPhotoFromGallery } from '../../utils/mediaCapture';

export const NewInspectionPage = () => {
  const navigate = useNavigate();

  const [commodity, setCommodity] = useState({
    product_name: '',
    brand: '',
    category: 'Food & Beverages',
    barcode: ''
  });

  // Dedicated states for FRONT and BACK images
  const [frontImage, setFrontImage] = useState(null); // { file, previewUrl, fileName }
  const [backImage, setBackImage] = useState(null);   // { file, previewUrl, fileName }

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  // Fallback hidden inputs for desktop browser file picking
  const frontInputRef = useRef(null);
  const backInputRef = useRef(null);

  const handleCommodityChange = (e) => {
    setCommodity(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  // ── Front Side Actions ──
  const handleFrontCamera = async () => {
    try {
      setError('');
      const res = await capturePhotoFromCamera();
      if (res) {
        if (frontImage?.previewUrl && frontImage.previewUrl.startsWith('blob:')) {
          URL.revokeObjectURL(frontImage.previewUrl);
        }
        setFrontImage(res);
      }
    } catch (err) {
      setError('Could not access camera. Please check camera permissions.');
    }
  };

  const handleFrontGallery = async () => {
    try {
      setError('');
      const res = await pickPhotoFromGallery();
      if (res) {
        if (frontImage?.previewUrl && frontImage.previewUrl.startsWith('blob:')) {
          URL.revokeObjectURL(frontImage.previewUrl);
        }
        setFrontImage(res);
      } else if (frontInputRef.current) {
        // Fallback for browsers without Capacitor
        frontInputRef.current.click();
      }
    } catch (err) {
      if (frontInputRef.current) frontInputRef.current.click();
    }
  };

  const handleFrontFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (frontImage?.previewUrl && frontImage.previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(frontImage.previewUrl);
    }
    setFrontImage({
      file,
      previewUrl: URL.createObjectURL(file),
      fileName: file.name
    });
    setError('');
  };

  const handleRemoveFront = () => {
    if (frontImage?.previewUrl && frontImage.previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(frontImage.previewUrl);
    }
    setFrontImage(null);
  };

  // ── Back Side Actions ──
  const handleBackCamera = async () => {
    try {
      setError('');
      const res = await capturePhotoFromCamera();
      if (res) {
        if (backImage?.previewUrl && backImage.previewUrl.startsWith('blob:')) {
          URL.revokeObjectURL(backImage.previewUrl);
        }
        setBackImage(res);
      }
    } catch (err) {
      setError('Could not access camera. Please check camera permissions.');
    }
  };

  const handleBackGallery = async () => {
    try {
      setError('');
      const res = await pickPhotoFromGallery();
      if (res) {
        if (backImage?.previewUrl && backImage.previewUrl.startsWith('blob:')) {
          URL.revokeObjectURL(backImage.previewUrl);
        }
        setBackImage(res);
      } else if (backInputRef.current) {
        backInputRef.current.click();
      }
    } catch (err) {
      if (backInputRef.current) backInputRef.current.click();
    }
  };

  const handleBackFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (backImage?.previewUrl && backImage.previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(backImage.previewUrl);
    }
    setBackImage({
      file,
      previewUrl: URL.createObjectURL(file),
      fileName: file.name
    });
    setError('');
  };

  const handleRemoveBack = () => {
    if (backImage?.previewUrl && backImage.previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(backImage.previewUrl);
    }
    setBackImage(null);
  };

  // ── Submit ──
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!frontImage && !backImage) {
      setError('Please capture or select at least the Front side packaging photo.');
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('product_name', commodity.product_name);
      formData.append('brand', commodity.brand);
      formData.append('category', commodity.category);
      formData.append('barcode', commodity.barcode);

      const faceTypes = [];
      if (frontImage?.file) {
        formData.append('images', frontImage.file, frontImage.fileName);
        faceTypes.push('FRONT');
      }
      if (backImage?.file) {
        formData.append('images', backImage.file, backImage.fileName);
        faceTypes.push('BACK');
      }

      formData.append('imageFaceTypes', JSON.stringify(faceTypes));

      const res = await inspectionApi.createInspection(formData);
      const inspectionId = res?.data?.id || res?.id;
      if (!inspectionId) throw new Error('The server did not return an inspection ID.');

      // Clean up object URLs
      if (frontImage?.previewUrl && frontImage.previewUrl.startsWith('blob:')) {
        URL.revokeObjectURL(frontImage.previewUrl);
      }
      if (backImage?.previewUrl && backImage.previewUrl.startsWith('blob:')) {
        URL.revokeObjectURL(backImage.previewUrl);
      }

      navigate(`/inspections/${inspectionId}/analyzing`, {
        state: { inspectionData: res?.data || res, commodity }
      });
    } catch (err) {
      console.error(err);
      setError(err.message || 'Failed to initialize product inspection.');
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <ScanLine className="w-4 h-4" />
            </span>
            <h1 className="text-xl font-extrabold text-slate-900">New PackCheck Inspection</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Capture or upload front and back packaged commodity images for Legal Metrology compliance screening.
          </p>
        </div>
      </div>

      {error && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2.5 text-xs text-rose-800 font-medium">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Commodity Metadata */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Package className="w-4 h-4 text-blue-700" />
            <h2 className="text-sm font-bold text-slate-900">Commodity Information</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Product / Commodity Name
              </label>
              <input
                type="text"
                name="product_name"
                value={commodity.product_name}
                onChange={handleCommodityChange}
                placeholder="e.g. Digestive Oats & Honey Biscuits 200g"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Brand / Trade Mark
              </label>
              <input
                type="text"
                name="brand"
                value={commodity.brand}
                onChange={handleCommodityChange}
                placeholder="e.g. NutriCrunch Foods"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Category
              </label>
              <select
                name="category"
                value={commodity.category}
                onChange={handleCommodityChange}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:bg-white"
              >
                <option value="Food & Beverages">Food &amp; Beverages</option>
                <option value="Personal Care / Cosmetics">Personal Care / Cosmetics</option>
                <option value="Household Cleaning">Household Cleaning</option>
                <option value="Spices & Condiments">Spices &amp; Condiments</option>
                <option value="Electronics & Appliances">Electronics &amp; Appliances</option>
                <option value="Apparel & Textiles">Apparel &amp; Textiles</option>
                <option value="General Packaged Goods">General Packaged Goods</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Barcode / EAN-13 (Optional)
              </label>
              <input
                type="text"
                name="barcode"
                value={commodity.barcode}
                onChange={handleCommodityChange}
                placeholder="8901030829142"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Product Label Evidence (FRONT + BACK) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-600" />
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Product Label Evidence</h2>
            </div>
            <span className="text-xs text-slate-500 font-medium">
              {[frontImage, backImage].filter(Boolean).length} / 2 sides captured
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* FRONT SIDE CARD */}
            <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold tracking-wider text-slate-800 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block" />
                  FRONT SIDE (Primary)
                </span>
                {frontImage ? (
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Ready
                  </span>
                ) : (
                  <span className="text-[11px] font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded">
                    Required
                  </span>
                )}
              </div>

              {frontImage ? (
                <div className="space-y-2">
                  <div className="h-48 rounded-xl overflow-hidden bg-slate-950 flex items-center justify-center relative border border-slate-200 shadow-inner">
                    <img
                      src={frontImage.previewUrl}
                      alt="Front Label Evidence"
                      className="h-full w-full object-contain"
                    />
                    <button
                      type="button"
                      onClick={handleRemoveFront}
                      className="absolute top-2 right-2 p-1.5 rounded-lg bg-rose-600 text-white shadow hover:bg-rose-700 transition"
                      title="Remove Front Image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="text-slate-500 truncate text-[11px]">{frontImage.fileName}</span>
                    <button
                      type="button"
                      onClick={handleFrontCamera}
                      className="text-blue-700 font-bold hover:underline shrink-0 text-[11px] flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" /> Retake
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col justify-center space-y-2.5 py-4">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleFrontCamera}
                      className="flex flex-col items-center justify-center p-4 border border-blue-200 hover:border-blue-400 bg-blue-50/70 hover:bg-blue-100/70 rounded-xl text-center cursor-pointer transition"
                    >
                      <Camera className="w-6 h-6 text-blue-700 mb-1" />
                      <span className="text-xs font-bold text-blue-900">Take Photo</span>
                      <span className="text-[10px] text-blue-600">Camera</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleFrontGallery}
                      className="flex flex-col items-center justify-center p-4 border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-100 rounded-xl text-center cursor-pointer transition shadow-2xs"
                    >
                      <Upload className="w-6 h-6 text-slate-600 mb-1" />
                      <span className="text-xs font-bold text-slate-800">Gallery</span>
                      <span className="text-[10px] text-slate-500">Pick file</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500 text-center">
                    Front panel showing product name, net quantity &amp; brand.
                  </p>
                </div>
              )}

              {/* Hidden file input fallback */}
              <input
                ref={frontInputRef}
                type="file"
                accept="image/*"
                onChange={handleFrontFileChange}
                className="hidden"
              />
            </div>

            {/* BACK SIDE CARD */}
            <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold tracking-wider text-slate-800 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />
                  BACK SIDE (Nutritional / MRP Panel)
                </span>
                {backImage ? (
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Ready
                  </span>
                ) : (
                  <span className="text-[11px] font-semibold text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
                    Optional / Recommended
                  </span>
                )}
              </div>

              {backImage ? (
                <div className="space-y-2">
                  <div className="h-48 rounded-xl overflow-hidden bg-slate-950 flex items-center justify-center relative border border-slate-200 shadow-inner">
                    <img
                      src={backImage.previewUrl}
                      alt="Back Label Evidence"
                      className="h-full w-full object-contain"
                    />
                    <button
                      type="button"
                      onClick={handleRemoveBack}
                      className="absolute top-2 right-2 p-1.5 rounded-lg bg-rose-600 text-white shadow hover:bg-rose-700 transition"
                      title="Remove Back Image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="text-slate-500 truncate text-[11px]">{backImage.fileName}</span>
                    <button
                      type="button"
                      onClick={handleBackCamera}
                      className="text-blue-700 font-bold hover:underline shrink-0 text-[11px] flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" /> Retake
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col justify-center space-y-2.5 py-4">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleBackCamera}
                      className="flex flex-col items-center justify-center p-4 border border-emerald-200 hover:border-emerald-400 bg-emerald-50/70 hover:bg-emerald-100/70 rounded-xl text-center cursor-pointer transition"
                    >
                      <Camera className="w-6 h-6 text-emerald-700 mb-1" />
                      <span className="text-xs font-bold text-emerald-900">Take Photo</span>
                      <span className="text-[10px] text-emerald-600">Camera</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleBackGallery}
                      className="flex flex-col items-center justify-center p-4 border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-100 rounded-xl text-center cursor-pointer transition shadow-2xs"
                    >
                      <Upload className="w-6 h-6 text-slate-600 mb-1" />
                      <span className="text-xs font-bold text-slate-800">Gallery</span>
                      <span className="text-[10px] text-slate-500">Pick file</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500 text-center">
                    Back panel showing MRP, USP, Mfg date, Consumer care &amp; address.
                  </p>
                </div>
              )}

              {/* Hidden file input fallback */}
              <input
                ref={backInputRef}
                type="file"
                accept="image/*"
                onChange={handleBackFileChange}
                className="hidden"
              />
            </div>
          </div>
        </div>

        {/* Submit Action */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate('/dashboard')}
            className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm shadow-md transition disabled:opacity-50 cursor-pointer"
          >
            {submitting ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>Analyze Evidence</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewInspectionPage;
