import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle2, Loader2, Sparkles, Scale, FileText } from 'lucide-react';

export const AnalysisProgressPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const [currentStep, setCurrentStep] = useState(1);

  const steps = [
    { id: 1, title: 'Images uploaded & metadata validated', desc: 'Verifying file formats and principal display surfaces' },
    { id: 2, title: 'Image quality & resolution checked', desc: 'Evaluating DPI, illumination, and contrast sufficiency' },
    { id: 3, title: 'Text regions & OCR detected', desc: 'Segmenting text blocks, numeral areas, and barcode zones' },
    { id: 4, title: 'Extracting mandatory declarations', desc: 'Identifying Net Qty, MRP, USP, Mfg Date, Packer & Consumer Care' },
    { id: 5, title: 'Validating Legal Metrology rules', desc: 'Checking Rule 6, Schedule II numeral heights & pricing formats' },
    { id: 6, title: 'Generating compliance score & audit result', desc: 'Synthesizing evidence bounding boxes and recommendations' }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev >= steps.length) {
          clearInterval(timer);
          setTimeout(() => {
            navigate(`/inspections/${id}/result`, {
              replace: true,
              state: location.state
            });
          }, 800);
          return prev;
        }
        return prev + 1;
      });
    }, 750);

    return () => clearInterval(timer);
  }, [id, navigate, steps.length, location.state]);

  return (
    <div className="min-h-[75vh] flex items-center justify-center py-12 px-4">
      <div className="max-w-xl w-full bg-white p-8 rounded-3xl border border-slate-200 shadow-card space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center mx-auto shadow-inner">
            <Scale className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Analyzing Packaged Commodity
          </h1>
          <p className="text-xs text-slate-500 font-mono">
            Inspection Record: <span className="text-blue-700 font-bold">{id}</span>
          </p>
        </div>

        {/* Multi-step progress list */}
        <div className="space-y-4 pt-2">
          {steps.map((step) => {
            const isCompleted = currentStep > step.id;
            const isCurrent = currentStep === step.id;
            const isPending = currentStep < step.id;

            return (
              <div
                key={step.id}
                className={`flex items-start gap-3.5 p-3.5 rounded-xl border transition-all duration-200 ${
                  isCurrent
                    ? 'bg-blue-50/80 border-blue-300 ring-2 ring-blue-500/20'
                    : isCompleted
                    ? 'bg-slate-50/60 border-slate-200 text-slate-700'
                    : 'bg-white border-slate-100 opacity-40'
                }`}
              >
                <div className="shrink-0 mt-0.5">
                  {isCompleted ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  ) : isCurrent ? (
                    <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border-2 border-slate-300 flex items-center justify-center text-[10px] text-slate-400 font-bold">
                      {step.id}
                    </div>
                  )}
                </div>

                <div className="flex-1">
                  <p className={`text-xs font-bold ${isCurrent ? 'text-blue-950' : 'text-slate-800'}`}>
                    {step.title}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center text-[11px] text-slate-400 font-mono">
          Evaluating Legal Metrology (Packaged Commodities) Rules, 2011 • Phase 1
        </div>
      </div>
    </div>
  );
};

export default AnalysisProgressPage;
