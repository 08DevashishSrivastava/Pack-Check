import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles,
  Upload,
  RotateCcw,
  ArrowRight,
  Scale,
  FileSearch,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Package,
  Layers
} from 'lucide-react';
import demoService, { demoSampleProducts } from '../../services/demo.service';
import EvidenceViewer from '../../components/common/EvidenceViewer';
import StatusBadge from '../../components/common/StatusBadge';
import ScoreBadge from '../../components/common/ScoreBadge';
import { getImageUrl } from '../../utils/imageUrl';

export const DemoPage = () => {
  const [selectedProduct, setSelectedProduct] = useState(demoSampleProducts[0]);
  const [selectedImage, setSelectedImage] = useState(demoSampleProducts[0].image);
  const [uploadedFile, setUploadedFile] = useState(null);

  const [screeningState, setScreeningState] = useState('IDLE'); // 'IDLE' | 'ANALYZING' | 'RESULT'
  const [analysisProgress, setAnalysisProgress] = useState(null);
  const [screeningResult, setScreeningResult] = useState(null);
  const [activeBoxId, setActiveBoxId] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);

  const handleSelectSample = (sample) => {
    setSelectedProduct(sample);
    setSelectedImage(sample.image);
    setUploadedFile(null);
    setScreeningState('IDLE');
    setScreeningResult(null);
    setErrorMessage(null);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!['image/jpeg', 'image/png', 'image/webp', 'image/jpg'].includes(file.type)) {
        setErrorMessage('Unsupported file format. Please upload JPEG, PNG, or WebP images.');
        return;
      }
      if (file.size > 15 * 1024 * 1024) {
        setErrorMessage('File size exceeds maximum allowed limit of 15MB.');
        return;
      }

      const url = URL.createObjectURL(file);
      setSelectedImage(url);
      setUploadedFile(file);
      setSelectedProduct({
        id: 'custom-upload',
        name: file.name.replace(/\.[^/.]+$/, ''),
        category: 'Custom Uploaded Packaging Label'
      });
      setScreeningState('IDLE');
      setScreeningResult(null);
      setErrorMessage(null);
    }
  };

  const runDemoAnalysis = async () => {
    setScreeningState('ANALYZING');
    setErrorMessage(null);
    try {
      const result = await demoService.analyzePackageImage({
        file: uploadedFile,
        sampleId: uploadedFile ? null : selectedProduct.id,
        onProgress: (prog) => setAnalysisProgress(prog)
      });
      setScreeningResult(result);
      setScreeningState('RESULT');
    } catch (err) {
      console.error('[DEMO ANALYSIS FAILED]:', err);
      setErrorMessage(err.message || 'AI analysis failed. Please check server connection.');
      setScreeningState('IDLE');
    }
  };

  const handleReset = () => {
    setScreeningState('IDLE');
    setScreeningResult(null);
    setAnalysisProgress(null);
    setErrorMessage(null);
  };

  const resultImageUrl = screeningResult?.image_url
    ? getImageUrl(screeningResult.image_url)
    : selectedImage;

  // Build bounding boxes list from declarations and ocr_items
  const evidenceBoxes = [
    ...(screeningResult?.ocr_items || []).map(item => ({ ...item, field: item.text })),
    ...(screeningResult?.declarations || []),
    ...(screeningResult?.violations || [])
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-100 text-blue-900 border border-blue-300 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-blue-700" />
            <span>Real AI Compliance Screener Sandbox</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Legal Metrology Packaged Commodity Screener
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real Gemini Vision analysis &amp; Legal Metrology Packaged Commodities Rules (LM-PC-2026.08) rule evaluation pipeline.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Link
            to="/login"
            className="inline-flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-sm transition"
          >
            <Scale className="w-4 h-4" />
            <span>Inspector Full Suite</span>
          </Link>
        </div>
      </div>

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-center justify-between gap-3 text-xs text-rose-900 font-medium">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="px-2.5 py-1 bg-rose-200 hover:bg-rose-300 rounded text-rose-900 font-bold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Sandbox Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Sample selector & Image Preview / Interactive Viewer */}
        <div className="lg:col-span-6 space-y-4">
          {screeningState !== 'RESULT' ? (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-subtle space-y-4">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                1. Select Sample or Upload Packaging Label
              </h2>

              {/* Sample Buttons Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {demoSampleProducts.map((sample) => (
                  <button
                    key={sample.id}
                    onClick={() => handleSelectSample(sample)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedProduct?.id === sample.id && !uploadedFile
                        ? 'border-blue-600 bg-blue-50/80 ring-2 ring-blue-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-slate-50'
                    }`}
                  >
                    <p className="text-[11px] font-bold text-slate-800 line-clamp-1">{sample.name}</p>
                    <p className="text-[9.5px] text-slate-500 line-clamp-1">{sample.category}</p>
                  </button>
                ))}
              </div>

              {/* File Upload Option */}
              <div className="relative border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-4 text-center bg-slate-50 transition cursor-pointer">
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
                <p className="text-xs font-semibold text-slate-700">
                  {uploadedFile ? `Selected: ${uploadedFile.name}` : 'Click or Drag & Drop custom product image'}
                </p>
                <p className="text-[10px] text-slate-400">PNG, JPG, WEBP supported (Max 15MB)</p>
              </div>

              {/* Preview Box */}
              <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-900 flex items-center justify-center p-2 min-h-[300px]">
                <img
                  src={selectedImage}
                  alt="Selected package"
                  className="max-h-[320px] w-auto object-contain rounded shadow-lg"
                />
              </div>

              {/* Start Screening CTA */}
              <button
                onClick={runDemoAnalysis}
                disabled={screeningState === 'ANALYZING'}
                className="w-full flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 text-white font-bold py-3 rounded-xl text-sm shadow-md transition disabled:opacity-50 cursor-pointer"
              >
                {screeningState === 'ANALYZING' ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Analyzing Packaging Rules with AI...</span>
                  </>
                ) : (
                  <>
                    <FileSearch className="w-4 h-4" />
                    <span>Analyze Product Label with AI</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          ) : (
            // In RESULT state: Show Evidence Viewer with bounding boxes
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Label Evidence &amp; Visual Bounding Boxes
                </h2>
                <button
                  onClick={handleReset}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-blue-700 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Test Another Image</span>
                </button>
              </div>
              <EvidenceViewer
                imageUrl={resultImageUrl}
                boundingBoxes={evidenceBoxes}
                activeBoxId={activeBoxId}
                onSelectBox={(box) => setActiveBoxId(box.field || box.id || box.title)}
                title={screeningResult?.product_name || selectedProduct?.name || 'Screened Commodity'}
                imageWidth={screeningResult?.images?.[0]?.image_width || 900}
                imageHeight={screeningResult?.images?.[0]?.image_height || 900}
              />
            </div>
          )}
        </div>

        {/* Right Column: Analysis Progress or Screening Results */}
        <div className="lg:col-span-6 space-y-4">
          {screeningState === 'IDLE' && (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-subtle text-center space-y-4 flex flex-col items-center justify-center min-h-[420px]">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center">
                <Scale className="w-7 h-7" />
              </div>
              <div className="max-w-md space-y-2">
                <h2 className="text-lg font-bold text-slate-900">Ready to Screen Package</h2>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Select one of the sample packaged commodities or upload your own label photograph. Click <strong>"Analyze Product Label with AI"</strong> to extract mandatory declarations and evaluate Legal Metrology compliance rules.
                </p>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left w-full text-xs space-y-1.5 text-slate-600">
                <p className="font-bold text-slate-800">Rule engine screening verifies:</p>
                <div className="grid grid-cols-2 gap-1 text-[11px]">
                  <span>✓ Rule 6(1)(a) Commodity Name</span>
                  <span>✓ Rule 6(1)(b) Net Quantity</span>
                  <span>✓ Rule 6(1)(e) MRP &amp; Tax format</span>
                  <span>✓ Rule 6(1)(f) Manufacturer &amp; Address</span>
                  <span>✓ Rule 6(1)(c) Consumer Grievance</span>
                  <span>✓ Rule 6(1)(g) Country of Origin</span>
                </div>
              </div>
            </div>
          )}

          {screeningState === 'ANALYZING' && (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-subtle space-y-6 min-h-[420px] flex flex-col justify-center">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                <h2 className="text-lg font-bold text-slate-900">AI Screening in Progress</h2>
                <p className="text-xs text-slate-500 font-mono">
                  {analysisProgress?.text || 'Analyzing image with Gemini Vision AI...'}
                </p>
              </div>

              {/* Stepper Progress */}
              <div className="space-y-3 max-w-sm mx-auto w-full pt-4">
                {[
                  { id: 1, label: 'Uploading inspection image & calculating hash' },
                  { id: 2, label: 'Gemini Vision AI visual reading & OCR' },
                  { id: 3, label: 'Extracting Legal Metrology declarations' },
                  { id: 4, label: 'Rule engine validation (LM-PC-2026.08)' },
                  { id: 5, label: 'Generating audit score & saving investigation' },
                ].map((s) => {
                  const isDone = (analysisProgress?.step || 1) > s.id;
                  const isCurrent = (analysisProgress?.step || 1) === s.id;

                  return (
                    <div key={s.id} className="flex items-center gap-3 text-xs">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                        isDone ? 'bg-emerald-600 text-white' : isCurrent ? 'bg-blue-600 text-white animate-pulse' : 'bg-slate-200 text-slate-500'
                      }`}>
                        {isDone ? '✓' : s.id}
                      </div>
                      <span className={isCurrent ? 'font-bold text-slate-900' : isDone ? 'text-slate-700' : 'text-slate-400'}>
                        {s.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {screeningState === 'RESULT' && screeningResult && (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-5">
              {/* Screening summary bar */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Screening Result</p>
                  <p className="text-base font-extrabold text-slate-900">{screeningResult.product_name || 'Audited Commodity'}</p>
                  {screeningResult.brand && (
                    <p className="text-xs text-blue-700 font-semibold">{screeningResult.brand}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={screeningResult.status} size="md" />
                  <ScoreBadge score={screeningResult.score} size="md" />
                </div>
              </div>

              {/* Saved Investigation Record Card */}
              {screeningResult.id && (
                <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-xl flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
                    <div>
                      <span className="font-bold text-blue-950">Investigation Saved: </span>
                      <span className="font-mono text-blue-800 font-bold">{screeningResult.id}</span>
                    </div>
                  </div>
                  <Link
                    to={`/inspections/${screeningResult.id}`}
                    className="inline-flex items-center gap-1 text-[11px] bg-blue-700 hover:bg-blue-800 text-white font-bold px-3 py-1.5 rounded-lg shadow-xs transition"
                  >
                    <span>View in Inspector</span>
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
              )}

              {/* Statutory Disclaimer Notice */}
              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                <span>{screeningResult.disclaimer}</span>
              </div>

              {/* Violations Flagged */}
              {screeningResult.violations && screeningResult.violations.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-rose-800 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                    <span>Flagged Non-Compliance Issues ({screeningResult.violations.length})</span>
                  </p>
                  {screeningResult.violations.map((viol, idx) => (
                    <div
                      key={viol.id || idx}
                      onClick={() => setActiveBoxId(viol.field || viol.title)}
                      className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-1.5 cursor-pointer hover:bg-rose-100/70 transition"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-rose-950">{viol.title}</span>
                        <StatusBadge status={viol.severity} size="sm" />
                      </div>
                      <p className="text-[11px] text-rose-900 font-medium">
                        <strong>Observed:</strong> {viol.detected_value || 'Not detected'}
                      </p>
                      <p className="text-[10.5px] text-slate-600">
                        <strong>Statutory Requirement:</strong> {viol.expected_condition}
                      </p>
                      {viol.legal_reference && (
                        <p className="text-[10px] text-slate-500 font-mono">
                          <strong>Rule Reference:</strong> {viol.legal_reference}
                        </p>
                      )}
                      <p className="text-[10.5px] text-blue-900 font-medium bg-white/60 p-1.5 rounded border border-rose-200/60">
                        💡 <strong>Recommendation:</strong> {viol.recommendation}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* Extracted Declarations Table */}
              <div className="space-y-2">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Extracted Mandatory Declarations (Legal Metrology Rule 6)
                </p>
                <div className="max-h-56 overflow-y-auto rounded-xl border border-slate-200 divide-y divide-slate-100 text-xs">
                  {(screeningResult.declarations || []).map((decl, idx) => (
                    <div
                      key={decl.id || idx}
                      onClick={() => setActiveBoxId(decl.field || decl.text)}
                      className={`p-2.5 flex items-center justify-between cursor-pointer transition ${
                        activeBoxId === (decl.field || decl.text) ? 'bg-blue-50/90 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="max-w-[70%]">
                        <p className="font-semibold text-slate-800">{decl.field}</p>
                        <p className="text-[11px] text-slate-600 font-mono truncate">{decl.value}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {decl.confidence && (
                          <span className="text-[10px] text-slate-400 font-mono">
                            {Math.round(decl.confidence * 100)}% conf
                          </span>
                        )}
                        <StatusBadge status={decl.status} size="sm" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  onClick={handleReset}
                  className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition cursor-pointer"
                >
                  Test Another Sample
                </button>
                <Link
                  to={screeningResult.id ? `/inspections/${screeningResult.id}` : '/login'}
                  className="flex-1 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold text-center transition"
                >
                  {screeningResult.id ? 'Open Full Audit Details' : 'Inspector Full Suite'}
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DemoPage;
