import React from 'react';
import { Link } from 'react-router-dom';
import { Scale, BookOpen, ShieldAlert, CheckCircle2, ArrowRight, ExternalLink } from 'lucide-react';

export const AboutPage = () => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-900 border border-blue-200 text-xs font-bold">
          <BookOpen className="w-3.5 h-3.5 text-blue-700" />
          <span>Statutory Framework Reference</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Legal Metrology (Packaged Commodities) Rules, 2011
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed">
          Standardized guide on packaging compliance requirements, mandatory declarations, font size standards, and unit sale price rules enforced by PackCheck.
        </p>
      </div>

      {/* Main Rules Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-3">
          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs">
            R-6
          </div>
          <h2 className="text-base font-bold text-slate-900">Rule 6(1) — Mandatory Declarations</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Every package must contain clear declarations on its principal display panel including:
          </p>
          <ul className="space-y-1.5 text-xs text-slate-700 list-disc list-inside">
            <li>Name and complete address of the manufacturer/packer/importer.</li>
            <li>Generic or common name of the packaged commodity.</li>
            <li>Net quantity in terms of standard unit of weight or measure.</li>
            <li>Month and year of manufacture or pre-packing.</li>
            <li>Maximum Retail Price (MRP) inclusive of all taxes.</li>
            <li>Unit Sale Price (USP) for items above 1 unit/100g/100ml.</li>
            <li>Consumer Care telephone number, postal address, and email.</li>
            <li>Country of origin (for imported goods).</li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-subtle space-y-3">
          <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-xs">
            SCH-2
          </div>
          <h2 className="text-base font-bold text-slate-900">Schedule II — Font Height Standards</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Minimum height of numerals and letters for net quantity declaration (Table-I):
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 rounded">
              <thead className="bg-slate-50 text-[10px] font-bold text-slate-500 uppercase">
                <tr>
                  <th className="p-2 border-b">Net Qty Range</th>
                  <th className="p-2 border-b">Normal Packaging</th>
                  <th className="p-2 border-b">Blown/Molded/Perforated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-mono text-[11px]">
                <tr>
                  <td className="p-2">Up to 50 g / ml</td>
                  <td className="p-2">1.0 mm</td>
                  <td className="p-2">2.0 mm</td>
                </tr>
                <tr>
                  <td className="p-2">50 g to 200 g / ml</td>
                  <td className="p-2">2.0 mm</td>
                  <td className="p-2">4.0 mm</td>
                </tr>
                <tr>
                  <td className="p-2">200 g to 1 kg / l</td>
                  <td className="p-2 font-bold text-blue-700">4.0 mm</td>
                  <td className="p-2">6.0 mm</td>
                </tr>
                <tr>
                  <td className="p-2">&gt; 1 kg / l</td>
                  <td className="p-2">6.0 mm</td>
                  <td className="p-2">6.0 mm</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Bottom info */}
      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-blue-950 text-sm">Need to run an inspection audit?</h3>
          <p className="text-xs text-blue-800">Launch the live sandbox demo or sign in to the inspector dashboard.</p>
        </div>
        <div className="flex gap-2">
          <Link
            to="/demo"
            className="bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition"
          >
            Try Demo
          </Link>
          <Link
            to="/login"
            className="bg-white border border-blue-300 text-blue-900 text-xs font-bold px-4 py-2 rounded-xl hover:bg-blue-100 transition"
          >
            Inspector Login
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
