import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Scale,
  ShieldCheck,
  ScanLine,
  FileSearch,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  ArrowRight,
  Sparkles,
  ChevronDown,
  Layers,
  Award,
  Eye,
  Sliders,
  Check
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { StatusBadge } from '../../components/common/StatusBadge';
import { ScoreBadge } from '../../components/common/ScoreBadge';

export const LandingPage = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleStartInspection = () => {
    if (isAuthenticated) {
      navigate('/inspections/new');
    } else {
      navigate('/login');
    }
  };

  const [activeFaq, setActiveFaq] = useState(null);

  const faqs = [
    {
      q: 'What is PackCheck and what legal framework does it support?',
      a: 'PackCheck is an AI-assisted compliance inspection system designed to enforce the Legal Metrology (Packaged Commodities) Rules, 2011 (Problem Statement ID: 26034). It assists inspectors in scanning packaged commodities to detect mandatory declarations, numeral font heights, MRP/USP formats, manufacturer details, and consumer care disclosures.'
    },
    {
      q: 'Does the AI make legally binding adjudication decisions?',
      a: 'No. The AI engine performs structured optical declaration extraction and rule-based screening. The system flags potential statutory non-compliances and presents highlighted visual evidence for the designated Legal Metrology Officer/Inspector to review and validate before legal notices are served.'
    },
    {
      q: 'Which mandatory declarations under Rule 6 are verified?',
      a: 'The system validates all mandatory declarations under Rule 6(1), including Name and Address of Manufacturer/Packer/Importer, Common/Generic Name of Commodity, Net Quantity (with minimum font height validation per Schedule II), Maximum Retail Price (MRP), Unit Sale Price (USP), Month and Year of Manufacture/Packing, and Complete Consumer Care Redressal Contact details.'
    },
    {
      q: 'Can inspectors use smartphones or portable devices during field inspections?',
      a: 'Yes. The inspection portal includes responsive mobile camera capture optimized for high-resolution packaging photography on tablets and mobile devices, supporting front, back, top, bottom, and side packaging surfaces.'
    }
  ];

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 sm:pt-20 bg-gradient-to-b from-blue-50/70 via-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            <div className="inline-flex items-center gap-2 bg-blue-100/90 text-blue-900 border border-blue-200 px-3.5 py-1.5 rounded-full text-xs font-semibold shadow-2xs">
              <Scale className="w-4 h-4 text-blue-700" />
              <span>Legal Metrology (Packaged Commodities) Rules, 2011 Enforcement</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
              AI-Powered Legal Metrology <br />
              <span className="text-blue-700 underline decoration-blue-300 decoration-wavy decoration-2">
                Compliance Inspection
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto">
              Scan packaged commodity labels and identify missing declarations, potential violations and compliance issues using AI-assisted analysis and configurable Legal Metrology rules.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handleStartInspection}
                className="inline-flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md hover:shadow-lg transition duration-150 cursor-pointer"
              >
                <span>Start Inspection</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <Link
                to="/demo"
                className="inline-flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 px-6 py-3 rounded-xl font-semibold text-sm shadow-2xs transition"
              >
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Try Public Demo</span>
              </Link>

              <Link
                to="/login"
                className="inline-flex items-center gap-1.5 text-slate-600 hover:text-blue-700 px-4 py-3 text-sm font-semibold transition"
              >
                <span>Inspector Login</span>
              </Link>
            </div>

            <p className="text-[11.5px] text-slate-500 font-medium">
              * AI-assisted compliance screening based on configured Legal Metrology rules — not a final legal adjudication.
            </p>
          </div>

          {/* Realistic Dashboard & Scanner Mockup Preview */}
          <div className="mt-12 sm:mt-16 max-w-5xl mx-auto rounded-2xl p-2 sm:p-3 bg-gradient-to-b from-slate-800 to-slate-900 shadow-2xl border border-slate-700">
            <div className="bg-slate-950 rounded-xl overflow-hidden border border-slate-800">
              {/* Fake Window Header */}
              <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="ml-2 font-mono text-[11px] text-slate-300">
                    PackCheck — Live Inspection Workspace [INSP-2026-0841]
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status="NON_COMPLIANT" size="sm" />
                  <ScoreBadge score={64} size="sm" />
                </div>
              </div>

              {/* Preview Content Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
                {/* Left: Product preview with highlighted bounding box */}
                <div className="md:col-span-7 bg-slate-900/50 p-6 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-slate-800">
                  <div className="relative max-w-xs rounded-lg overflow-hidden border border-slate-700 shadow-lg">
                    <img
                      src="https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800&auto=format&fit=crop&q=80"
                      alt="Sample product label scan"
                      className="w-full h-64 object-cover"
                    />
                    {/* Simulated Bounding Boxes */}
                    <div className="absolute top-10 left-8 right-8 border-2 border-dashed border-blue-400 bg-blue-500/20 rounded p-1">
                      <span className="bg-blue-600 text-white text-[9px] font-bold px-1 py-0.5 rounded">
                        Product: Oats & Honey 200g
                      </span>
                    </div>
                    <div className="absolute bottom-12 left-10 w-32 border-2 border-solid border-rose-500 bg-rose-500/30 rounded p-1 animate-pulse">
                      <span className="bg-rose-600 text-white text-[9px] font-bold px-1 py-0.5 rounded">
                        Violation: Font 2.2mm (&lt; 3.0mm)
                      </span>
                    </div>
                  </div>
                  <p className="mt-3 text-xs text-slate-400 text-center font-mono">
                    Surface: Principal Display Panel (Front) • Resolution: 300 DPI
                  </p>
                </div>

                {/* Right: Compliance Result Summary */}
                <div className="md:col-span-5 bg-slate-950 p-5 space-y-4 text-xs">
                  <div className="border-b border-slate-800 pb-3">
                    <p className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">Screening Result</p>
                    <p className="text-sm font-bold text-white mt-1">Digestive Biscuits 200g</p>
                    <p className="text-slate-400 text-[11px]">Rule Evaluation: LM (Packaged Commodities) 2011</p>
                  </div>

                  <div className="space-y-2">
                    <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-800/60 flex items-start gap-2 text-rose-200">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-[11px]">LM-RULE-06-NETQTY-FONT</p>
                        <p className="text-[10px] text-rose-300">Net Quantity numeral height 2.2mm is below statutory 3.0mm minimum.</p>
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-800/60 flex items-start gap-2 text-rose-200">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-[11px]">LM-RULE-06-USP</p>
                        <p className="text-[10px] text-rose-300">Mandatory Unit Sale Price (USP) declaration absent alongside MRP.</p>
                      </div>
                    </div>

                    <div className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-800/60 flex items-center justify-between text-emerald-200 text-[11px]">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Mfg Address, Date &amp; Care</span>
                      </span>
                      <span className="font-bold">Compliant (3/3)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section: How It Works */}
      <section id="how-it-works" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-12">
          <p className="text-xs font-bold uppercase tracking-wider text-blue-700">Enforcement Workflow</p>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            How PackCheck Operates
          </h2>
          <p className="text-slate-600 text-sm">
            A standardized, auditable 4-stage pipeline that bridges computer vision with statutory Legal Metrology validation rules.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              step: '01',
              title: 'Capture / Upload',
              desc: 'High-resolution image capture of packaging surfaces (Front, Back, Sides, Top, Bottom) via field camera or file upload.',
              icon: ScanLine
            },
            {
              step: '02',
              title: 'AI Extraction',
              desc: 'Structured extraction of textual declarations, bounding boxes, numeral heights, and format patterns using vision models.',
              icon: FileSearch
            },
            {
              step: '03',
              title: 'Rule Validation',
              desc: 'Deterministic evaluation against Legal Metrology Rules 2011 (Rule 6, Schedule II, MRP, USP, Consumer Care).',
              icon: Sliders
            },
            {
              step: '04',
              title: 'Compliance Result',
              desc: 'Audit report with evidence bounding boxes, compliance scoring, non-compliance notices, and inspector review actions.',
              icon: Award
            }
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-xl p-6 border border-slate-200 shadow-subtle hover:shadow-card transition duration-150 relative overflow-hidden"
              >
                <span className="text-4xl font-extrabold text-slate-100 absolute top-3 right-4 select-none">
                  {item.step}
                </span>
                <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Section: Key Capabilities */}
      <section id="capabilities" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="bg-slate-900 rounded-3xl p-8 sm:p-12 text-white shadow-xl">
          <div className="max-w-2xl mb-10 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">Key Capabilities</span>
            <h2 className="text-3xl font-extrabold text-white tracking-tight">
              Comprehensive Packaging Inspection Tools
            </h2>
            <p className="text-slate-400 text-sm">
              Built specifically to streamline the workflow of Legal Metrology enforcement officers and quality control teams.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-slate-300">
            {[
              {
                title: 'Multi-Face Product Scanning',
                desc: 'Support for multiple image angles with dedicated labels for front, back, top, bottom, and sides.',
                icon: Layers
              },
              {
                title: 'Mandatory Declaration Audit',
                desc: 'Audits Rule 6 requirements: MRP, Net Quantity, Mfg Date, Packer details, and Country of Origin.',
                icon: CheckCircle2
              },
              {
                title: 'Evidence Bounding Box Viewer',
                desc: 'Interactive bounding box overlays trace every flagged rule directly back to the packaging photograph.',
                icon: Eye
              },
              {
                title: 'Compliance Scoring & Metrics',
                desc: 'Deterministic scoring algorithm weighting critical vs minor statutory infractions.',
                icon: Award
              },
              {
                title: 'Central Inspection History',
                desc: 'Searchable repository of past inspections, violation patterns, and brand-level compliance rates.',
                icon: FileSpreadsheet
              },
              {
                title: 'Exportable Audit Notices',
                desc: 'Generate standard compliance and non-compliance PDF documentation for official notices.',
                icon: ShieldCheck
              }
            ].map((cap, idx) => {
              const Icon = cap.icon;
              return (
                <div key={idx} className="bg-slate-800/80 rounded-xl p-5 border border-slate-700/80 space-y-2.5">
                  <div className="w-8 h-8 rounded-lg bg-blue-600/30 text-blue-400 flex items-center justify-center">
                    <Icon className="w-4 h-4" />
                  </div>
                  <p className="font-bold text-white text-sm">{cap.title}</p>
                  <p className="text-xs text-slate-400 leading-relaxed">{cap.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Section: Compliance Detection Scope */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700">Statutory Scope</span>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Statutory Compliance Rules Assisted by AI
            </h2>
            <p className="text-slate-600 text-sm leading-relaxed">
              PackCheck systematically inspects key clauses of the Legal Metrology (Packaged Commodities) Rules, 2011 to assist inspectors in identifying non-conformities:
            </p>
            <div className="pt-2">
              <Link
                to="/about"
                className="inline-flex items-center gap-1.5 text-blue-700 font-bold text-xs hover:text-blue-800"
              >
                <span>Read complete Legal Metrology 2011 Rules guide</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              {
                rule: 'Missing Declarations',
                desc: 'Detects absence of mandatory declarations (e.g. Unit Sale Price, Consumer Care Contact, Country of Origin).'
              },
              {
                rule: 'MRP & Tax Declarations',
                desc: 'Validates MRP currency symbol ₹ and mandatory "inclusive of all taxes" suffix wording.'
              },
              {
                rule: 'Net Quantity Font Heights',
                desc: 'Evaluates numeral size against Table-I Schedule II minimum millimeter thresholds.'
              },
              {
                rule: 'Manufacturer & Packer Info',
                desc: 'Verifies complete postal address and distinct identity for manufacturer vs marketing company.'
              },
              {
                rule: 'Date of Packing / Mfg',
                desc: 'Checks standard Month and Year format compliance.'
              },
              {
                rule: 'Print Readability & Contrast',
                desc: 'Highlights low-contrast text on principal display area needing physical officer verification.'
              }
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1.5">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-xs">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{item.rule}</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed pl-6">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="text-center space-y-2 mb-8">
          <h2 className="text-2xl font-extrabold text-slate-900">Frequently Asked Questions</h2>
          <p className="text-xs text-slate-500">Legal Metrology enforcement and system usage questions</p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs transition-colors"
            >
              <button
                onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                className="w-full px-5 py-4 text-left flex items-center justify-between text-sm font-bold text-slate-900 hover:bg-slate-50"
              >
                <span>{faq.q}</span>
                <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform ${activeFaq === idx ? 'rotate-180' : ''}`} />
              </button>
              {activeFaq === idx && (
                <div className="px-5 pb-4 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="bg-gradient-to-r from-blue-800 to-slate-900 rounded-2xl p-8 sm:p-12 text-center text-white space-y-5 shadow-xl">
          <h2 className="text-3xl font-extrabold tracking-tight">
            Ready to test Legal Metrology Compliance Inspection?
          </h2>
          <p className="text-slate-300 text-sm max-w-xl mx-auto">
            Experience our public interactive demo or sign into the inspector portal to begin a full packaging inspection.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <Link
              to="/demo"
              className="bg-white text-blue-900 hover:bg-blue-50 px-6 py-3 rounded-xl font-bold text-sm shadow-md transition"
            >
              Launch Public Demo
            </Link>
            <Link
              to="/signup"
              className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl font-bold text-sm transition"
            >
              Register Inspector Account
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
