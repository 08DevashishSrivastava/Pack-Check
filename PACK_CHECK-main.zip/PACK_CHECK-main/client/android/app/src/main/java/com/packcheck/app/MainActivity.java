package com.packcheck.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
