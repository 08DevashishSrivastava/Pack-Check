"""Metro-Check's real PaddleOCR 3.x service."""
import io
import logging
from typing import Any

import cv2
import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, UnidentifiedImageError

from field_extractor import extract_fields

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("metro_check.ocr")
MAX_BYTES = 15 * 1024 * 1024
MAX_PIXELS = 30_000_000
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}
ocr_engine = None
ocr_startup_error = None

app = FastAPI(title="Metro-Check AI OCR Service", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])


def get_ocr():
    global ocr_engine
    if ocr_engine is None:
        from paddleocr import PaddleOCR
        logger.info("[OCR] loading PaddleOCR model")
        ocr_engine = PaddleOCR(lang="en", use_doc_orientation_classify=True, use_doc_unwarping=True, use_textline_orientation=True)
        logger.info("[OCR] model ready")
    return ocr_engine


@app.on_event("startup")
async def start_ocr() -> None:
    global ocr_startup_error
    try:
        get_ocr()
    except Exception as error:
        ocr_startup_error = str(error)
        logger.exception("[OCR] model startup failed")


def preprocess_image(image: np.ndarray) -> np.ndarray:
    """Light, non-destructive preprocessing; original upload is never modified."""
    height, width = image.shape[:2]
    if width * height > MAX_PIXELS:
        scale = (MAX_PIXELS / (width * height)) ** 0.5
        image = cv2.resize(image, (int(width * scale), int(height * scale)), interpolation=cv2.INTER_AREA)
    denoised = cv2.fastNlMeansDenoisingColored(image, None, 3, 3, 7, 21)
    lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    enhanced = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(l)
    return cv2.cvtColor(cv2.merge((enhanced, a, b)), cv2.COLOR_LAB2BGR)


def rect_from_polygon(polygon: Any) -> dict[str, int]:
    points = np.asarray(polygon).reshape(-1, 2)
    x1, y1 = points.min(axis=0)
    x2, y2 = points.max(axis=0)
    return {"x": int(x1), "y": int(y1), "width": int(x2 - x1), "height": int(y2 - y1)}


def run_ocr(image: np.ndarray) -> list[dict]:
    result = next(iter(get_ocr().predict(preprocess_image(image))), None)
    if result is None:
        return []
    payload = result.json if hasattr(result, "json") else result
    if callable(payload):
        payload = payload()
    if isinstance(payload, str):
        import json
        payload = json.loads(payload)
    payload = payload.get("res", payload)
    items = []
    for text, score, polygon in zip(payload.get("rec_texts", []), payload.get("rec_scores", []), payload.get("rec_polys", payload.get("dt_polys", []))):
        text = str(text).strip()
        if text:
            confidence = float(score)
            items.append({"text": text, "confidence": confidence, "status": "REVIEW" if confidence < 0.65 else "DETECTED", "bbox": rect_from_polygon(polygon)})
    return items


def detect_codes(image: np.ndarray) -> list[dict]:
    value, points, _ = cv2.QRCodeDetector().detectAndDecode(image)
    return [{"type": "QR_CODE", "data": value, "bbox": rect_from_polygon(points[0]), "status": "DETECTED"}] if value and points is not None else []


@app.get("/health")
async def health():
    return {"status": "ok" if ocr_engine else "error", "ocr": "ready" if ocr_engine else "unavailable", "detail": ocr_startup_error}


@app.post("/api/ocr/analyze")
async def analyze(image: UploadFile = File(...)):
    if image.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, detail={"code": "INVALID_IMAGE_TYPE", "message": "JPEG, PNG, and WebP images are supported."})
    content = await image.read()
    if not content or len(content) > MAX_BYTES:
        raise HTTPException(413, detail={"code": "INVALID_IMAGE_SIZE", "message": "Image must be between 1 byte and 15 MB."})
    try:
        pil_image = Image.open(io.BytesIO(content)); pil_image.verify()
        decoded = cv2.imdecode(np.frombuffer(content, np.uint8), cv2.IMREAD_COLOR)
    except (UnidentifiedImageError, cv2.error, ValueError):
        raise HTTPException(400, detail={"code": "IMAGE_UNREADABLE", "message": "The uploaded file is not a readable image."})
    if decoded is None:
        raise HTTPException(400, detail={"code": "IMAGE_UNREADABLE", "message": "The uploaded file is not a readable image."})
    height, width = decoded.shape[:2]
    if width < 32 or height < 32 or width * height > MAX_PIXELS:
        raise HTTPException(400, detail={"code": "INVALID_IMAGE_DIMENSIONS", "message": "Image dimensions are outside the supported range."})
    if ocr_engine is None:
        raise HTTPException(503, detail={"code": "OCR_UNAVAILABLE", "message": ocr_startup_error or "PaddleOCR is not ready."})
    logger.info("[OCR] received: filename=%s width=%d height=%d", image.filename, width, height)
    try:
        items = run_ocr(decoded)
    except Exception as error:
        logger.exception("[OCR] inference failed")
        raise HTTPException(502, detail={"code": "OCR_FAILED", "message": str(error)})
    logger.info("[OCR] detected item count: %d", len(items))
    for item in items:
        logger.info("[OCR] text=%r confidence=%s bbox=%s", item["text"], item["confidence"], item["bbox"])
    fields = extract_fields(items)
    return {"success": True, "analysis_code": "NO_TEXT_DETECTED" if not items else "OK", "image_width": width, "image_height": height, "ocr": {"full_text": "\n".join(item["text"] for item in items), "items": items}, "fields": fields, "barcodes": detect_codes(decoded)}
