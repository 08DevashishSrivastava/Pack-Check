"""Deterministic extraction from actual OCR text only."""
import re

FIELD_PATTERNS = {
    "Maximum Retail Price (MRP)": r"\b(?:m\.?r\.?p\.?|maximum\s+retail\s+price)\b[^\n]{0,50}",
    "Net Quantity": r"\b(?:net\s*(?:wt|weight|qty|quantity|content)?|contents?)\b[^\n]{0,50}|\b\d+(?:[.,]\d+)?\s*(?:kg|g|gm|mg|ml|l|litre|ltr)\b",
    "Date of Manufacture / Packing": r"\b(?:mfg|mfd|manufactured|packing|packed\s+on)\b[^\n]{0,50}",
    "Manufacturer Name & Address": r"\b(?:manufactured\s+by|mfg\.?\s*by|packed\s+by|marketed\s+by|imported\s+by)\b[^\n]{0,100}",
    "Consumer Care Contact": r"\b(?:consumer\s+care|customer\s+care|helpline|toll\s*free)\b[^\n]{0,100}|\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b",
    "Country of Origin": r"\b(?:country\s+of\s+origin|made\s+in|origin)\b[^\n]{0,50}",
    "Unit Sale Price (USP)": r"\b(?:unit\s+sale\s+price|usp|price\s+per\s+(?:unit|kg|g|l|ml))\b[^\n]{0,50}",
    "Batch Number": r"\b(?:batch|lot)\s*(?:no\.?|number|#)?\s*[:.-]?\s*[A-Za-z0-9/-]+",
    "Expiry Date": r"\b(?:expiry|exp|best\s+before|use\s+by)\b[^\n]{0,50}",
}


def missing():
    return {"value": None, "status": "NOT_DETECTED", "confidence": None, "bbox": None}


def extract_fields(items):
    fields = {name: missing() for name in FIELD_PATTERNS}
    fields["Product Name"] = missing()  # never inferred from position, size, or first OCR line
    for name, pattern in FIELD_PATTERNS.items():
        for item in items:
            if re.search(pattern, item["text"], re.IGNORECASE):
                fields[name] = {"value": item["text"].strip(), "status": item["status"], "confidence": item["confidence"], "bbox": item["bbox"]}
                break
    # A product name needs an explicit, OCR-visible label; otherwise it remains missing.
    for item in items:
        match = re.search(r"\b(?:product|commodity|item)\s*name\s*[:.-]\s*(.+)$", item["text"], re.IGNORECASE)
        if match and match.group(1).strip():
            fields["Product Name"] = {"value": match.group(1).strip(), "status": item["status"], "confidence": item["confidence"], "bbox": item["bbox"]}
            break
    return fields
