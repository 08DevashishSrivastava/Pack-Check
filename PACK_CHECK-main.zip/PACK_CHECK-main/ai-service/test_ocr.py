"""Run a genuine PaddleOCR smoke test and save evidence boxes."""
import sys
from pathlib import Path

import cv2

from main import run_ocr

DEFAULT_IMAGE = Path(__file__).parent.parent / "server" / "uploads" / "inspections" / "INSP-2026-0841" / "front-nutricrunch-digestive.jpg"


def main():
    image_path = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_IMAGE
    image = cv2.imread(str(image_path))
    if image is None:
        raise SystemExit(f"OCR TEST FAILED: cannot read {image_path}")
    items = run_ocr(image)
    if not items:
        raise SystemExit("OCR TEST FAILED: PaddleOCR detected no text")
    debug = image.copy()
    for item in items:
        box = item["bbox"]
        cv2.rectangle(debug, (box["x"], box["y"]), (box["x"] + box["width"], box["y"] + box["height"]), (0, 180, 0), 2)
        print(f"text={item['text']!r} confidence={item['confidence']:.4f} bbox={box}")
    output = Path(__file__).parent / "debug_ocr_boxes.jpg"
    cv2.imwrite(str(output), debug)
    print(f"OCR TEST PASSED: {len(items)} actual text regions; visualization: {output}")


if __name__ == "__main__":
    main()
